import hashlib, json
from decimal import Decimal
from datetime import date, datetime
from sqlalchemy import select, desc
from .models import AuditLog

def _js(o):
    if isinstance(o, (Decimal,)): return str(o)
    if isinstance(o, (date, datetime)): return o.isoformat()
    raise TypeError(type(o))

def clean(d):
    return None if d is None else json.loads(json.dumps(d, default=_js, ensure_ascii=False))

def digest(prev, row) -> str:
    raw = json.dumps([prev, row["ts"], row["user_id"], row["action"], row["entity"], row["entity_id"],
                      row["before"], row["after"], row["reason"]], sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()

def log(db, user, action, entity="", entity_id="", before=None, after=None, reason="", request=None):
    last = db.execute(select(AuditLog.hash).order_by(desc(AuditLog.id)).limit(1).with_for_update()).scalar() or ""
    row = AuditLog(user_id=getattr(user, "id", "") or "", username=getattr(user, "username", "") or "",
                   action=action, entity=entity, entity_id=str(entity_id), before=clean(before), after=clean(after),
                   reason=reason or "", ip=(request.client.host if request and request.client else ""),
                   user_agent=(request.headers.get("user-agent", "")[:300] if request else ""), prev_hash=last)
    from datetime import timezone
    row.ts = datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)
    db.add(row); db.flush()
    row.hash = digest(last, dict(ts=row.ts.isoformat(), user_id=row.user_id, action=action, entity=entity,
                                 entity_id=row.entity_id, before=row.before, after=row.after, reason=row.reason))
    return row

def verify_chain(db):
    prev, n = "", 0
    for r in db.execute(select(AuditLog).order_by(AuditLog.id)).scalars():
        want = digest(prev, dict(ts=r.ts.isoformat(), user_id=r.user_id, action=r.action, entity=r.entity,
                                 entity_id=r.entity_id, before=r.before, after=r.after, reason=r.reason))
        if r.prev_hash != prev or r.hash != want:
            return {"ok": False, "broken_at": r.id, "checked": n}
        prev, n = r.hash, n + 1
    return {"ok": True, "checked": n}
