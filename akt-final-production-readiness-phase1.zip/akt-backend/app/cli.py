"""python -m app.cli create-admin <username>   (كلمة المرور تُقرأ من متغير AKT_ADMIN_PASSWORD أو تُطلب)"""
import sys, os, getpass
from sqlalchemy import select
from .config import require_secret
from .db import engine, Base, SessionLocal
from .models import User, Role
from .rbac import seed_rbac
from .security import hash_password
from .legacy import seed_accounts

def main():
    require_secret()
    if len(sys.argv) < 3 or sys.argv[1] != "create-admin":
        sys.exit(__doc__)
    Base.metadata.create_all(engine)
    pw = os.getenv("AKT_ADMIN_PASSWORD") or getpass.getpass("كلمة مرور المسؤول: ")
    with SessionLocal() as db:
        seed_rbac(db); seed_accounts(db)
        name = sys.argv[2].lower()
        if db.execute(select(User).where(User.username == name)).scalar_one_or_none():
            sys.exit("المستخدم موجود")
        role = db.execute(select(Role).where(Role.name == "admin")).scalar_one()
        db.add(User(username=name, full_name="مسؤول النظام", password_hash=hash_password(pw), roles=[role]))
        db.commit(); print("تم إنشاء المسؤول")

if __name__ == "__main__":
    main()
