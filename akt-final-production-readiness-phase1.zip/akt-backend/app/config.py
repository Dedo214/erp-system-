import os
from dataclasses import dataclass, field

@dataclass
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./akt.db")
    auto_create: bool = os.getenv("AKT_AUTO_CREATE", "1") == "1"   # الإنتاج: 0 والجداول عبر alembic upgrade head
    secret_key: str = os.getenv("AKT_SECRET_KEY", "")
    token_minutes: int = int(os.getenv("AKT_TOKEN_MINUTES", "480"))
    max_ip_failures: int = int(os.getenv("AKT_MAX_IP_FAILURES", "30"))
    max_failed_logins: int = int(os.getenv("AKT_MAX_FAILED_LOGINS", "5"))
    lock_minutes: int = int(os.getenv("AKT_LOCK_MINUTES", "15"))
    upload_dir: str = os.getenv("AKT_UPLOAD_DIR", "./uploads")
    max_upload_mb: int = int(os.getenv("AKT_MAX_UPLOAD_MB", "15"))
    allowed_ext: tuple = (".pdf", ".png", ".jpg", ".jpeg", ".xlsx", ".docx", ".csv", ".txt")
    cors_origins: list = field(default_factory=lambda: [o for o in os.getenv("AKT_CORS_ORIGINS", "").split(",") if o])

settings = Settings()

def require_secret():
    # لا نقبل مفتاحاً فارغاً أو ضعيفاً في الإنتاج
    if len(settings.secret_key) < 32:
        raise RuntimeError("AKT_SECRET_KEY must be set (>= 32 chars)")
