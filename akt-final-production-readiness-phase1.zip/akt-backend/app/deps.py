from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from .db import get_db
from .models import User
from .security import read_token

def current_user(request: Request, db=Depends(get_db)) -> User:
    h = request.headers.get("authorization", "")
    if not h.lower().startswith("bearer "):
        raise HTTPException(401, "يلزم تسجيل الدخول")
    d = read_token(h[7:])
    if not d:
        raise HTTPException(401, "انتهت الجلسة أو الرمز غير صالح")
    u = db.get(User, d["u"])
    if not u or not u.is_active or u.token_version != d["v"]:
        raise HTTPException(401, "الجلسة غير صالحة")
    request.state.user = u
    return u

def need(code: str):
    """الصلاحية تُفحص على الخادم في كل طلب، ولا تعتمد على إخفاء الأزرار في الواجهة."""
    def dep(u: User = Depends(current_user)) -> User:
        if code not in u.permissions():
            raise HTTPException(403, f"لا تملك صلاحية: {code}")
        return u
    return dep
