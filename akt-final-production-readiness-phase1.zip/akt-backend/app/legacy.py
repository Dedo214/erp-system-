import hashlib, json, re
from datetime import date
from decimal import Decimal, InvalidOperation
from fastapi import HTTPException
from sqlalchemy import select
from .numbering import next_no
from .models import LegacySnapshot, Project, Party, Account, BoqItem, ScheduleTask, Tender, Inspection, Snag, Handover, DailyReport, SafetyRecord, SiteDocument, Risk, Correspondence, Equipment, EquipmentUsage, Worker, LaborDay, Contract, Rating, Rfq, RfqQuote

STATUS = {"جارٍ": "active", "مكتمل": "completed", "متوقف": "paused", "تحت التسعير": "bidding"}
COA = {"1100": "البنك", "1110": "الخزينة", "1200": "العملاء", "1250": "ضمان أعمال محتجز لدى العملاء", "1270": "ضريبة خصم من المنبع",
       "1300": "المخزون", "1410": "دفعات مقدمة للمقاولين", "2200": "دفعات مقدمة من العملاء", "2600": "ضرائب خصم مستحقة السداد", "2500": "رواتب مستحقة", "2510": "تأمينات اجتماعية مستحقة", "2520": "ضريبة كسب عمل مستحقة", "1400": "عهد الموظفين", "2100": "الموردون", "2300": "المقاولون من الباطن", "2400": "ضمان أعمال محتجز للمقاولين",
       "3100": "رأس المال والأرصدة الافتتاحية", "4100": "إيرادات المقاولات", "4200": "إيرادات أخرى", "5100": "تكلفة المواد",
       "5200": "أجور عمالة", "5300": "مقاولو باطن", "5400": "معدات وإيجارات", "5500": "مصروفات إدارية", "5900": "مصروفات أخرى"}
ATYPE = {"1": "asset", "2": "liability", "3": "equity", "4": "revenue", "5": "expense"}

def seed_accounts(db):
    have = set(db.execute(select(Account.code)).scalars())
    for c, n in COA.items():
        if c not in have: db.add(Account(code=c, name=n, type=ATYPE[c[0]]))
    db.flush()

def _d(v):
    try: return date.fromisoformat(str(v)[:10]) if v else None
    except ValueError: return None

def _m(v):
    try:
        x = Decimal(str(v or 0)).quantize(Decimal("0.01"))
        return x if x >= 0 else Decimal(0)
    except (InvalidOperation, ValueError):
        return Decimal(0)

def _q(v, places=3):
    try:
        x = Decimal(str(v or 0)).quantize(Decimal(1).scaleb(-places))
        return x if x >= 0 else Decimal(0)
    except (InvalidOperation, ValueError):
        return Decimal(0)

def _code(db, base):
    c, n = base, 1
    while db.execute(select(Project.id).where(Project.code == c)).first():
        n += 1; c = f"{base}-{n}"
    return c

def import_legacy(db, data: dict, user) -> dict:
    raw = json.dumps(data, sort_keys=True, ensure_ascii=False)
    sha = hashlib.sha256(raw.encode()).hexdigest()
    snap = db.execute(select(LegacySnapshot).where(LegacySnapshot.sha256 == sha)).scalar_one_or_none()
    new_snapshot = snap is None
    if new_snapshot:
        snap = LegacySnapshot(sha256=sha, data=data, imported_by=user.id); db.add(snap); db.flush()
    seed_accounts(db)
    cnt = {"clients": 0, "suppliers": 0, "subcontractors": 0, "projects": 0, "skipped": 0}

    def party(kind, name, legacy_id, **kw):
        name = (name or "").strip()
        if not name: cnt["skipped"] += 1; return None
        p = db.execute(select(Party).where(Party.kind == kind, Party.name == name)).scalar_one_or_none()
        if p: return p
        p = Party(kind=kind, name=name, legacy_id=legacy_id, **kw); db.add(p); db.flush()
        cnt[{"client": "clients", "supplier": "suppliers", "subcontractor": "subcontractors"}[kind]] += 1
        return p

    cmap = {}
    for c in data.get("clients", []):
        p = party("client", c.get("name"), c.get("id"), contact=c.get("contact") or "", phone=c.get("phone") or "", email=c.get("email") or "")
        if p: cmap[c.get("id")] = p.id
    supmap = {}
    for s in data.get("suppliers", []):
        p = party("supplier", s.get("name"), s.get("id"), phone=s.get("phone") or "", terms_days=int(s.get("terms") or 0), credit_limit=_m(s.get("limit")))
        if p: supmap[s.get("id")] = p.id
    smap = {}
    for s in data.get("subs", []):
        p = party("subcontractor", s.get("name"), s.get("id"), phone=s.get("phone") or "")
        if p: smap[s.get("id")] = p.id
    for p in data.get("projects", []):
        name = (p.get("name") or "").strip()
        if not name: cnt["skipped"] += 1; continue
        if db.execute(select(Project.id).where(Project.legacy_id == p.get("id"))).first(): continue
        cl = party("client", p.get("client"), None) if p.get("client") else None
        s, e = _d(p.get("start")), _d(p.get("end"))
        if s and e and e < s: e = None
        base = "P-" + re.sub(r"\W+", "", str(p.get("id") or len(name)))[:12].upper()
        db.add(Project(code=_code(db, base), name=name, client_id=cl.id if cl else None, location=p.get("location") or "",
                       start_date=s, end_date=e, contract_value=_m(p.get("value")), budget=_m(p.get("budget")),
                       progress=min(Decimal(100), max(Decimal(0), _m(p.get("progress")))),
                       status=STATUS.get(p.get("status"), "active"), legacy_id=p.get("id")))
        cnt["projects"] += 1
    db.flush()
    pmap = {p.legacy_id: p.id for p in db.execute(select(Project).where(Project.legacy_id.is_not(None))).scalars()}
    cnt.update(boq_items=0, tasks=0)
    for b in data.get("boq", []):
        pid = pmap.get(b.get("pid"))
        if not pid or not (b.get("desc") or "").strip() or db.execute(select(BoqItem.id).where(BoqItem.legacy_id == b.get("id"))).first():
            if not pid or not (b.get("desc") or "").strip(): cnt["skipped"] += 1
            continue
        db.add(BoqItem(project_id=pid, section=str(b.get("sec") or "")[:120], description=str(b["desc"]).strip()[:400], unit=str(b.get("unit") or "")[:30],
                       qty=_q(b.get("qty")), price=_m(b.get("price")), done=_q(b.get("done")), legacy_id=b.get("id"))); cnt["boq_items"] += 1
    for t in data.get("tasks", []):
        pid, s, e = pmap.get(t.get("pid")), _d(t.get("start")), _d(t.get("end"))
        if not pid or not s or not e or e < s or not (t.get("name") or "").strip():
            cnt["skipped"] += 1; continue
        if db.execute(select(ScheduleTask.id).where(ScheduleTask.legacy_id == t.get("id"))).first(): continue
        db.add(ScheduleTask(project_id=pid, name=str(t["name"]).strip()[:300], start=s, end=e,
                            progress=min(Decimal(100), _q(t.get("progress"), 2)), legacy_id=t.get("id"))); cnt["tasks"] += 1

    # ---- الجودة والتسليم والمناقصات ----
    from .routes.quality import HOCK
    cnt.update(tenders=0, inspections=0, snags=0, handovers=0)
    ST = {"قيد الدراسة": "study", "تم التقديم": "submitted", "تفاوض": "negotiation", "فائزة": "won", "خاسرة": "lost"}
    for t in data.get("tenders", []):
        name = (t.get("name") or "").strip()
        if not name or t.get("stage") not in ST: cnt["skipped"] += 1; continue
        if db.execute(select(Tender.id).where(Tender.legacy_id == t.get("id"))).first(): continue
        db.add(Tender(name=name[:300], client_id=cmap.get(t.get("cid")), type=str(t.get("type") or "")[:80], due=_d(t.get("due")),
                      value=_m(t.get("value")), cost=_m(t.get("cost")), stage=ST[t["stage"]], note=str(t.get("note") or ""),
                      project_id=pmap.get(t.get("pid")) if t.get("pid") else None, legacy_id=t.get("id"))); cnt["tenders"] += 1
    from sqlalchemy import func
    nxt = lambda col: (db.execute(select(func.max(col))).scalar() or 0)
    ir_no, ncr_no = nxt(Inspection.no), nxt(Snag.no)
    IST = {"قيد الفحص": "pending", "مقبول": "accepted", "مقبول بملاحظات": "accepted_notes", "مرفوض": "rejected"}
    for i in data.get("insp", []):
        pid = pmap.get(i.get("pid"))
        if not pid or i.get("status") not in IST or i.get("kind") not in ("تنفيذ", "مواد") or not _d(i.get("date")) or not (i.get("item") or "").strip():
            cnt["skipped"] += 1; continue
        if db.execute(select(Inspection.id).where(Inspection.legacy_id == i.get("id"))).first(): continue
        ir_no += 1
        db.add(Inspection(no=ir_no, project_id=pid, item=str(i["item"])[:300], kind="work" if i["kind"] == "تنفيذ" else "material", date=_d(i["date"]),
                          inspector=str(i.get("inspector") or "")[:120], status=IST[i["status"]], note=str(i.get("note") or ""), legacy_id=i.get("id"))); cnt["inspections"] += 1
    SEV = {"منخفضة": "low", "متوسطة": "medium", "عالية": "high"}
    for s in data.get("snags", []):
        pid = pmap.get(s.get("pid"))
        if not pid or s.get("severity") not in SEV or s.get("status") not in ("مفتوح", "مغلق") or not (s.get("desc") or "").strip():
            cnt["skipped"] += 1; continue
        if db.execute(select(Snag.id).where(Snag.legacy_id == s.get("id"))).first(): continue
        ncr_no += 1; closed = s["status"] == "مغلق"
        db.add(Snag(no=ncr_no, project_id=pid, location=str(s.get("loc") or "-")[:300], description=str(s["desc"]), severity=SEV[s["severity"]], due=_d(s.get("due")),
                    status="closed" if closed else "open", responsible=str(s.get("resp") or "")[:200], opened=_d(s.get("opened")) or date.today(),
                    closed=date.today() if closed else None, closure_note="مُرحَّلة من النظام القديم" if closed else "", legacy_id=s.get("id"))); cnt["snags"] += 1
    for h in data.get("handover", []):
        pid = pmap.get(h.get("pid")); kind = {"ابتدائي": "initial", "نهائي": "final"}.get(h.get("kind"))
        if not pid or not kind or h.get("status") not in ("تم", "جاري"): cnt["skipped"] += 1; continue
        if db.execute(select(Handover.id).where(Handover.project_id == pid, Handover.kind == kind)).first(): continue
        checks = {str(k): bool(v) for k, v in (h.get("checks") or {}).items() if str(k).isdigit() and int(k) < len(HOCK[kind])}
        done = h["status"] == "تم"
        if done and len(checks) < len(HOCK[kind]) or done and not all(checks.values()):
            cnt["skipped"] += 1; continue          # محضر "تم" ببنود ناقصة لا يُستورد كمعتمد
        db.add(Handover(project_id=pid, kind=kind, status="done" if done else "in_progress", date=_d(h.get("date")),
                        warranty_months=max(0, min(120, int(h.get("warranty") or 0))), checks=checks, legacy_id=h.get("id"))); cnt["handovers"] += 1
    db.flush()

    # ---- الموقع والمعدات والعمالة (سجلات تشغيلية بلا أثر محاسبي) ----
    cnt.update(daily_reports=0, safety=0, documents=0, risks=0, correspondence=0, equipment=0, equipment_usage=0, workers=0, labor_days=0, sub_contracts=0, ratings=0, rfqs=0)
    seen = lambda M, lid: db.execute(select(M.id).where(M.legacy_id == lid)).first() is not None
    for r in data.get("reports", []):
        pid, d = pmap.get(r.get("pid")), _d(r.get("date"))
        if not pid or not d or not (r.get("work") or "").strip(): cnt["skipped"] += 1; continue
        if seen(DailyReport, r.get("id")) or db.execute(select(DailyReport.id).where(DailyReport.project_id == pid, DailyReport.date == d)).first(): continue
        db.add(DailyReport(project_id=pid, date=d, weather=str(r.get("weather") or "")[:40], workers_count=max(0, int(r.get("workers") or 0)),
                           work=str(r["work"]), issues=str(r.get("issues") or ""), legacy_id=r.get("id"))); cnt["daily_reports"] += 1
    KIND = {"تفتيش": "inspection", "حادث": "accident", "شبه حادث": "near_miss"}; SEVR = {"منخفضة": "low", "متوسطة": "medium", "عالية": "high"}
    for s in data.get("safety", []):
        pid, d = pmap.get(s.get("pid")), _d(s.get("date"))
        if not pid or not d or s.get("kind") not in KIND or s.get("severity") not in SEVR or s.get("status") not in ("مفتوح", "مغلق") or not (s.get("desc") or "").strip():
            cnt["skipped"] += 1; continue
        if seen(SafetyRecord, s.get("id")): continue
        db.add(SafetyRecord(project_id=pid, date=d, kind=KIND[s["kind"]], severity=SEVR[s["severity"]], description=str(s["desc"]), action=str(s.get("action") or ""),
                            status="closed" if s["status"] == "مغلق" else "open", legacy_id=s.get("id"))); cnt["safety"] += 1
    for d in data.get("docs", []):
        i, e = _d(d.get("issue")), _d(d.get("expiry"))
        if not (d.get("name") or "").strip() or (i and e and e < i): cnt["skipped"] += 1; continue
        if seen(SiteDocument, d.get("id")): continue
        db.add(SiteDocument(project_id=pmap.get(d.get("pid")), doc_type=str(d.get("type") or "مستند")[:60], name=str(d["name"])[:300], issue_date=i, expiry_date=e, legacy_id=d.get("id"))); cnt["documents"] += 1
    RST = {"مفتوح": "open", "مخفف": "mitigated", "مغلق": "closed"}
    for r in data.get("risks", []):
        pid = pmap.get(r.get("pid"))
        try: pr, im = int(r.get("prob")), int(r.get("impact"))
        except (TypeError, ValueError): pr = im = 0
        if not pid or not (1 <= pr <= 5 and 1 <= im <= 5) or not (r.get("desc") or "").strip(): cnt["skipped"] += 1; continue
        if seen(Risk, r.get("id")): continue
        db.add(Risk(project_id=pid, description=str(r["desc"]), prob=pr, impact=im, owner=str(r.get("owner") or "")[:120], mitigation=str(r.get("mitigation") or ""),
                    status=RST.get(r.get("status"), "open"), legacy_id=r.get("id"))); cnt["risks"] += 1
    for c in data.get("corr", []):
        d, direction = _d(c.get("date")), {"وارد": "in", "صادر": "out"}.get(c.get("dir"))
        if not d or not direction or not (c.get("no") or "").strip() or not (c.get("subject") or "").strip() or not (c.get("party") or "").strip(): cnt["skipped"] += 1; continue
        if seen(Correspondence, c.get("id")) or db.execute(select(Correspondence.id).where(Correspondence.direction == direction, Correspondence.ref_no == str(c["no"]).strip())).first(): continue
        db.add(Correspondence(direction=direction, ref_no=str(c["no"]).strip()[:60], date=d, party=str(c["party"])[:200], project_id=pmap.get(c.get("pid")),
                              subject=str(c["subject"])[:400], due=_d(c.get("due")), status="closed" if c.get("status") == "مغلق" else "open",
                              closure_note="مُرحَّلة من النظام القديم" if c.get("status") == "مغلق" else "", legacy_id=c.get("id"))); cnt["correspondence"] += 1
    emap, wmap = {}, {}
    EST = {"يعمل": "working", "صيانة": "maintenance", "متوقف": "idle"}
    for e in data.get("equip", []):
        name = (e.get("name") or "").strip()
        if not name: cnt["skipped"] += 1; continue
        ex = db.execute(select(Equipment).where(Equipment.name == name)).scalar()
        if not ex:
            ex = Equipment(name=name[:200], type=str(e.get("type") or "")[:60], daily_rate=_m(e.get("rate")), status=EST.get(e.get("status"), "working"),
                           maint_interval_days=max(1, int(e.get("interval") or 90)), last_maint=_d(e.get("lastMaint")), legacy_id=e.get("id")); db.add(ex); db.flush(); cnt["equipment"] += 1
        emap[e.get("id")] = ex
    for u in data.get("eqUse", []):
        eq, pid, d = emap.get(u.get("eid")), pmap.get(u.get("pid")), _d(u.get("date"))
        days = _q(u.get("days"), 2)
        if not eq or not pid or not d or days <= 0: cnt["skipped"] += 1; continue
        if seen(EquipmentUsage, u.get("id")) or db.execute(select(EquipmentUsage.id).where(EquipmentUsage.equipment_id == eq.id, EquipmentUsage.project_id == pid, EquipmentUsage.date == d)).first(): continue
        db.add(EquipmentUsage(equipment_id=eq.id, project_id=pid, date=d, days=days, rate=eq.daily_rate, legacy_id=u.get("id"))); cnt["equipment_usage"] += 1
    for w in data.get("workers", []):
        name = (w.get("name") or "").strip()
        if not name: cnt["skipped"] += 1; continue
        ex = db.execute(select(Worker).where(Worker.legacy_id == w.get("id"))).scalar()
        if not ex: ex = Worker(name=name[:200], trade=str(w.get("trade") or "")[:80], daily_rate=_m(w.get("daily")), legacy_id=w.get("id")); db.add(ex); db.flush(); cnt["workers"] += 1
        wmap[w.get("id")] = ex
    for a in data.get("att", []):
        wk, pid, d, days = wmap.get(a.get("wid")), pmap.get(a.get("pid")), _d(a.get("date")), _q(a.get("days"), 2)
        if not wk or not pid or not d or not (0 < days <= 2): cnt["skipped"] += 1; continue
        if seen(LaborDay, a.get("id")) or db.execute(select(LaborDay.id).where(LaborDay.worker_id == wk.id, LaborDay.date == d)).first(): continue
        # "مسدد" في القديم = تاريخ مالي لم يُرحَّل للأستاذ الجديد؛ يُستورد مسددًا بلا قيد ويُبلَّغ عنه. غير المسدد يبقى مستحقًا ويُسدَّد بقيد جديد.
        db.add(LaborDay(worker_id=wk.id, project_id=pid, date=d, days=days, rate=wk.daily_rate, paid=bool(a.get("paid")), legacy_id=a.get("id"))); cnt["labor_days"] += 1
    for c in data.get("subc", []):       # عقود مقاولي الباطن تُستورد "مسودة" فقط؛ مستخلصاتها ودفعاتها تاريخ مالي لا يُرحَّل
        sid, pid, code = smap.get(c.get("subid")), pmap.get(c.get("pid")), "LEG-" + str(c.get("id"))
        if not sid or not pid or not (c.get("desc") or "").strip(): cnt["skipped"] += 1; continue
        if db.execute(select(Contract.id).where(Contract.code == code)).first(): continue
        db.add(Contract(code=code, kind="subcontractor", project_id=pid, party_id=sid, title=str(c["desc"])[:300], original_value=_m(c.get("value")),
                        retention_pct=min(Decimal(100), _m(c.get("retPct"))), status="draft", created_by="legacy-import")); cnt["sub_contracts"] += 1
    for r in data.get("ratings", []):     # تقييمات الموردين/المقاولين: تشغيلية بلا أثر محاسبي
        pid = supmap.get(r.get("rid")) if r.get("kind") == "sup" else smap.get(r.get("rid"))
        try: q, t, pr = int(r.get("quality")), int(r.get("time")), int(r.get("price"))
        except (TypeError, ValueError): q = t = pr = 0
        if not pid or not (1 <= q <= 5 and 1 <= t <= 5 and 1 <= pr <= 5) or not _d(r.get("date")): cnt["skipped"] += 1; continue
        if seen(Rating, r.get("id")): continue
        db.add(Rating(party_id=pid, date=_d(r["date"]), quality=q, punctuality=t, price=pr, note=str(r.get("note") or "")[:500], created_by="legacy-import", legacy_id=r.get("id"))); cnt["ratings"] += 1
    for r in data.get("rfqs", []):        # طلبات الأسعار: تُستورد مفتوحة بعروضها؛ لا ترسية ولا أمر شراء يُنشأ آليًا
        qty = _q(r.get("qty"))
        if not (r.get("item") or "").strip() or qty <= 0: cnt["skipped"] += 1; continue
        if seen(Rfq, r.get("id")): continue
        rf = Rfq(no=next_no(db, Rfq.no), item=str(r["item"])[:300], unit=str(r.get("unit") or "")[:20], qty=qty, project_id=pmap.get(r.get("pid")),
                 status="cancelled" if r.get("done") else "open", award_note="مغلق في النظام القديم دون تحديد مورد" if r.get("done") else "", created_by="legacy-import", legacy_id=r.get("id"))
        seen_p = set()
        for qt in r.get("quotes") or []:
            sp, pr = supmap.get(qt.get("sid")), _m(qt.get("price"))
            if sp and pr > 0 and sp not in seen_p: seen_p.add(sp); rf.quotes.append(RfqQuote(party_id=sp, price=pr, note=str(qt.get("note") or "")[:300]))
        db.add(rf); db.flush(); cnt["rfqs"] += 1
    db.flush()
    # الوحدات التي ما زالت محفوظة في اللقطة الكاملة فقط وستُنقل في المراحل التالية
    DONE = ("projects", "suppliers", "subs", "clients", "boq", "tasks", "tenders", "insp", "snags", "handover", "reports", "safety", "docs", "risks", "corr",
            "equip", "eqUse", "workers", "att", "subc", "ratings", "rfqs")
    FIN = {"stock": "أرصدة مخزون", "moves": "حركات مخزون", "pos": "أوامر شراء", "bills": "فواتير موردين", "invoices": "مستخلصات العملاء", "txs": "حركات الخزينة/البنك",
           "subi": "مستخلصات مقاولي الباطن", "cust": "عهد", "custExp": "مصروفات عهد", "cos": "أوامر تغيير", "plan": "خطة التحصيل", "je": "قيود يومية",
           "rfqs": "طلبات تسعير", "ratings": "تقييمات", "counts": "جرد", "approvals": "اعتمادات",
           "emps": "الموظفون", "loans": "السلف", "payruns": "مسيرات الرواتب"}
    WHY = {"cos": "ترتبط بقيمة عقد المشروع القديمة ولا يوجد عقد مرحَّل تُنسب إليه؛ تُدخل كأوامر تغيير على العقد بعد إنشائه واعتماده",
           "plan": "خطة التحصيل مربوطة بمستخلصات غير مرحَّلة؛ تُبنى من جديد على عقد المشروع (جدول الدفعات/المستخلصات)",
           "approvals": "طلبات اعتماد معلّقة تنفّذ إجراءات على كائنات النظام القديم؛ لا تُنقل لأن تنفيذها بعد النقل غير آمن — أعد رفعها من الشاشات الجديدة",
           "counts": "سجل جرد قديم سبق وعدّل المخزون؛ استيراده سيعدّله مرة ثانية. الجرد الجديد متاح من شاشة الجرد المخزني",
           "emps": "يلزم رقم الموظف الفعلي في AKT Attendance (مفتاح الربط)؛ يُدخل الموظفون من شاشة الموظفين أو بملف مرقّم",
           "loans": "ترتبط بالموظفين وتحتاج رصيدًا افتتاحيًا معتمدًا", "payruns": "تاريخ مالي مُرحَّل في النظام القديم؛ لا يُعاد احتسابه"}
    not_migrated = [{"module": k, "label": FIN.get(k, k), "records": len(v), "reason": WHY.get(k, "تاريخ مالي/معاملات لا تُرحَّل آليًا؛ تُدخل أرصدتها الافتتاحية بقيد معتمد من المحاسب")}
                    for k, v in sorted(data.items()) if isinstance(v, list) and v and k not in DONE and k in FIN]
    pending = sorted(k for k, v in data.items() if isinstance(v, list) and v and k not in DONE and k not in FIN)
    snap.summary = {**cnt, "pending_modules": pending, "not_migrated": not_migrated}
    return {"snapshot_id": snap.id, "new_snapshot": new_snapshot, "sha256": sha, **cnt, "pending_modules": pending, "not_migrated": not_migrated}
