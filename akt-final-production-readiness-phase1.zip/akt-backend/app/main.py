import os
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, text
from .config import settings, require_secret
from .db import engine, Base, SessionLocal
from . import models
from .rbac import seed_rbac
from .legacy import seed_accounts
from .routes import auth, users, masters, ledger, admin, contracts, invoices, reports, hr, payroll, procurement, executive, planning, quality, tenders, site, resources, files, export, sourcing, budget

def create_app(init_db=True) -> FastAPI:
    require_secret()
    docs = os.getenv("AKT_ENABLE_DOCS") == "1"        # وثائق Swagger مغلقة افتراضيًا: لا نكشف خريطة الواجهة
    app = FastAPI(title="Akt Group ERP API", version="1.0.0-phase1", docs_url="/docs" if docs else None,
                  redoc_url=None, openapi_url="/openapi.json" if docs else None)
    if settings.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["*"], allow_headers=["authorization", "content-type"])
    if init_db:
        if settings.auto_create:
            Base.metadata.create_all(engine)
        with SessionLocal() as db:
            seed_rbac(db); seed_accounts(db); db.commit()
    for r in (auth.router, users.router, masters.router, ledger.router, admin.router, contracts.router, invoices.router, reports.router, hr.router, payroll.router, procurement.router, executive.router, planning.router, quality.router, tenders.router, site.router, resources.router, files.router, export.router, sourcing.router, budget.router):
        app.include_router(r)

    from fastapi.responses import FileResponse
    web = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web")

    @app.get("/", include_in_schema=False)
    def ui():
        return FileResponse(os.path.join(web, "index.html"), headers={
            "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})

    @app.get("/app.js", include_in_schema=False)
    def appjs():
        return FileResponse(os.path.join(web, "app.js"), media_type="application/javascript")

    @app.get("/i18n.js", include_in_schema=False)
    def i18njs():
        return FileResponse(os.path.join(web, "i18n.js"), media_type="application/javascript")

    @app.middleware("http")
    async def sec_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return resp

    @app.exception_handler(Exception)
    async def boom(request: Request, exc: Exception):
        # لا نكشف تفاصيل داخلية للمستخدم، ولا نخفي الخطأ: يُسجَّل في سجل الخادم
        import logging; logging.getLogger("akt").exception("unhandled: %s", exc)
        return JSONResponse({"detail": "حدث خطأ في الخادم ولم تُحفظ العملية"}, status_code=500)

    @app.get("/health")
    def health():
        with SessionLocal() as db:
            db.execute(text("select 1"))
        return {"ok": True}
    return app
