import uuid
from datetime import date as _date, datetime, date, timezone
from decimal import Decimal
from sqlalchemy import (String, Integer, Boolean, DateTime, Date, Numeric, ForeignKey, Text, JSON,
                        UniqueConstraint, CheckConstraint, Index, Table, Column)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def _id(): return uuid.uuid4().hex
def _now(): return datetime.now(timezone.utc)
Money = Numeric(18, 2)

user_roles = Table("user_roles", Base.metadata,
    Column("user_id", ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True))
role_perms = Table("role_permissions", Base.metadata,
    Column("role_id", ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    Column("perm_id", ForeignKey("permissions.id", ondelete="CASCADE"), primary_key=True))

class Permission(Base):
    __tablename__ = "permissions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(80), unique=True)          # مثال: projects.update
    label: Mapped[str] = mapped_column(String(200), default="")

class Role(Base):
    __tablename__ = "roles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    perms: Mapped[list[Permission]] = relationship(secondary=role_perms, lazy="selectin")

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    username: Mapped[str] = mapped_column(String(80), unique=True)
    full_name: Mapped[str] = mapped_column(String(200), default="")
    email: Mapped[str] = mapped_column(String(200), default="")
    password_hash: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    token_version: Mapped[int] = mapped_column(Integer, default=0)       # لإبطال الجلسات فوراً
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    roles: Mapped[list[Role]] = relationship(secondary=user_roles, lazy="selectin")

    def permissions(self) -> set[str]:
        return {p.code for r in self.roles for p in r.perms}

class LoginAttempt(Base):
    __tablename__ = "login_attempts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    username: Mapped[str] = mapped_column(String(80))
    ok: Mapped[bool] = mapped_column(Boolean)
    ip: Mapped[str] = mapped_column(String(64), default="")

class AuditLog(Base):
    """سجل غير قابل للتعديل: كل سجل يحمل بصمة السجل السابق (hash chain) لكشف أي عبث."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=lambda: _now().replace(tzinfo=None))   # UTC بدون منطقة زمنية ليتطابق التحقق من البصمة
    user_id: Mapped[str] = mapped_column(String(32), default="")
    username: Mapped[str] = mapped_column(String(80), default="")
    action: Mapped[str] = mapped_column(String(80))
    entity: Mapped[str] = mapped_column(String(60), default="")
    entity_id: Mapped[str] = mapped_column(String(64), default="")
    before: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    reason: Mapped[str] = mapped_column(Text, default="")
    ip: Mapped[str] = mapped_column(String(64), default="")
    user_agent: Mapped[str] = mapped_column(String(300), default="")
    prev_hash: Mapped[str] = mapped_column(String(64), default="")
    hash: Mapped[str] = mapped_column(String(64), default="")
    __table_args__ = (Index("ix_audit_entity", "entity", "entity_id"),)

class Party(Base):
    """عميل / مورد / مقاول باطن في جدول واحد مع نوع الطرف."""
    __tablename__ = "parties"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    kind: Mapped[str] = mapped_column(String(20))      # client | supplier | subcontractor
    name: Mapped[str] = mapped_column(String(200))
    contact: Mapped[str] = mapped_column(String(200), default="")
    phone: Mapped[str] = mapped_column(String(60), default="")
    email: Mapped[str] = mapped_column(String(200), default="")
    tax_no: Mapped[str] = mapped_column(String(60), default="")
    terms_days: Mapped[int] = mapped_column(Integer, default=0)
    credit_limit: Mapped[Decimal] = mapped_column(Money, default=0)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("kind", "name", name="uq_party_kind_name"),
                      CheckConstraint("kind in ('client','supplier','subcontractor')", name="ck_party_kind"),
                      CheckConstraint("credit_limit >= 0", name="ck_party_credit"))

class Project(Base):
    __tablename__ = "projects"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(250))
    client_id: Mapped[str | None] = mapped_column(ForeignKey("parties.id"), nullable=True)
    location: Mapped[str] = mapped_column(String(250), default="")
    start_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    contract_value: Mapped[Decimal] = mapped_column(Money, default=0)
    budget: Mapped[Decimal] = mapped_column(Money, default=0)
    progress: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    status: Mapped[str] = mapped_column(String(20), default="active")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)           # تحكم تفاؤلي بالتزامن
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint("progress between 0 and 100", name="ck_proj_progress"),
                      CheckConstraint("contract_value >= 0 and budget >= 0", name="ck_proj_money"),
                      CheckConstraint("end_date is null or start_date is null or end_date >= start_date", name="ck_proj_dates"))

class Account(Base):
    __tablename__ = "accounts"
    code: Mapped[str] = mapped_column(String(20), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(12))      # asset|liability|equity|revenue|expense
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (CheckConstraint("type in ('asset','liability','equity','revenue','expense')", name="ck_acct_type"),)

class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    date: Mapped[_date] = mapped_column(Date)
    description: Mapped[str] = mapped_column(String(400))
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    source: Mapped[str] = mapped_column(String(30), default="manual")
    reverses_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True, unique=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    lines: Mapped[list["JournalLine"]] = relationship(cascade="all, delete-orphan", lazy="selectin")

class JournalLine(Base):
    __tablename__ = "journal_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_id: Mapped[str] = mapped_column(ForeignKey("journal_entries.id", ondelete="CASCADE"))
    account_code: Mapped[str] = mapped_column(ForeignKey("accounts.code"))
    debit: Mapped[Decimal] = mapped_column(Money, default=0)
    credit: Mapped[Decimal] = mapped_column(Money, default=0)
    __table_args__ = (CheckConstraint("debit >= 0 and credit >= 0 and (debit = 0 or credit = 0)", name="ck_line_side"),)

class PeriodLock(Base):
    __tablename__ = "period_lock"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    lock_date: Mapped[_date | None] = mapped_column(Date, nullable=True)

class Attachment(Base):
    __tablename__ = "attachments"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    entity: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str] = mapped_column(String(64))
    filename: Mapped[str] = mapped_column(String(250))
    mime: Mapped[str] = mapped_column(String(100), default="")
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    path: Mapped[str] = mapped_column(String(400))
    uploaded_by: Mapped[str] = mapped_column(String(32), default="")
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

class LegacySnapshot(Base):
    """نسخة كاملة غير معدّلة من بيانات النظام القديم، تضمن عدم ضياع أي بيان أثناء الترحيل."""
    __tablename__ = "legacy_snapshots"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    sha256: Mapped[str] = mapped_column(String(64), unique=True)
    data: Mapped[dict] = mapped_column(JSON)
    imported_by: Mapped[str] = mapped_column(String(32), default="")
    summary: Mapped[dict] = mapped_column(JSON, default=dict)

# ===================== المرحلة 2: العقود والمستخلصات والضمانات =====================
class Contract(Base):
    __tablename__ = "contracts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    kind: Mapped[str] = mapped_column(String(20))               # client | subcontractor | supplier
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    party_id: Mapped[str] = mapped_column(ForeignKey("parties.id"))
    title: Mapped[str] = mapped_column(String(300))
    original_value: Mapped[Decimal] = mapped_column(Money)      # لا تتغير بعد التفعيل؛ التغييرات عبر أوامر التغيير
    start_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    advance_pct: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    retention_pct: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    tax_pct: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    payment_days: Mapped[int] = mapped_column(Integer, default=30)
    penalty_terms: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="draft")     # draft|active|completed|terminated
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (CheckConstraint("kind in ('client','subcontractor','supplier')", name="ck_contract_kind"),
                      CheckConstraint("original_value >= 0", name="ck_contract_value"),
                      CheckConstraint("advance_pct between 0 and 100 and retention_pct between 0 and 100 and tax_pct between 0 and 100", name="ck_contract_pct"))

class ChangeOrder(Base):
    __tablename__ = "change_orders"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    contract_id: Mapped[str] = mapped_column(ForeignKey("contracts.id"))
    no: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(300))
    reason: Mapped[str] = mapped_column(Text)
    items: Mapped[list] = mapped_column(JSON, default=list)           # بنود وكميات
    amount: Mapped[Decimal] = mapped_column(Money)                    # موجب إضافة، سالب خصم
    time_days: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|tech_review|fin_review|approval|approved|rejected
    history: Mapped[list] = mapped_column(JSON, default=list)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (UniqueConstraint("contract_id", "no", name="uq_co_no"),)

class Invoice(Base):
    __tablename__ = "invoices"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    contract_id: Mapped[str] = mapped_column(ForeignKey("contracts.id"))
    no: Mapped[int] = mapped_column(Integer)
    date: Mapped[_date] = mapped_column(Date)
    description: Mapped[str] = mapped_column(String(300), default="")
    final: Mapped[bool] = mapped_column(Boolean, default=False)       # ختامي
    gross: Mapped[Decimal] = mapped_column(Money)
    advance: Mapped[Decimal] = mapped_column(Money, default=0)
    retention: Mapped[Decimal] = mapped_column(Money, default=0)
    tax: Mapped[Decimal] = mapped_column(Money, default=0)
    other: Mapped[Decimal] = mapped_column(Money, default=0)
    net: Mapped[Decimal] = mapped_column(Money)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|review|approved|submitted|rejected|cancelled
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    approved_by: Mapped[str] = mapped_column(String(32), default="")
    history: Mapped[list] = mapped_column(JSON, default=list)
    __table_args__ = (UniqueConstraint("contract_id", "no", name="uq_inv_no"),
                      CheckConstraint("gross > 0 and net >= 0 and advance >= 0 and retention >= 0 and tax >= 0 and other >= 0", name="ck_inv_amounts"))

class Payment(Base):
    """سند قبض (للعميل) أو سند صرف (للمقاول)، مرتبط بمستخلص وبقيد."""
    __tablename__ = "payments"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    invoice_id: Mapped[str] = mapped_column(ForeignKey("invoices.id"))
    date: Mapped[_date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Money)
    method: Mapped[str] = mapped_column(String(20), default="bank")   # cash|bank|cheque
    ref: Mapped[str] = mapped_column(String(100), default="")
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (CheckConstraint("amount > 0", name="ck_pay_amount"),)

class AdvancePayment(Base):
    """دفعة مقدمة فعلية: مقبوضة من العميل (دائن 2200) أو مدفوعة لمقاول الباطن (مدين 1410)."""
    __tablename__ = "advance_payments"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    contract_id: Mapped[str] = mapped_column(ForeignKey("contracts.id"))
    date: Mapped[_date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Money)
    method: Mapped[str] = mapped_column(String(20), default="bank")
    ref: Mapped[str] = mapped_column(String(100), default="")
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    reversed: Mapped[bool] = mapped_column(Boolean, default=False)
    reverse_entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    reverse_reason: Mapped[str] = mapped_column(String(300), default="")
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (CheckConstraint("amount > 0", name="ck_adv_amount"),)

class Guarantee(Base):
    __tablename__ = "guarantees"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    kind: Mapped[str] = mapped_column(String(20))        # bid|performance|advance|insurance
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    contract_id: Mapped[str | None] = mapped_column(ForeignKey("contracts.id"), nullable=True)
    party_id: Mapped[str | None] = mapped_column(ForeignKey("parties.id"), nullable=True)
    bank: Mapped[str] = mapped_column(String(120), default="")
    ref: Mapped[str] = mapped_column(String(80), default="")
    amount: Mapped[Decimal] = mapped_column(Money)
    remaining: Mapped[Decimal] = mapped_column(Money)
    issue_date: Mapped[_date] = mapped_column(Date)
    expiry_date: Mapped[_date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), default="active")   # active|renewed|released|claimed
    __table_args__ = (CheckConstraint("kind in ('bid','performance','advance','insurance')", name="ck_g_kind"),
                      CheckConstraint("amount > 0 and remaining >= 0 and remaining <= amount", name="ck_g_amount"),
                      CheckConstraint("expiry_date >= issue_date", name="ck_g_dates"))

# ===================== المرحلة 3: الموارد البشرية والرواتب =====================
class Employee(Base):
    __tablename__ = "employees"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    code: Mapped[str] = mapped_column(String(40), unique=True)       # نفس رقم الموظف في AKT Attendance (مفتاح الربط)
    name: Mapped[str] = mapped_column(String(200))
    job: Mapped[str] = mapped_column(String(120), default="")
    dept: Mapped[str] = mapped_column(String(80), default="")
    national_id: Mapped[str] = mapped_column(String(20), default="")
    phone: Mapped[str] = mapped_column(String(60), default="")
    hire_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    basic: Mapped[Decimal] = mapped_column(Money, default=0)
    allowances: Mapped[Decimal] = mapped_column(Money, default=0)
    insured: Mapped[bool] = mapped_column(Boolean, default=True)
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")   # active|suspended|terminated
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("basic >= 0 and allowances >= 0", name="ck_emp_pay"),
                      CheckConstraint("status in ('active','suspended','terminated')", name="ck_emp_status"))

class EmployeeLoan(Base):
    __tablename__ = "employee_loans"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    employee_id: Mapped[str] = mapped_column(ForeignKey("employees.id"))
    amount: Mapped[Decimal] = mapped_column(Money)
    monthly: Mapped[Decimal] = mapped_column(Money)
    repaid: Mapped[Decimal] = mapped_column(Money, default=0)
    note: Mapped[str] = mapped_column(String(300), default="")
    __table_args__ = (CheckConstraint("amount > 0 and monthly > 0 and repaid >= 0 and repaid <= amount", name="ck_loan"),)

class AttendanceImport(Base):
    __tablename__ = "attendance_imports"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    source: Mapped[str] = mapped_column(String(60))
    sha256: Mapped[str] = mapped_column(String(64), unique=True)       # يمنع استيراد نفس الدفعة مرتين
    rows_total: Mapped[int] = mapped_column(Integer, default=0)
    rows_new: Mapped[int] = mapped_column(Integer, default=0)
    rows_updated: Mapped[int] = mapped_column(Integer, default=0)
    rows_rejected: Mapped[int] = mapped_column(Integer, default=0)
    rejected: Mapped[list] = mapped_column(JSON, default=list)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

class AttendanceRecord(Base):
    """ملخص يومي مستورد من AKT Attendance فقط؛ لا يوجد إدخال حضور داخل هذا النظام."""
    __tablename__ = "attendance_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    employee_id: Mapped[str] = mapped_column(ForeignKey("employees.id"))
    date: Mapped[_date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(12))        # present|absent|leave|holiday
    hours: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    overtime_hours: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    import_id: Mapped[str] = mapped_column(ForeignKey("attendance_imports.id"))
    __table_args__ = (UniqueConstraint("employee_id", "date", name="uq_att_day"),
                      CheckConstraint("status in ('present','absent','leave','holiday')", name="ck_att_status"),
                      CheckConstraint("hours >= 0 and overtime_hours >= 0", name="ck_att_hours"))

class PayrollSetting(Base):
    __tablename__ = "payroll_settings"
    key: Mapped[str] = mapped_column(String(40), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)

class PayrollRun(Base):
    __tablename__ = "payroll_runs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    month: Mapped[str] = mapped_column(String(7), unique=True)         # YYYY-MM
    status: Mapped[str] = mapped_column(String(12), default="draft")   # draft|approved|paid
    params: Mapped[dict] = mapped_column(JSON, default=dict)           # نسخة المعاملات وقت الاحتساب
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    pay_entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    approved_by: Mapped[str] = mapped_column(String(32), default="")
    lines: Mapped[list["PayrollLine"]] = relationship(cascade="all, delete-orphan", lazy="selectin")

class PayrollLine(Base):
    __tablename__ = "payroll_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(ForeignKey("payroll_runs.id", ondelete="CASCADE"))
    employee_id: Mapped[str] = mapped_column(ForeignKey("employees.id"))
    absent_days: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    overtime_hours: Mapped[Decimal] = mapped_column(Numeric(6, 2), default=0)
    bonus: Mapped[Decimal] = mapped_column(Money, default=0)
    penalty: Mapped[Decimal] = mapped_column(Money, default=0)
    base: Mapped[Decimal] = mapped_column(Money, default=0)
    absence_ded: Mapped[Decimal] = mapped_column(Money, default=0)
    overtime_pay: Mapped[Decimal] = mapped_column(Money, default=0)
    gross: Mapped[Decimal] = mapped_column(Money, default=0)
    emp_ins: Mapped[Decimal] = mapped_column(Money, default=0)
    er_ins: Mapped[Decimal] = mapped_column(Money, default=0)
    tax: Mapped[Decimal] = mapped_column(Money, default=0)
    loan: Mapped[Decimal] = mapped_column(Money, default=0)
    net: Mapped[Decimal] = mapped_column(Money, default=0)
    __table_args__ = (UniqueConstraint("run_id", "employee_id", name="uq_pl_emp"),)

# ===================== المرحلة 4: المشتريات والمخزون =====================
Qty = Numeric(18, 3)

class Item(Base):
    __tablename__ = "items"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    unit: Mapped[str] = mapped_column(String(20), default="")
    min_stock: Mapped[Decimal] = mapped_column(Qty, default=0)
    qty: Mapped[Decimal] = mapped_column(Qty, default=0)
    value: Mapped[Decimal] = mapped_column(Money, default=0)       # القيمة الدفترية (متوسط مرجح)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("qty >= 0 and value >= 0 and min_stock >= 0", name="ck_item_nonneg"),)

class StockMovement(Base):
    __tablename__ = "stock_movements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id"))
    kind: Mapped[str] = mapped_column(String(10))          # in | out | adjust
    qty: Mapped[Decimal] = mapped_column(Qty)              # موجب للداخل، سالب للخارج
    amount: Mapped[Decimal] = mapped_column(Money)         # قيمة الحركة بنفس الإشارة
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    ref: Mapped[str] = mapped_column(String(80), default="")
    note: Mapped[str] = mapped_column(String(300), default="")
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

class PurchaseRequest(Base):
    __tablename__ = "purchase_requests"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    lines: Mapped[list] = mapped_column(JSON, default=list)       # [{item_id, qty, note}]
    status: Mapped[str] = mapped_column(String(12), default="pending")   # pending|approved|rejected|ordered
    note: Mapped[str] = mapped_column(String(400), default="")
    created_by: Mapped[str] = mapped_column(String(32), default="")
    decided_by: Mapped[str] = mapped_column(String(32), default="")

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    supplier_id: Mapped[str] = mapped_column(ForeignKey("parties.id"))
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    request_id: Mapped[str | None] = mapped_column(ForeignKey("purchase_requests.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(12), default="draft")   # draft|approved|closed|cancelled
    total: Mapped[Decimal] = mapped_column(Money, default=0)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    approved_by: Mapped[str] = mapped_column(String(32), default="")
    lines: Mapped[list["POLine"]] = relationship(cascade="all, delete-orphan", lazy="selectin")

class POLine(Base):
    __tablename__ = "po_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.id", ondelete="CASCADE"))
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id"))
    qty: Mapped[Decimal] = mapped_column(Qty)
    price: Mapped[Decimal] = mapped_column(Money)
    received: Mapped[Decimal] = mapped_column(Qty, default=0)
    __table_args__ = (CheckConstraint("qty > 0 and price >= 0 and received >= 0 and received <= qty", name="ck_poline"),)

class SupplierInvoice(Base):
    __tablename__ = "supplier_invoices"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    po_id: Mapped[str] = mapped_column(ForeignKey("purchase_orders.id"))
    ref: Mapped[str] = mapped_column(String(80))
    date: Mapped[_date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Money)
    paid: Mapped[Decimal] = mapped_column(Money, default=0)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (UniqueConstraint("po_id", "ref", name="uq_sinv_ref"),
                      CheckConstraint("amount > 0 and paid >= 0 and paid <= amount", name="ck_sinv"))

# ===================== المرحلة 6: المقايسات والجدول الزمني =====================
class BoqItem(Base):
    __tablename__ = "boq_items"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    section: Mapped[str] = mapped_column(String(120), default="")
    description: Mapped[str] = mapped_column(String(400))
    unit: Mapped[str] = mapped_column(String(30), default="")
    qty: Mapped[Decimal] = mapped_column(Qty)
    price: Mapped[Decimal] = mapped_column(Money)
    done: Mapped[Decimal] = mapped_column(Qty, default=0)          # الكمية المنفذة
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint("qty >= 0 and price >= 0 and done >= 0", name="ck_boq_nonneg"),)

class ScheduleTask(Base):
    __tablename__ = "schedule_tasks"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    name: Mapped[str] = mapped_column(String(300))
    start: Mapped[_date] = mapped_column(Date)
    end: Mapped[_date] = mapped_column(Date)
    progress: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0)
    predecessor_id: Mapped[str | None] = mapped_column(ForeignKey("schedule_tasks.id"), nullable=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint('"end" >= "start"', name="ck_task_dates"),
                      CheckConstraint("progress between 0 and 100", name="ck_task_prog"))

# ===================== المرحلة 7: الجودة والتسليم والمناقصات =====================
class Inspection(Base):
    __tablename__ = "inspections"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    item: Mapped[str] = mapped_column(String(300))
    kind: Mapped[str] = mapped_column(String(10))                 # work | material
    date: Mapped[_date] = mapped_column(Date)
    inspector: Mapped[str] = mapped_column(String(120), default="")
    status: Mapped[str] = mapped_column(String(20), default="pending")   # pending|accepted|accepted_notes|rejected
    note: Mapped[str] = mapped_column(Text, default="")
    decided_by: Mapped[str] = mapped_column(String(32), default="")
    created_by: Mapped[str] = mapped_column(String(32), default="")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    __table_args__ = (CheckConstraint("kind in ('work','material')", name="ck_insp_kind"),
                      CheckConstraint("status in ('pending','accepted','accepted_notes','rejected')", name="ck_insp_status"))

class Snag(Base):
    __tablename__ = "snags"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    inspection_id: Mapped[str | None] = mapped_column(ForeignKey("inspections.id"), nullable=True)
    location: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(10))             # low|medium|high
    due: Mapped[_date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(10), default="open")      # open|closed
    responsible: Mapped[str] = mapped_column(String(200), default="")
    opened: Mapped[_date] = mapped_column(Date)
    closed: Mapped[_date | None] = mapped_column(Date, nullable=True)
    closure_note: Mapped[str] = mapped_column(Text, default="")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("severity in ('low','medium','high')", name="ck_snag_sev"),
                      CheckConstraint("status in ('open','closed')", name="ck_snag_status"))

class Handover(Base):
    __tablename__ = "handovers"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    kind: Mapped[str] = mapped_column(String(10))                 # initial | final
    status: Mapped[str] = mapped_column(String(12), default="in_progress")   # in_progress | done
    date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    warranty_months: Mapped[int] = mapped_column(Integer, default=0)
    checks: Mapped[dict] = mapped_column(JSON, default=dict)      # {"0": true, ...}
    override_reason: Mapped[str] = mapped_column(String(300), default="")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (UniqueConstraint("project_id", "kind", name="uq_handover_kind"),
                      CheckConstraint("kind in ('initial','final')", name="ck_ho_kind"),
                      CheckConstraint("status in ('in_progress','done')", name="ck_ho_status"),
                      CheckConstraint("warranty_months between 0 and 120", name="ck_ho_warranty"))

class Tender(Base):
    __tablename__ = "tenders"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    name: Mapped[str] = mapped_column(String(300))
    client_id: Mapped[str | None] = mapped_column(ForeignKey("parties.id"), nullable=True)
    type: Mapped[str] = mapped_column(String(80), default="")
    due: Mapped[_date | None] = mapped_column(Date, nullable=True)
    value: Mapped[Decimal] = mapped_column(Money, default=0)      # سعر العرض
    cost: Mapped[Decimal] = mapped_column(Money, default=0)       # التكلفة المقدرة
    stage: Mapped[str] = mapped_column(String(12), default="study")   # study|submitted|negotiation|won|lost
    note: Mapped[str] = mapped_column(Text, default="")
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint("value >= 0 and cost >= 0", name="ck_tender_amounts"),
                      CheckConstraint("stage in ('study','submitted','negotiation','won','lost')", name="ck_tender_stage"))

# ===================== المرحلة 8: الموقع والمعدات والعمالة والعهد =====================
class DailyReport(Base):
    __tablename__ = "daily_reports"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    date: Mapped[_date] = mapped_column(Date)
    weather: Mapped[str] = mapped_column(String(40), default="")
    workers_count: Mapped[int] = mapped_column(Integer, default=0)
    work: Mapped[str] = mapped_column(Text)
    issues: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[str] = mapped_column(String(32), default="")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (UniqueConstraint("project_id", "date", name="uq_daily_report"), CheckConstraint("workers_count >= 0", name="ck_dr_workers"))

class SafetyRecord(Base):
    __tablename__ = "safety_records"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    date: Mapped[_date] = mapped_column(Date)
    kind: Mapped[str] = mapped_column(String(12))           # inspection | accident | near_miss
    severity: Mapped[str] = mapped_column(String(8))        # low | medium | high
    description: Mapped[str] = mapped_column(Text)
    action: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(8), default="open")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("kind in ('inspection','accident','near_miss')", name="ck_saf_kind"),
                      CheckConstraint("severity in ('low','medium','high')", name="ck_saf_sev"),
                      CheckConstraint("status in ('open','closed')", name="ck_saf_status"))

class SiteDocument(Base):
    __tablename__ = "site_documents"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    doc_type: Mapped[str] = mapped_column(String(60))
    name: Mapped[str] = mapped_column(String(300))
    issue_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    expiry_date: Mapped[_date | None] = mapped_column(Date, nullable=True)
    attachment_id: Mapped[str | None] = mapped_column(ForeignKey("attachments.id"), nullable=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint("expiry_date is null or issue_date is null or expiry_date >= issue_date", name="ck_doc_dates"),)

class Risk(Base):
    __tablename__ = "risks"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    description: Mapped[str] = mapped_column(Text)
    prob: Mapped[int] = mapped_column(Integer)
    impact: Mapped[int] = mapped_column(Integer)
    owner: Mapped[str] = mapped_column(String(120), default="")
    mitigation: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(10), default="open")    # open | mitigated | closed
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("prob between 1 and 5 and impact between 1 and 5", name="ck_risk_scale"),
                      CheckConstraint("status in ('open','mitigated','closed')", name="ck_risk_status"))

class Correspondence(Base):
    __tablename__ = "correspondence"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    direction: Mapped[str] = mapped_column(String(4))        # in | out
    ref_no: Mapped[str] = mapped_column(String(60))
    date: Mapped[_date] = mapped_column(Date)
    party: Mapped[str] = mapped_column(String(200))
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    subject: Mapped[str] = mapped_column(String(400))
    due: Mapped[_date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(8), default="open")
    closure_note: Mapped[str] = mapped_column(Text, default="")
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (UniqueConstraint("direction", "ref_no", name="uq_corr_ref"),
                      CheckConstraint("direction in ('in','out')", name="ck_corr_dir"),
                      CheckConstraint("status in ('open','closed')", name="ck_corr_status"))

class Equipment(Base):
    __tablename__ = "equipment"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    name: Mapped[str] = mapped_column(String(200), unique=True)
    type: Mapped[str] = mapped_column(String(60), default="")
    daily_rate: Mapped[Decimal] = mapped_column(Money, default=0)
    status: Mapped[str] = mapped_column(String(12), default="working")   # working | maintenance | idle
    maint_interval_days: Mapped[int] = mapped_column(Integer, default=90)
    last_maint: Mapped[_date | None] = mapped_column(Date, nullable=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("daily_rate >= 0 and maint_interval_days > 0", name="ck_eq_vals"),
                      CheckConstraint("status in ('working','maintenance','idle')", name="ck_eq_status"))

class EquipmentUsage(Base):
    __tablename__ = "equipment_usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    equipment_id: Mapped[str] = mapped_column(ForeignKey("equipment.id"))
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    date: Mapped[_date] = mapped_column(Date)
    days: Mapped[Decimal] = mapped_column(Numeric(6, 2))
    rate: Mapped[Decimal] = mapped_column(Money)               # سعر اليوم وقت التسجيل
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    __table_args__ = (UniqueConstraint("equipment_id", "project_id", "date", name="uq_eq_usage"), CheckConstraint("days > 0", name="ck_equ_days"))

class Worker(Base):
    __tablename__ = "workers"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    name: Mapped[str] = mapped_column(String(200))
    trade: Mapped[str] = mapped_column(String(80), default="")
    daily_rate: Mapped[Decimal] = mapped_column(Money)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("daily_rate >= 0", name="ck_worker_rate"),)

class LaborDay(Base):
    __tablename__ = "labor_days"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    worker_id: Mapped[str] = mapped_column(ForeignKey("workers.id"))
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    date: Mapped[_date] = mapped_column(Date)
    days: Mapped[Decimal] = mapped_column(Numeric(4, 2))
    rate: Mapped[Decimal] = mapped_column(Money)               # أجر اليوم وقت التسجيل
    paid: Mapped[bool] = mapped_column(Boolean, default=False)
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    legacy_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    __table_args__ = (UniqueConstraint("worker_id", "date", name="uq_labor_day"), CheckConstraint("days > 0 and days <= 2", name="ck_labor_days"))

class Custody(Base):
    __tablename__ = "custodies"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    person: Mapped[str] = mapped_column(String(200))
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    amount: Mapped[Decimal] = mapped_column(Money)
    date: Mapped[_date] = mapped_column(Date)
    settled: Mapped[bool] = mapped_column(Boolean, default=False)
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    settle_entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    __table_args__ = (CheckConstraint("amount > 0", name="ck_cust_amount"),)

class CustodyExpense(Base):
    __tablename__ = "custody_expenses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    custody_id: Mapped[str] = mapped_column(ForeignKey("custodies.id"))
    date: Mapped[_date] = mapped_column(Date)
    category: Mapped[str] = mapped_column(String(10))          # materials | labor | equipment | admin | other
    description: Mapped[str] = mapped_column(String(300))
    amount: Mapped[Decimal] = mapped_column(Money)
    entry_id: Mapped[str | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    __table_args__ = (CheckConstraint("amount > 0", name="ck_custexp_amount"),)


# ---------------- التقييمات وطلبات الأسعار والجرد ----------------
class Rating(Base):
    __tablename__ = "ratings"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    party_id: Mapped[str] = mapped_column(ForeignKey("parties.id"))
    date: Mapped[_date] = mapped_column(Date)
    quality: Mapped[int] = mapped_column(Integer)
    punctuality: Mapped[int] = mapped_column(Integer)
    price: Mapped[int] = mapped_column(Integer)
    note: Mapped[str] = mapped_column(String(500), default="")
    created_by: Mapped[str] = mapped_column(String(32), default="")
    legacy_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    __table_args__ = (CheckConstraint("quality between 1 and 5 and punctuality between 1 and 5 and price between 1 and 5", name="ck_rating_range"),)

class Rfq(Base):
    __tablename__ = "rfqs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    item: Mapped[str] = mapped_column(String(300))
    unit: Mapped[str] = mapped_column(String(20), default="")
    qty: Mapped[Decimal] = mapped_column(Qty)
    project_id: Mapped[str | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(12), default="open")            # open | awarded | cancelled
    awarded_party_id: Mapped[str | None] = mapped_column(ForeignKey("parties.id"), nullable=True)
    award_note: Mapped[str] = mapped_column(String(300), default="")
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    legacy_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    quotes: Mapped[list["RfqQuote"]] = relationship(cascade="all, delete-orphan", lazy="selectin")
    __table_args__ = (CheckConstraint("qty > 0", name="ck_rfq_qty"),)

class RfqQuote(Base):
    __tablename__ = "rfq_quotes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rfq_id: Mapped[str] = mapped_column(ForeignKey("rfqs.id"))
    party_id: Mapped[str] = mapped_column(ForeignKey("parties.id"))
    price: Mapped[Decimal] = mapped_column(Money)
    note: Mapped[str] = mapped_column(String(300), default="")
    __table_args__ = (UniqueConstraint("rfq_id", "party_id", name="uq_rfq_quote"), CheckConstraint("price > 0", name="ck_rfq_price"))

class StockCount(Base):
    __tablename__ = "stock_counts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_id)
    no: Mapped[int] = mapped_column(Integer, unique=True)
    date: Mapped[_date] = mapped_column(Date)
    note: Mapped[str] = mapped_column(String(300), default="")
    status: Mapped[str] = mapped_column(String(12), default="draft")          # draft | approved | cancelled
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[str] = mapped_column(String(32), default="")
    approved_by: Mapped[str | None] = mapped_column(String(32), nullable=True)
    lines: Mapped[list["StockCountLine"]] = relationship(cascade="all, delete-orphan", lazy="selectin")

class StockCountLine(Base):
    __tablename__ = "stock_count_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    count_id: Mapped[str] = mapped_column(ForeignKey("stock_counts.id"))
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id"))
    system_qty: Mapped[Decimal] = mapped_column(Qty)                          # رصيد النظام وقت بدء الجرد
    counted_qty: Mapped[Decimal | None] = mapped_column(Qty, nullable=True)
    unit_cost: Mapped[Decimal | None] = mapped_column(Money, nullable=True)   # للزيادة على صنف رصيده صفر فقط
    __table_args__ = (UniqueConstraint("count_id", "item_id", name="uq_count_item"), CheckConstraint("counted_qty is null or counted_qty >= 0", name="ck_count_nonneg"))


class BudgetLine(Base):
    """موازنة تقديرية للمشروع بحسب فئة التكلفة؛ المنفَّذ الفعلي يُقرأ من دفتر الأستاذ لا من هذا الجدول."""
    __tablename__ = "budget_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"))
    category: Mapped[str] = mapped_column(String(20))            # materials|subcontractors|labor|equipment|admin|other
    amount: Mapped[Decimal] = mapped_column(Money)
    note: Mapped[str] = mapped_column(String(300), default="")
    __table_args__ = (UniqueConstraint("project_id", "category", name="uq_budget_cat"), CheckConstraint("amount >= 0", name="ck_budget_amount"))
