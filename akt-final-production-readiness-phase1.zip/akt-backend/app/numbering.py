import zlib
from sqlalchemy import text, func, select

def next_no(db, col, *where, scope: str = ""):
    """رقم تسلسلي آمن مع تعدد المستخدمين.
    PostgreSQL لا يسمح بـ FOR UPDATE مع الدوال التجميعية، فنأخذ قفلًا استشاريًا على مستوى المعاملة
    (يُحرَّر تلقائيًا عند commit/rollback)، وقيد UNIQUE في الجدول خط دفاع أخير."""
    if db.bind.dialect.name == "postgresql":
        key = zlib.crc32(f"{col}:{scope}".encode()) & 0x7FFFFFFF
        db.execute(text("select pg_advisory_xact_lock(:k)"), {"k": key})
    q = select(func.max(col))
    if where: q = q.where(*where)
    return (db.execute(q).scalar() or 0) + 1
