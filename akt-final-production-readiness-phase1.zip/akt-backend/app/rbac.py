from sqlalchemy import select
from .models import Permission, Role

MODULES = {
  "projects": ["view","create","update","delete","approve","export"],
  "parties":  ["view","create","update","delete","export"],
  "ledger":   ["view","create","reverse","close","export"],
  "users":    ["view","manage"],
  "audit":    ["view"],
  "backup":   ["run","restore"],
  "legacy":   ["import"],
  "files":    ["view","upload","delete"],
  "export":   ["use"],
  "contracts": ["view","create","update","approve"],
  "changeorders": ["view","create","review_tech","review_fin","approve"],
  "invoices": ["view","create","review","approve","approve_high","submit"],
  "payments": ["create"],
  "guarantees": ["view","create","update"],
  "cashflow": ["view"],
  "reports":  ["view"],
  "employees": ["view","salary","create","update"],
  "attendance": ["view","import"],
  "payroll":  ["view","create","approve","pay","settings"],
  "boq":      ["view","create","update","delete","import"],
  "schedule": ["view","create","update","delete"],
  "quality":  ["view","create","decide","close","delete"],
  "handover": ["view","create","check","complete","override"],
  "tenders":  ["view","create","update","convert","delete"],
  "site":     ["view","create","update"],
  "risks":    ["view","create","update"],
  "docs":     ["view","create","update","delete"],
  "equipment": ["view","create","update","usage"],
  "labor":    ["view","create","record","pay"],
  "custody":  ["view","create","expense","settle"],
  "ratings":  ["view","create"],
  "budget":   ["view","edit"],
  "rfq":      ["view","create","update"],
  "stockcount": ["view","create","approve"],
  "executive": ["view","export"],
  "items":    ["view","create","update"],
  "stock":    ["view","issue","adjust"],
  "purchasing": ["pr_create","pr_approve","po_create","po_approve","po_approve_high","receive","invoice","pay"],
}
ALL = [f"{m}.{a}" for m, acts in MODULES.items() for a in acts]

# مطابقة أدوار النظام القديم (مدير / محاسب / أمين مخزن / مهندس موقع)
ROLE_PERMS = {
  "admin": ALL,
  "accountant": ["export.use","projects.view","projects.export","parties.view","parties.create","parties.update","parties.export",
                 "ledger.view","ledger.create","ledger.reverse","ledger.export","files.view","files.upload",
                 "contracts.view","contracts.create","changeorders.view","changeorders.review_fin","invoices.view","invoices.create",
                 "invoices.review","invoices.approve","invoices.submit","payments.create","guarantees.view","guarantees.create",
                 "guarantees.update","cashflow.view","reports.view",
                 "employees.view","employees.salary","employees.create","employees.update","attendance.view","attendance.import","payroll.view","payroll.create",
                 "items.view","stock.view","purchasing.po_create","purchasing.invoice","purchasing.pay",
                 "boq.view","schedule.view","quality.view","handover.view","tenders.view","tenders.create","tenders.update",
                 "site.view","risks.view","docs.view","equipment.view","labor.view","labor.pay","custody.view","custody.create","custody.expense","custody.settle",
                 "budget.view","budget.edit","ratings.view","ratings.create","rfq.view","rfq.create","rfq.update","stockcount.view","stockcount.approve"],
  "storekeeper": ["export.use","projects.view","parties.view","files.view","files.upload",
                 "items.view","items.create","items.update","stock.view","stock.issue","purchasing.pr_create","purchasing.receive","stockcount.view","stockcount.create","rfq.view"],
  "site_engineer": ["export.use","projects.view","projects.update","parties.view","files.view","files.upload",
                    "contracts.view","changeorders.view","changeorders.create","changeorders.review_tech","attendance.view","employees.view","items.view","stock.view","purchasing.pr_create",
                    "boq.view","boq.create","boq.update","boq.import","schedule.view","schedule.create","schedule.update","schedule.delete","quality.view","quality.create","quality.decide","quality.close",
                    "budget.view","ratings.view","ratings.create","handover.view","handover.create","handover.check","site.view","site.create","site.update","risks.view","risks.create","risks.update",
                    "docs.view","docs.create","equipment.view","equipment.usage","labor.view","labor.record","custody.view","custody.expense","invoices.view","invoices.create","invoices.review"],
}

def seed_rbac(db):
    have = {p.code: p for p in db.execute(select(Permission)).scalars()}
    for c in ALL:
        if c not in have:
            p = Permission(code=c, label=c); db.add(p); have[c] = p
    db.flush()
    roles = {r.name: r for r in db.execute(select(Role)).scalars()}
    for name, codes in ROLE_PERMS.items():
        r = roles.get(name) or Role(name=name)
        r.perms = [have[c] for c in codes]
        db.add(r)
    db.flush()
