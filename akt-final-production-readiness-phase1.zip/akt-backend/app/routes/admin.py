import hashlib, json, os, re
from datetime import date, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from sqlalchemy import select, delete
from ..db import get_db, Base
from ..models import AuditLog, LegacySnapshot, Attachment, Project, Party, Account
from ..deps import need
from ..config import settings
from .. import audit
from ..legacy import import_legacy

router = APIRouter(tags=["admin"])

@router.get("/audit")
def audit_list(entity: str = "", entity_id: str = "", limit: int = 200, db=Depends(get_db), _=Depends(need("audit.view"))):
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(min(limit, 1000))
    if entity: q = q.where(AuditLog.entity == entity)
    if entity_id: q = q.where(AuditLog.entity_id == entity_id)
    return [{c.name: getattr(a, c.name) for c in AuditLog.__table__.columns} for a in db.execute(q).scalars()]

@router.get("/audit/verify")
def audit_verify(db=Depends(get_db), _=Depends(need("audit.view"))):
    return audit.verify_chain(db)

@router.post("/legacy/import", status_code=201)
def legacy(payload: dict, request: Request, db=Depends(get_db), u=Depends(need("legacy.import"))):
    """يستورد نسخة JSON من النظام الحالي: تُحفظ كاملة كما هي، ثم تُنشأ السجلات المنظمة منها. الاستيراد قابل للتكرار بلا تكرار سجلات."""
    if not isinstance(payload.get("projects"), list):
        raise HTTPException(422, "الملف ليس نسخة احتياطية صالحة من نظام Akt Group")
    summary = import_legacy(db, payload, u)
    audit.log(db, u, "legacy.import", "legacy_snapshot", summary["snapshot_id"], after=summary, request=request)
    return summary

# ---------- نسخ احتياطي واستعادة ----------
def _ser(v):
    if isinstance(v, Decimal): return str(v)
    if isinstance(v, (datetime, date)): return v.isoformat()
    return v

def dump(db) -> dict:
    out = {}
    for t in Base.metadata.sorted_tables:
        out[t.name] = [{c.name: _ser(r[c.name]) for c in t.columns} for r in db.execute(select(t)).mappings()]
    body = json.dumps(out, sort_keys=True, ensure_ascii=False)
    return {"created": datetime.now().astimezone().isoformat(), "sha256": hashlib.sha256(body.encode()).hexdigest(), "tables": out}

def _py(col, v):
    if v is None: return None
    t = col.type.python_type
    if t is Decimal: return Decimal(v)
    if t is datetime: return datetime.fromisoformat(v)
    if t is date: return date.fromisoformat(v)
    return v

def restore(db, data: dict):
    body = json.dumps(data["tables"], sort_keys=True, ensure_ascii=False)
    if hashlib.sha256(body.encode()).hexdigest() != data["sha256"]:
        raise HTTPException(422, "بصمة النسخة الاحتياطية لا تطابق محتواها، الملف تالف أو معدّل")
    for t in reversed(Base.metadata.sorted_tables):
        db.execute(delete(t))
    for t in Base.metadata.sorted_tables:
        rows = [{c.name: _py(c, r[c.name]) for c in t.columns} for r in data["tables"].get(t.name, [])]
        if rows: db.execute(t.insert(), rows)

@router.post("/admin/backup")
def backup(request: Request, db=Depends(get_db), u=Depends(need("backup.run"))):
    d = dump(db)
    audit.log(db, u, "backup.run", "backup", d["sha256"][:12], request=request)
    return d

@router.post("/admin/restore")
def do_restore(data: dict, reason: str, request: Request, db=Depends(get_db), u=Depends(need("backup.restore"))):
    if not reason.strip(): raise HTTPException(422, "سبب الاستعادة مطلوب")
    restore(db, data)
    # بعد الاستعادة نسجل العملية في السجل الجديد
    audit.log(db, u, "backup.restore", "backup", data["sha256"][:12], reason=reason, request=request)
    return {"ok": True}

# ---------- المرفقات ----------
@router.post("/files", status_code=201)
async def upload(entity: str, entity_id: str, file: UploadFile = File(...), request: Request = None,
                 db=Depends(get_db), u=Depends(need("files.upload"))):
    name = os.path.basename(file.filename or "")
    ext = os.path.splitext(name)[1].lower()
    if ext not in settings.allowed_ext:
        raise HTTPException(415, "نوع الملف غير مسموح")
    data = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, "حجم الملف أكبر من المسموح")
    if ext == ".pdf" and not data.startswith(b"%PDF"): raise HTTPException(415, "محتوى الملف لا يطابق امتداده")
    if ext == ".png" and not data.startswith(b"\x89PNG"): raise HTTPException(415, "محتوى الملف لا يطابق امتداده")
    if ext in (".jpg", ".jpeg") and not data.startswith(b"\xff\xd8"): raise HTTPException(415, "محتوى الملف لا يطابق امتداده")
    sha = hashlib.sha256(data).hexdigest()
    os.makedirs(settings.upload_dir, exist_ok=True)
    path = os.path.join(settings.upload_dir, sha + ext)             # اسم من البصمة: لا مسارات من المستخدم
    with open(path, "wb") as f: f.write(data)
    a = Attachment(entity=entity, entity_id=entity_id, filename=re.sub(r"[^\w.\- ]", "_", name)[:200], mime=file.content_type or "",
                   size=len(data), sha256=sha, path=path, uploaded_by=u.id)
    db.add(a); db.flush()
    audit.log(db, u, "files.upload", entity, entity_id, after={"file": a.filename, "sha256": sha, "size": a.size}, request=request)
    return {"id": a.id, "filename": a.filename, "sha256": sha, "size": a.size}
