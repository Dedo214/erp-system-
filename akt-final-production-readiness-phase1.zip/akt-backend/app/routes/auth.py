from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select, func
from ..db import get_db
from ..models import User, LoginAttempt
from ..security import verify_password, make_token, hash_password, _ph
from ..config import settings
from ..deps import current_user
from .. import audit

router = APIRouter(prefix="/auth", tags=["auth"])
_DUMMY = _ph.hash("dummy-password-for-timing")

class Login(BaseModel):
    username: str
    password: str

class ChangePw(BaseModel):
    old_password: str
    new_password: str

@router.post("/login")
def login(b: Login, request: Request, db=Depends(get_db)):
    ip = request.client.host if request.client else ""
    u = db.execute(select(User).where(User.username == b.username.strip().lower())).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    # رش كلمات المرور: حد للمحاولات الفاشلة من نفس العنوان بصرف النظر عن اسم المستخدم
    since = now - timedelta(minutes=10)
    if ip and db.execute(select(func.count()).select_from(LoginAttempt).where(LoginAttempt.ip == ip, LoginAttempt.ok == False, LoginAttempt.ts >= since)).scalar() >= settings.max_ip_failures:
        raise HTTPException(429, "محاولات فاشلة كثيرة من هذا العنوان، حاول بعد دقائق")
    if u and u.locked_until and u.locked_until.replace(tzinfo=timezone.utc) > now:
        db.add(LoginAttempt(username=b.username, ok=False, ip=ip)); db.commit()
        raise HTTPException(423, "الحساب مقفل مؤقتاً بسبب محاولات فاشلة، حاول لاحقاً")
    if not u: verify_password(_DUMMY, b.password)        # نفس زمن التحقق: لا يُعرف وجود المستخدم من سرعة الرد
    ok = bool(u and u.is_active and verify_password(u.password_hash, b.password))
    db.add(LoginAttempt(username=b.username, ok=ok, ip=ip))
    if not ok:
        if u:
            u.failed_attempts += 1
            if u.failed_attempts >= settings.max_failed_logins:
                u.locked_until = now + timedelta(minutes=settings.lock_minutes); u.failed_attempts = 0
                audit.log(db, u, "auth.locked", "user", u.id, request=request)
        db.commit()                       # نحفظ المحاولة الفاشلة حتى مع رفض الطلب
        raise HTTPException(401, "بيانات الدخول غير صحيحة")
    u.failed_attempts = 0; u.locked_until = None
    audit.log(db, u, "auth.login", "user", u.id, request=request)
    return {"token": make_token(u.id, u.token_version), "user": {"id": u.id, "username": u.username, "full_name": u.full_name,
            "roles": [r.name for r in u.roles], "permissions": sorted(u.permissions())}}

@router.get("/me")
def me(u: User = Depends(current_user)):
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "roles": [r.name for r in u.roles],
            "permissions": sorted(u.permissions())}

@router.post("/change-password")
def change_pw(b: ChangePw, request: Request, u: User = Depends(current_user), db=Depends(get_db)):
    if not verify_password(u.password_hash, b.old_password):
        raise HTTPException(400, "كلمة المرور الحالية غير صحيحة")
    try:
        u.password_hash = hash_password(b.new_password)
    except ValueError as e:
        raise HTTPException(422, str(e))
    u.token_version += 1                   # يُنهي كل الجلسات القديمة
    audit.log(db, u, "auth.password_changed", "user", u.id, request=request)
    return {"ok": True}
