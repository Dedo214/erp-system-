from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Project, BudgetLine, BoqItem, Account
from ..deps import need
from .. import audit
from .reports import balances

router = APIRouter(tags=["budget"])
Z = Decimal(0)
CATS = {"materials": ("5100", "المواد"), "subcontractors": ("5300", "مقاولو الباطن"), "labor": ("5200", "العمالة"),
        "equipment": ("5400", "المعدات"), "admin": ("5500", "المصروفات الإدارية"), "other": ("5900", "مصروفات أخرى")}
WARN = Decimal("0.9")

class Line(BaseModel):
    category: str
    amount: Decimal = Field(ge=0)
    note: str = Field(default="", max_length=300)

class BudgetIn(BaseModel):
    lines: list[Line] = Field(min_length=1, max_length=len(CATS))
    version: int
    reason: str = Field(default="", max_length=300)

def progress_pct(db, pid):
    """نسبة الإنجاز من المقايسة: قيمة المنفَّذ ÷ قيمة المقايسة. None إن لم توجد مقايسة."""
    tot, done = db.execute(select(func.coalesce(func.sum(BoqItem.qty * BoqItem.price), 0), func.coalesce(func.sum(BoqItem.done * BoqItem.price), 0))
                           .where(BoqItem.project_id == pid, BoqItem.deleted == False)).one()
    return (min(done / tot, Decimal(1)) if tot else None)

def build(db, p):
    b = balances(db, project_id=p.id)
    types = {a.code: a.type for a in db.execute(select(Account)).scalars()}
    spent = lambda code: (b.get(code, (Z, Z))[0] - b.get(code, (Z, Z))[1])
    bl = {l.category: l for l in db.execute(select(BudgetLine).where(BudgetLine.project_id == p.id)).scalars()}
    prog = progress_pct(db, p.id)
    rows = []
    for cat, (code, name) in CATS.items():
        bud = bl[cat].amount if cat in bl else Z; act = spent(code)
        used = (act / bud) if bud else None
        # توقع التكلفة عند الإنجاز: الفعلي ÷ نسبة الإنجاز (إن زاد الإنجاز عن 10%)، وإلا الأكبر من الموازنة والفعلي
        eac = (act / prog) if prog and prog >= Decimal("0.1") else max(bud, act)
        rows.append({"category": cat, "name": name, "account": code, "budget": bud, "actual": act, "variance": bud - act,
                     "used_pct": (used * 100).quantize(Decimal("0.1")) if used is not None else None,
                     "forecast": eac.quantize(Decimal("0.01")), "status": "over" if bud and act > bud else ("warn" if bud and act >= bud * WARN else ("unbudgeted" if act and not bud else "ok")),
                     "note": bl[cat].note if cat in bl else ""})
    mapped = {code for code, _ in CATS.values()}
    other_cost = sum((d - c for k, (d, c) in b.items() if types.get(k) == "expense" and k not in mapped), Z)
    tb, ta = sum((r["budget"] for r in rows), Z), sum((r["actual"] for r in rows), Z) + other_cost
    tf = sum((r["forecast"] for r in rows), Z) + other_cost
    base = p.contract_value
    return {"project_id": p.id, "project": p.name, "version": p.version, "rows": rows, "unmapped_cost": other_cost,
            "total_budget": tb, "total_actual": ta, "total_variance": tb - ta, "used_pct": (ta / tb * 100).quantize(Decimal("0.1")) if tb else None,
            "progress_pct": (prog * 100).quantize(Decimal("0.1")) if prog is not None else None,
            "forecast_total": tf, "forecast_basis": "الفعلي ÷ نسبة الإنجاز من المقايسة" if prog and prog >= Decimal("0.1") else "الأكبر من الموازنة والفعلي (الإنجاز أقل من 10% أو لا مقايسة)",
            "contract_value": base, "planned_profit": base - tb if base else None, "forecast_profit": base - tf if base else None}

@router.get("/projects/{pid}/budget")
def get_budget(pid: str, db=Depends(get_db), _=Depends(need("budget.view"))):
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(404, "المشروع غير موجود")
    return build(db, p)

@router.put("/projects/{pid}/budget")
def set_budget(pid: str, b: BudgetIn, request: Request, db=Depends(get_db), u=Depends(need("budget.edit"))):
    p = db.get(Project, pid, with_for_update=True)
    if not p or p.deleted: raise HTTPException(404, "المشروع غير موجود")
    if p.version != b.version: raise HTTPException(409, "عُدّل المشروع من مستخدم آخر، أعد التحميل")
    cats = [l.category for l in b.lines]
    if len(set(cats)) != len(cats) or any(c not in CATS for c in cats): raise HTTPException(422, "فئة غير معروفة أو مكررة")
    old = {l.category: l for l in db.execute(select(BudgetLine).where(BudgetLine.project_id == pid)).scalars()}
    before = {c: str(l.amount) for c, l in old.items()}
    if old and len(b.reason.strip()) < 3: raise HTTPException(422, "تعديل موازنة قائمة يتطلب سببًا")
    for l in b.lines:
        if l.category in old: old[l.category].amount, old[l.category].note = l.amount, l.note
        else: db.add(BudgetLine(project_id=pid, category=l.category, amount=l.amount, note=l.note))
    for c in set(old) - set(cats): db.delete(old[c])                      # فئة غابت عن الطلب = تُصفَّر وتُحذف
    db.flush()
    total = db.execute(select(func.coalesce(func.sum(BudgetLine.amount), 0)).where(BudgetLine.project_id == pid)).scalar()
    p.budget = total; p.version += 1; db.flush()                           # يغذي تنبيه "التكاليف تجاوزت الموازنة" القائم
    audit.log(db, u, "budget.set", "project", pid, before=before, after={l.category: str(l.amount) for l in b.lines}, reason=b.reason or None, request=request)
    return build(db, p)

@router.get("/reports/budget-vs-actual")
def overview(db=Depends(get_db), _=Depends(need("budget.view"))):
    out = []
    for p in db.execute(select(Project).where(Project.deleted == False).order_by(Project.code)).scalars():
        d = build(db, p)
        out.append({"project_id": p.id, "code": p.code, "project": p.name, "budget": d["total_budget"], "actual": d["total_actual"], "variance": d["total_variance"],
                    "used_pct": d["used_pct"], "progress_pct": d["progress_pct"], "forecast": d["forecast_total"], "forecast_profit": d["forecast_profit"],
                    "over_categories": sum(1 for r in d["rows"] if r["status"] == "over"), "has_budget": d["total_budget"] > 0})
    return out
