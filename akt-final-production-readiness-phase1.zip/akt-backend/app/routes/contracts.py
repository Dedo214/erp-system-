from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Contract, ChangeOrder, Invoice, Project, Party, AdvancePayment
from ..deps import need
from .. import audit
from ..numbering import next_no

router = APIRouter(tags=["contracts"])
KIND_PARTY = {"client": "client", "subcontractor": "subcontractor", "supplier": "supplier"}

def approved_changes(db, cid):
    return db.execute(select(func.coalesce(func.sum(ChangeOrder.amount), 0))
                      .where(ChangeOrder.contract_id == cid, ChangeOrder.status == "approved")).scalar() or Decimal(0)

def invoiced(db, cid):
    return db.execute(select(func.coalesce(func.sum(Invoice.gross), 0))
                      .where(Invoice.contract_id == cid, Invoice.status.in_(("draft", "review", "approved", "submitted")))).scalar() or Decimal(0)

def advance_state(db, cid):
    """رصيد الدفعة المقدمة: المستلمة − المستردة بمستخلصات معتمدة. المعلّقة (مسودة/مراجعة) تُحجز من المتاح."""
    z = Decimal(0)
    rec = db.execute(select(func.coalesce(func.sum(AdvancePayment.amount), 0)).where(AdvancePayment.contract_id == cid, AdvancePayment.reversed == False)).scalar() or z
    sm = lambda sts: db.execute(select(func.coalesce(func.sum(Invoice.advance), 0)).where(Invoice.contract_id == cid, Invoice.status.in_(sts))).scalar() or z
    done, pend = sm(("approved", "submitted")), sm(("draft", "review"))
    return {"received": rec, "recovered": done, "pending": pend, "balance": rec - done, "available": max(z, rec - done - pend),
            "unbacked_recovery": max(z, done - rec)}

def cdto(db, c):
    ch = approved_changes(db, c.id); inv = invoiced(db, c.id)
    cur = c.original_value + ch
    return {"id": c.id, "code": c.code, "kind": c.kind, "project_id": c.project_id, "party_id": c.party_id, "title": c.title,
            "original_value": c.original_value, "approved_changes": ch, "current_value": cur, "invoiced": inv, "remaining": cur - inv,
            "start_date": c.start_date, "end_date": c.end_date, "advance_pct": c.advance_pct, "retention_pct": c.retention_pct,
            "advance_received": (adv := advance_state(db, c.id))["received"], "advance_balance": adv["balance"], "tax_pct": c.tax_pct, "payment_days": c.payment_days, "penalty_terms": c.penalty_terms, "status": c.status, "version": c.version}

class ContractIn(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    kind: str
    project_id: str
    party_id: str
    title: str = Field(min_length=1, max_length=300)
    original_value: Decimal = Field(ge=0)
    start_date: date | None = None
    end_date: date | None = None
    advance_pct: Decimal = Field(default=Decimal(0), ge=0, le=100)
    retention_pct: Decimal = Field(default=Decimal(0), ge=0, le=100)
    tax_pct: Decimal = Field(default=Decimal(0), ge=0, le=100)
    payment_days: int = Field(default=30, ge=0, le=365)
    penalty_terms: str = ""

@router.post("/contracts", status_code=201)
def create_contract(b: ContractIn, request: Request, db=Depends(get_db), u=Depends(need("contracts.create"))):
    if b.kind not in KIND_PARTY: raise HTTPException(422, "نوع العقد غير صحيح")
    if not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    p = db.get(Party, b.party_id)
    if not p or p.kind != KIND_PARTY[b.kind]: raise HTTPException(422, "الطرف الثاني لا يطابق نوع العقد")
    if b.start_date and b.end_date and b.end_date < b.start_date: raise HTTPException(422, "تاريخ النهاية قبل البداية")
    if db.execute(select(Contract.id).where(Contract.code == b.code)).first(): raise HTTPException(409, "كود العقد مستخدم")
    c = Contract(**b.model_dump(), created_by=u.id); db.add(c); db.flush(); db.refresh(c)
    audit.log(db, u, "contract.create", "contract", c.id, after=cdto(db, c), request=request)
    return cdto(db, c)

@router.get("/contracts")
def list_contracts(project_id: str | None = None, kind: str | None = None, db=Depends(get_db), _=Depends(need("contracts.view"))):
    q = select(Contract).order_by(Contract.code)
    if project_id: q = q.where(Contract.project_id == project_id)
    if kind: q = q.where(Contract.kind == kind)
    return [cdto(db, c) for c in db.execute(q).scalars()]

@router.get("/contracts/{cid}")
def get_contract(cid: str, db=Depends(get_db), _=Depends(need("contracts.view"))):
    c = db.get(Contract, cid)
    if not c: raise HTTPException(404, "العقد غير موجود")
    return cdto(db, c)

class ContractPatch(BaseModel):
    version: int
    title: str | None = None
    end_date: date | None = None
    penalty_terms: str | None = None
    payment_days: int | None = Field(default=None, ge=0, le=365)
    advance_pct: Decimal | None = Field(default=None, ge=0, le=100)
    retention_pct: Decimal | None = Field(default=None, ge=0, le=100)
    tax_pct: Decimal | None = Field(default=None, ge=0, le=100)
    original_value: Decimal | None = Field(default=None, ge=0)
    reason: str = ""

@router.patch("/contracts/{cid}")
def patch_contract(cid: str, b: ContractPatch, request: Request, db=Depends(get_db), u=Depends(need("contracts.update"))):
    c = db.get(Contract, cid)
    if not c: raise HTTPException(404, "العقد غير موجود")
    if c.version != b.version: raise HTTPException(409, "تم تعديل العقد من مستخدم آخر، أعد التحميل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if c.status != "draft":
        locked = {"original_value", "advance_pct", "retention_pct", "tax_pct"} & set(ch)
        if locked: raise HTTPException(422, "لا تُعدَّل قيمة العقد ونسبه بعد التفعيل؛ استخدم أمر تغيير")
    if not b.reason and ch: raise HTTPException(422, "سبب التعديل إلزامي")
    before = cdto(db, c)
    for k, v in ch.items(): setattr(c, k, v)
    c.version += 1; db.flush(); db.refresh(c)
    audit.log(db, u, "contract.update", "contract", c.id, before=before, after=cdto(db, c), reason=b.reason, request=request)
    return cdto(db, c)

@router.post("/contracts/{cid}/activate")
def activate(cid: str, request: Request, db=Depends(get_db), u=Depends(need("contracts.approve"))):
    c = db.get(Contract, cid)
    if not c: raise HTTPException(404, "العقد غير موجود")
    if c.status != "draft": raise HTTPException(409, "العقد ليس مسودة")
    if c.created_by == u.id and "admin" not in {r.name for r in u.roles}:
        raise HTTPException(403, "لا يجوز اعتماد عقد أنشأته بنفسك")
    c.status = "active"; c.version += 1; db.flush()
    audit.log(db, u, "contract.activate", "contract", c.id, after={"status": "active"}, request=request)
    return cdto(db, c)

# ---------------- أوامر التغيير ----------------
STAGES = {"draft": ("changeorders.create", "tech_review"), "tech_review": ("changeorders.review_tech", "fin_review"),
          "fin_review": ("changeorders.review_fin", "approval"), "approval": ("changeorders.approve", "approved")}

def codto(o):
    return {"id": o.id, "contract_id": o.contract_id, "no": o.no, "title": o.title, "reason": o.reason, "items": o.items,
            "amount": o.amount, "time_days": o.time_days, "status": o.status, "history": o.history}

class COIn(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    reason: str = Field(min_length=3)
    items: list[dict] = []
    amount: Decimal
    time_days: int = 0

@router.post("/contracts/{cid}/change-orders", status_code=201)
def new_co(cid: str, b: COIn, request: Request, db=Depends(get_db), u=Depends(need("changeorders.create"))):
    c = db.get(Contract, cid)
    if not c: raise HTTPException(404, "العقد غير موجود")
    if c.status != "active": raise HTTPException(409, "أوامر التغيير على العقود السارية فقط")
    no = next_no(db, ChangeOrder.no, ChangeOrder.contract_id == cid, scope=cid)
    o = ChangeOrder(contract_id=cid, no=no, created_by=u.id, **b.model_dump(), history=[])
    db.add(o); db.flush()
    audit.log(db, u, "changeorder.create", "change_order", o.id, after=codto(o), request=request)
    return codto(o)

@router.get("/contracts/{cid}/change-orders")
def list_co(cid: str, db=Depends(get_db), _=Depends(need("changeorders.view"))):
    return [codto(o) for o in db.execute(select(ChangeOrder).where(ChangeOrder.contract_id == cid).order_by(ChangeOrder.no)).scalars()]

class Step(BaseModel):
    note: str = ""

def _stamp(o, u, frm, to, note):
    from datetime import datetime
    o.history = list(o.history) + [{"by": u.username, "from": frm, "to": to, "note": note, "at": datetime.now().astimezone().isoformat()}]

@router.post("/change-orders/{oid}/advance")
def advance(oid: str, b: Step, request: Request, db=Depends(get_db), u=Depends(need("changeorders.view"))):
    o = db.get(ChangeOrder, oid)
    if not o: raise HTTPException(404, "أمر التغيير غير موجود")
    if o.status not in STAGES: raise HTTPException(409, "الأمر منتهي")
    perm, nxt = STAGES[o.status]
    if perm not in u.permissions(): raise HTTPException(403, f"لا تملك صلاحية: {perm}")
    if o.status == "approval":
        c = db.get(Contract, o.contract_id)
        if o.created_by == u.id: raise HTTPException(403, "لا يجوز اعتماد أمر تغيير أنشأته بنفسك")
        if c.original_value + approved_changes(db, c.id) + o.amount < invoiced(db, c.id):
            raise HTTPException(422, "الخصم يجعل قيمة العقد أقل من المستخلصات الصادرة")
    before = o.status; _stamp(o, u, before, nxt, b.note); o.status = nxt; db.flush()
    audit.log(db, u, "changeorder.advance", "change_order", o.id, before={"status": before}, after={"status": nxt}, reason=b.note, request=request)
    return codto(o)

@router.post("/change-orders/{oid}/reject")
def reject(oid: str, b: Step, request: Request, db=Depends(get_db), u=Depends(need("changeorders.view"))):
    o = db.get(ChangeOrder, oid)
    if not o: raise HTTPException(404, "أمر التغيير غير موجود")
    if o.status not in STAGES or o.status == "draft": raise HTTPException(409, "لا يمكن رفض هذا الأمر")
    if STAGES[o.status][0] not in u.permissions(): raise HTTPException(403, "لا تملك صلاحية الرفض في هذه المرحلة")
    if not b.note: raise HTTPException(422, "سبب الرفض إلزامي")
    before = o.status; _stamp(o, u, before, "rejected", b.note); o.status = "rejected"; db.flush()
    audit.log(db, u, "changeorder.reject", "change_order", o.id, before={"status": before}, after={"status": "rejected"}, reason=b.note, request=request)
    return codto(o)
