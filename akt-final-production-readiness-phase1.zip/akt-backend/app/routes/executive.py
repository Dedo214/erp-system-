import csv, io
from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from sqlalchemy import select, func
from ..db import get_db
from ..models import (Account, JournalEntry, JournalLine, Project, Contract, Invoice, Payment, Guarantee, PurchaseOrder, POLine,
                      SupplierInvoice, Party, Item, PayrollRun, ScheduleTask, BoqItem, Snag, Tender, SiteDocument, Risk, SafetyRecord, Correspondence, Equipment, Custody)
from ..deps import need
from .. import audit
from .contracts import approved_changes, invoiced
from .invoices import paid
from .reports import balances

router = APIRouter(prefix="/executive", tags=["executive"])
Z = Decimal(0)
BUCKETS = ("current", "d1_30", "d31_60", "d61_90", "d90_plus")

def bucket(days_over):
    return "current" if days_over <= 0 else "d1_30" if days_over <= 30 else "d31_60" if days_over <= 60 else "d61_90" if days_over <= 90 else "d90_plus"

def net(b, code, sign=1):
    d, c = b.get(code, (Z, Z)); return (d - c) * sign

def project_rows(db):
    types = {a.code: a.type for a in db.execute(select(Account)).scalars()}
    out = []
    for p in db.execute(select(Project).where(Project.deleted == False).order_by(Project.code)).scalars():
        b = balances(db, project_id=p.id)
        rev = sum((c - d for k, (d, c) in b.items() if types.get(k) == "revenue"), Z)
        cost = sum((d - c for k, (d, c) in b.items() if types.get(k) == "expense"), Z)
        cons = db.execute(select(Contract).where(Contract.project_id == p.id, Contract.kind == "client", Contract.status == "active")).scalars().all()
        cval = sum((c.original_value + approved_changes(db, c.id) for c in cons), Z)
        billed = sum((invoiced(db, c.id) for c in cons), Z)
        collected = db.execute(select(func.coalesce(func.sum(Payment.amount), 0)).join(Invoice, Invoice.id == Payment.invoice_id)
                               .join(Contract, Contract.id == Invoice.contract_id)
                               .where(Contract.project_id == p.id, Contract.kind == "client")).scalar() or Z
        committed = Z
        for o in db.execute(select(PurchaseOrder).where(PurchaseOrder.project_id == p.id, PurchaseOrder.status == "approved")).scalars():
            committed += sum(((l.qty - l.received) * l.price for l in o.lines), Z)
        committed = committed.quantize(Decimal("0.01"))
        bud = p.budget or Z; flags = []
        if bud and cost + committed > bud: flags.append("التكلفة مع الالتزامات تتجاوز الموازنة")
        if rev and rev - cost < 0: flags.append("خسارة")
        out.append({"project_id": p.id, "code": p.code, "name": p.name, "contract_value": cval, "billed": billed, "collected": collected,
                    "uncollected": billed - collected, "backlog": cval - billed, "revenue": rev, "cost": cost, "profit": rev - cost,
                    "margin_pct": ((rev - cost) / rev * 100).quantize(Decimal("0.1")) if rev else None,
                    "budget": bud, "committed": committed,
                    "budget_used_pct": ((cost + committed) / bud * 100).quantize(Decimal("0.1")) if bud else None, "flags": flags})
    return out

def aging(db, today):
    res = {"receivables": {k: Z for k in BUCKETS}, "payables": {k: Z for k in BUCKETS}}
    for i, c in db.execute(select(Invoice, Contract).join(Contract, Contract.id == Invoice.contract_id)
                           .where(Invoice.status.in_(("approved", "submitted")))).all():
        rest = i.net - paid(db, i.id)
        if rest > 0:
            k = bucket((today - (i.date + timedelta(days=c.payment_days))).days)
            res["receivables" if c.kind == "client" else "payables"][k] += rest
    for s, o in db.execute(select(SupplierInvoice, PurchaseOrder).join(PurchaseOrder, PurchaseOrder.id == SupplierInvoice.po_id)).all():
        rest = s.amount - s.paid
        if rest > 0:
            terms = db.get(Party, o.supplier_id).terms_days or 0
            res["payables"][bucket((today - (s.date + timedelta(days=terms))).days)] += rest
    return res

@router.get("/dashboard")
def dashboard(today: date | None = None, db=Depends(get_db), _=Depends(need("executive.view"))):
    t = today or date.today(); b = balances(db)
    types = {a.code: a.type for a in db.execute(select(Account)).scalars()}
    rev = sum((c - d for k, (d, c) in b.items() if types.get(k) == "revenue"), Z)
    exp = sum((d - c for k, (d, c) in b.items() if types.get(k) == "expense"), Z)
    projs = project_rows(db)
    ag = aging(db, t)
    alerts = []
    for g in db.execute(select(Guarantee).where(Guarantee.status.in_(("active", "renewed")), Guarantee.expiry_date <= t + timedelta(days=30))).scalars():
        alerts.append({"type": "guarantee_expiry", "ref": g.ref, "days_left": (g.expiry_date - t).days})
    if ag["receivables"]["d90_plus"] > 0: alerts.append({"type": "receivable_over_90", "amount": ag["receivables"]["d90_plus"]})
    for p in projs:
        for f in p["flags"]: alerts.append({"type": "project", "project": p["code"], "message": f})
    for i in db.execute(select(Item).where(Item.active == True)).scalars():
        if i.qty <= i.min_stock: alerts.append({"type": "low_stock", "item": i.code})
    for tk in db.execute(select(ScheduleTask).where(ScheduleTask.deleted == False, ScheduleTask.end < t, ScheduleTask.progress < 100)).scalars():
        alerts.append({"type": "task_delayed", "task": tk.name, "project": tk.project_id, "due": tk.end})
    for sn in db.execute(select(Snag).where(Snag.status == "open")).scalars():
        if sn.severity == "high" or (sn.due and sn.due < t):
            alerts.append({"type": "snag_overdue" if sn.due and sn.due < t else "snag_high", "ref": f"NCR-{sn.no:03d}", "project": sn.project_id})
    for td in db.execute(select(Tender).where(Tender.deleted == False, Tender.stage == "study")).scalars():
        if td.due and td.due <= t + timedelta(days=7):
            alerts.append({"type": "tender_due" if td.due >= t else "tender_due_missed", "tender": td.name, "due": td.due})
    for dc in db.execute(select(SiteDocument).where(SiteDocument.deleted == False, SiteDocument.expiry_date.is_not(None), SiteDocument.expiry_date <= t + timedelta(days=30))).scalars():
        alerts.append({"type": "document_expiry" if dc.expiry_date >= t else "document_expired", "name": dc.name, "expiry": dc.expiry_date})
    for rk in db.execute(select(Risk).where(Risk.status == "open")).scalars():
        if rk.prob * rk.impact >= 15: alerts.append({"type": "risk_high", "risk": rk.description[:80], "score": rk.prob * rk.impact})
    for sf in db.execute(select(SafetyRecord).where(SafetyRecord.status == "open", SafetyRecord.severity == "high")).scalars():
        alerts.append({"type": "safety_open_high", "desc": sf.description[:80], "project": sf.project_id})
    for co in db.execute(select(Correspondence).where(Correspondence.status == "open", Correspondence.due.is_not(None), Correspondence.due < t)).scalars():
        alerts.append({"type": "correspondence_overdue", "ref": co.ref_no, "subject": co.subject[:80]})
    for eq in db.execute(select(Equipment).where(Equipment.last_maint.is_not(None))).scalars():
        if eq.last_maint + timedelta(days=eq.maint_interval_days) < t: alerts.append({"type": "maintenance_overdue", "equipment": eq.name})
    for cu in db.execute(select(Custody).where(Custody.settled == False, Custody.date < t - timedelta(days=30))).scalars():
        alerts.append({"type": "custody_unsettled_30d", "person": cu.person, "amount": cu.amount})
    for bi in db.execute(select(BoqItem).where(BoqItem.deleted == False, BoqItem.done > BoqItem.qty)).scalars():
        alerts.append({"type": "boq_over_executed", "item": bi.description, "project": bi.project_id})
    for r in db.execute(select(PayrollRun).where(PayrollRun.status == "draft")).scalars():
        alerts.append({"type": "payroll_pending_approval", "month": r.month})
    return {"as_of": t,
            "financial": {"revenue": rev, "expenses": exp, "net_income": rev - exp,
                          "cash": net(b, "1100") + net(b, "1110"), "receivables": net(b, "1200"),
                          "retention_receivable": net(b, "1250"), "inventory": net(b, "1300"),
                          "payables": net(b, "2100", -1) + net(b, "2300", -1), "retention_payable": net(b, "2400", -1),
                          "payroll_due": net(b, "2500", -1)},
            "backlog": sum((p["backlog"] for p in projs), Z),
            "projects_count": len(projs), "aging": ag, "projects": projs, "alerts": alerts}

@router.get("/aging")
def aging_report(today: date | None = None, db=Depends(get_db), _=Depends(need("executive.view"))):
    return aging(db, today or date.today())

def safe(v):    # منع حقن الصيغ عند فتح CSV في Excel
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s

@router.get("/export/projects.csv")
def export_projects(request: Request, db=Depends(get_db), u=Depends(need("executive.export"))):
    rows = project_rows(db); buf = io.StringIO(); w = csv.writer(buf)
    cols = ["code", "name", "contract_value", "billed", "collected", "uncollected", "backlog", "revenue", "cost", "profit", "margin_pct", "budget", "committed", "budget_used_pct"]
    w.writerow(cols)
    for r in rows: w.writerow([safe(r[c]) for c in cols])
    audit.log(db, u, "export.projects", "report", "executive", after={"rows": len(rows)}, request=request)
    return Response("﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="projects.csv"'})
