import io, os
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from ..deps import need
from .. import audit
from ..db import get_db

router = APIRouter(tags=["export"])
MAXROWS = 20000
FONTS = os.path.join(os.path.dirname(os.path.dirname(__file__)), "fonts")

class ExportIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    columns: list[str] = Field(min_length=1, max_length=40)
    rows: list[list] = Field(max_length=MAXROWS)
    rtl: bool = True      # False = English/LTR layout
    lang: str = Field(default="ar", pattern="^(ar|en)$")

def _safe(v):
    """منع حقن المعادلات في Excel: أي نص يبدأ برمز معادلة يُكتب نصًا."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v

def _cell(v, en=False):
    if v is None: return ""
    if isinstance(v, bool): return ("Yes" if v else "No") if en else ("نعم" if v else "لا")
    return v

def make_xlsx(b: ExportIn) -> bytes:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = b.title[:31].replace("/", "-").replace("\\", "-").replace("?", "").replace("*", "").replace("[", "").replace("]", "").replace(":", "") or ("Export" if b.lang == "en" else "تصدير")
    ws.sheet_view.rightToLeft = b.rtl
    ws.append(b.columns)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F3A5F"); c.alignment = Alignment(horizontal="center")
    for r in b.rows:
        ws.append([_safe(_cell(v, b.lang == "en")) for v in r[:len(b.columns)]])
    for i, col in enumerate(b.columns, 1):
        w = max([len(str(col))] + [len(str(r[i-1])) for r in b.rows[:200] if len(r) >= i and r[i-1] is not None])
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = min(max(w + 2, 8), 50)
    ws.freeze_panes = "A2"
    out = io.BytesIO(); wb.save(out); return out.getvalue()

def _ar(t):
    from arabic_reshaper import reshape
    from bidi.algorithm import get_display
    return get_display(reshape(str(t)))

def make_pdf(b: ExportIn) -> bytes:
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if "AktSans" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("AktSans", os.path.join(FONTS, "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("AktSansB", os.path.join(FONTS, "DejaVuSans-Bold.ttf")))
    out = io.BytesIO()
    doc = SimpleDocTemplate(out, pagesize=landscape(A4), leftMargin=24, rightMargin=24, topMargin=28, bottomMargin=28, title=b.title)
    AL = 2 if b.rtl else 0
    ts = ParagraphStyle("t", fontName="AktSansB", fontSize=14, alignment=AL, leading=20)
    cs = ParagraphStyle("c", fontName="AktSans", fontSize=7.5, leading=10, alignment=AL)
    hs = ParagraphStyle("h", fontName="AktSansB", fontSize=8, leading=10, alignment=1, textColor=colors.white)
    ms = ParagraphStyle("m", fontName="AktSans", fontSize=7, alignment=AL, textColor=colors.grey)
    def P(v, st):
        cv = _cell(v, b.lang == "en")
        s = (_ar(cv) if b.rtl else str(cv)) if not isinstance(cv, (int, float)) else f"{_cell(v):,.2f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)
        return Paragraph(s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), st)
    rv = (lambda x: list(reversed(x))) if b.rtl else (lambda x: list(x))   # RTL: العمود الأول في أقصى اليمين
    data = [[P(c, hs) for c in rv(b.columns)]] + [[P(v, cs) for v in rv((r + [""] * len(b.columns))[:len(b.columns)])] for r in b.rows]
    t = Table(data, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3A5F")), ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#bbbbbb")),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f6fa")]), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    meta = f"Export date: {datetime.now():%Y-%m-%d %H:%M} — Rows: {len(b.rows)}" if b.lang == "en" else _ar(f"تاريخ التصدير: {datetime.now():%Y-%m-%d %H:%M} — عدد الصفوف: {len(b.rows)}")
    doc.build([Paragraph(_ar(b.title) if b.rtl else b.title, ts), Paragraph(meta, ms), Spacer(1, 8), t])
    return out.getvalue()

@router.post("/export/{fmt}")
def export(fmt: str, body: ExportIn, request: Request, db=Depends(get_db), u=Depends(need("export.use"))):
    if fmt not in ("xlsx", "pdf"): raise HTTPException(404, "الصيغة غير مدعومة")
    data = make_xlsx(body) if fmt == "xlsx" else make_pdf(body)
    audit.log(db, u, "export." + fmt, "export", body.title[:60], after={"rows": len(body.rows), "columns": len(body.columns)}, request=request)
    mt = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if fmt == "xlsx" else "application/pdf"
    return Response(data, media_type=mt, headers={"X-Content-Type-Options": "nosniff"})
