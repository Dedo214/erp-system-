import os
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy import select, func
from urllib.parse import quote
from ..db import get_db
from ..models import Attachment, SiteDocument
from ..deps import need
from .. import audit
import hashlib

router = APIRouter(tags=["files"])

def _row(a):
    return {"id": a.id, "filename": a.filename, "size": a.size, "sha256": a.sha256, "mime": a.mime,
            "uploaded_by": a.uploaded_by, "uploaded_at": a.uploaded_at}

@router.get("/files")
def list_files(entity: str, entity_id: str, db=Depends(get_db), _=Depends(need("files.view"))):
    q = select(Attachment).where(Attachment.entity == entity, Attachment.entity_id == entity_id).order_by(Attachment.uploaded_at.desc())
    return [_row(a) for a in db.execute(q).scalars()]

@router.get("/files/{fid}/download")
def download(fid: str, request: Request, db=Depends(get_db), u=Depends(need("files.view"))):
    a = db.get(Attachment, fid)
    if not a: raise HTTPException(404, "المرفق غير موجود")
    if not os.path.isfile(a.path): raise HTTPException(410, "ملف المرفق مفقود من التخزين — راجع النسخ الاحتياطي")
    with open(a.path, "rb") as f:                       # نتحقق من البصمة: كشف أي تلف أو تعديل
        if hashlib.sha256(f.read()).hexdigest() != a.sha256:
            raise HTTPException(500, "بصمة الملف لا تطابق المسجّلة — الملف تالف أو معدَّل")
    audit.log(db, u, "files.download", a.entity, a.entity_id, after={"file": a.filename}, request=request)
    return FileResponse(a.path, media_type=a.mime or "application/octet-stream",
                        headers={"Content-Disposition": "attachment; filename*=UTF-8''" + quote(a.filename),
                                 "X-Content-Type-Options": "nosniff"})

@router.delete("/files/{fid}")
def delete_file(fid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("files.delete"))):
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الحذف مطلوب")
    a = db.get(Attachment, fid)
    if not a: raise HTTPException(404, "المرفق غير موجود")
    if db.execute(select(func.count()).select_from(SiteDocument).where(SiteDocument.attachment_id == fid)).scalar():
        raise HTTPException(409, "المرفق مرتبط بمستند — احذف المستند أولًا")
    audit.log(db, u, "files.delete", a.entity, a.entity_id, before=_row(a), reason=reason, request=request)
    path, sha = a.path, a.sha256
    db.delete(a); db.flush()
    others = db.execute(select(func.count()).select_from(Attachment).where(Attachment.path == path)).scalar()
    if not others:
        try: os.remove(path)
        except FileNotFoundError: pass
    return {"ok": True}
