import csv, hashlib, io
from datetime import date
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Employee, EmployeeLoan, AttendanceRecord, AttendanceImport, Project
from ..deps import need
from .. import audit

router = APIRouter(tags=["hr"])

def edto(e, salary):
    d = {"id": e.id, "code": e.code, "name": e.name, "job": e.job, "dept": e.dept, "phone": e.phone, "hire_date": e.hire_date,
         "insured": e.insured, "project_id": e.project_id, "status": e.status, "version": e.version}
    if salary:   # الأجور والرقم القومي حقول حساسة: لا تُرسل إلا لمن يملك employees.salary
        d.update(basic=e.basic, allowances=e.allowances, national_id=e.national_id)
    return d

class EmpIn(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=200)
    job: str = ""; dept: str = ""; national_id: str = ""; phone: str = ""
    hire_date: date | None = None
    basic: Decimal = Field(default=Decimal(0), ge=0)
    allowances: Decimal = Field(default=Decimal(0), ge=0)
    insured: bool = True
    project_id: str | None = None

@router.post("/employees", status_code=201)
def new_emp(b: EmpIn, request: Request, db=Depends(get_db), u=Depends(need("employees.create"))):
    if db.execute(select(Employee.id).where(Employee.code == b.code)).first(): raise HTTPException(409, "رقم الموظف مستخدم")
    if b.national_id and not (b.national_id.isdigit() and len(b.national_id) == 14): raise HTTPException(422, "الرقم القومي يجب أن يكون 14 رقمًا")
    if b.project_id and not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    e = Employee(**b.model_dump()); db.add(e); db.flush(); db.refresh(e)
    audit.log(db, u, "employee.create", "employee", e.id, after=edto(e, True), request=request)
    return edto(e, "employees.salary" in u.permissions())

@router.get("/employees")
def list_emp(db=Depends(get_db), u=Depends(need("employees.view"))):
    s = "employees.salary" in u.permissions()
    return [edto(e, s) for e in db.execute(select(Employee).order_by(Employee.code)).scalars()]

class EmpPatch(BaseModel):
    version: int
    name: str | None = None; job: str | None = None; dept: str | None = None; phone: str | None = None
    basic: Decimal | None = Field(default=None, ge=0)
    allowances: Decimal | None = Field(default=None, ge=0)
    insured: bool | None = None
    status: str | None = None
    project_id: str | None = None
    reason: str = ""

@router.patch("/employees/{eid}")
def patch_emp(eid: str, b: EmpPatch, request: Request, db=Depends(get_db), u=Depends(need("employees.update"))):
    e = db.get(Employee, eid)
    if not e: raise HTTPException(404, "الموظف غير موجود")
    if e.version != b.version: raise HTTPException(409, "تم تعديل الموظف من مستخدم آخر، أعد التحميل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if {"basic", "allowances", "insured"} & set(ch):
        if "employees.salary" not in u.permissions(): raise HTTPException(403, "تعديل الأجور يتطلب employees.salary")
        if not b.reason: raise HTTPException(422, "سبب تعديل الأجر إلزامي")
    if ch.get("status") not in (None, "active", "suspended", "terminated"): raise HTTPException(422, "حالة غير صحيحة")
    before = edto(e, True)
    for k, v in ch.items(): setattr(e, k, v)
    e.version += 1; db.flush(); db.refresh(e)
    audit.log(db, u, "employee.update", "employee", e.id, before=before, after=edto(e, True), reason=b.reason, request=request)
    return edto(e, "employees.salary" in u.permissions())

class LoanIn(BaseModel):
    amount: Decimal = Field(gt=0)
    monthly: Decimal = Field(gt=0)
    note: str = ""

@router.post("/employees/{eid}/loans", status_code=201)
def new_loan(eid: str, b: LoanIn, request: Request, db=Depends(get_db), u=Depends(need("employees.salary"))):
    if not db.get(Employee, eid): raise HTTPException(404, "الموظف غير موجود")
    if b.monthly > b.amount: raise HTTPException(422, "القسط أكبر من السلفة")
    l = EmployeeLoan(employee_id=eid, **b.model_dump()); db.add(l); db.flush()
    audit.log(db, u, "loan.create", "employee_loan", l.id, after=b.model_dump(), request=request)
    return {"id": l.id, "amount": l.amount, "monthly": l.monthly, "repaid": l.repaid}

# ---------------- استيراد الحضور من AKT Attendance (لا نظام حضور مكرر) ----------------
STATUS = {"present": "present", "absent": "absent", "leave": "leave", "holiday": "holiday",
          "حضور": "present", "غياب": "absent", "اجازة": "leave", "إجازة": "leave", "عطلة": "holiday"}

class Row(BaseModel):
    employee_code: str
    date: date
    status: str
    hours: Decimal = Field(default=Decimal(0), ge=0, le=24)
    overtime_hours: Decimal = Field(default=Decimal(0), ge=0, le=24)

class ImportIn(BaseModel):
    source: str = "akt-attendance"
    rows: list[Row] = Field(min_length=1, max_length=20000)

def _apply(db, u, source, rows, raw_hash, request, pre_rejected=()):
    if db.execute(select(AttendanceImport.id).where(AttendanceImport.sha256 == raw_hash)).first():
        raise HTTPException(409, "هذه الدفعة استُوردت من قبل")
    emps = {e.code: e.id for e in db.execute(select(Employee)).scalars()}
    imp = AttendanceImport(source=source, sha256=raw_hash, rows_total=len(rows) + len(pre_rejected), created_by=u.id)
    db.add(imp); db.flush()
    rej = list(pre_rejected); new = upd = 0
    for n, r in enumerate(rows, 1):
        st = STATUS.get(r.status.strip().lower() if r.status.isascii() else r.status.strip())
        if r.employee_code not in emps: rej.append({"row": n, "reason": f"موظف غير معروف: {r.employee_code}"}); continue
        if not st: rej.append({"row": n, "reason": f"حالة غير معروفة: {r.status}"}); continue
        cur = db.execute(select(AttendanceRecord).where(AttendanceRecord.employee_id == emps[r.employee_code], AttendanceRecord.date == r.date)).scalar()
        if cur:
            cur.status, cur.hours, cur.overtime_hours, cur.import_id = st, r.hours, r.overtime_hours, imp.id; upd += 1
        else:
            db.add(AttendanceRecord(employee_id=emps[r.employee_code], date=r.date, status=st, hours=r.hours,
                                    overtime_hours=r.overtime_hours, import_id=imp.id)); new += 1
    imp.rows_new, imp.rows_updated, imp.rows_rejected, imp.rejected = new, upd, len(rej), rej[:200]
    db.flush()
    audit.log(db, u, "attendance.import", "attendance_import", imp.id, after={"source": source, "new": new, "updated": upd, "rejected": len(rej)}, request=request)
    return {"import_id": imp.id, "new": new, "updated": upd, "rejected": len(rej), "rejected_rows": rej[:200]}

@router.post("/attendance/import", status_code=201)
def import_json(b: ImportIn, request: Request, db=Depends(get_db), u=Depends(need("attendance.import"))):
    h = hashlib.sha256(b.model_dump_json().encode()).hexdigest()
    return _apply(db, u, b.source, b.rows, h, request)

@router.post("/attendance/import-file", status_code=201)
async def import_file(request: Request, file: UploadFile = File(...), db=Depends(get_db), u=Depends(need("attendance.import"))):
    """CSV أو XLSX بالأعمدة: employee_code,date,status,hours,overtime_hours"""
    raw = await file.read()
    if len(raw) > 10_000_000: raise HTTPException(413, "الملف كبير")
    name = (file.filename or "").lower(); recs = []
    try:
        if name.endswith(".xlsx"):
            import openpyxl
            ws = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True).active
            it = ws.iter_rows(values_only=True); hdr = [str(h or "").strip() for h in next(it)]
            recs = [dict(zip(hdr, r)) for r in it if any(c is not None for c in r)]
        elif name.endswith(".csv"):
            recs = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
        else: raise HTTPException(415, "الصيغ المقبولة: csv أو xlsx")
    except HTTPException: raise
    except Exception: raise HTTPException(422, "تعذرت قراءة الملف")
    rows, bad = [], []
    for n, r in enumerate(recs, 1):
        try:
            d = r["date"]; d = d.date() if hasattr(d, "date") else date.fromisoformat(str(d)[:10])
            rows.append(Row(employee_code=str(r["employee_code"]).strip(), date=d, status=str(r["status"]).strip(),
                            hours=Decimal(str(r.get("hours") or 0)), overtime_hours=Decimal(str(r.get("overtime_hours") or 0))))
        except (KeyError, ValueError, InvalidOperation, TypeError) as ex:
            bad.append({"row": n, "reason": "صف غير صالح"})
        except Exception:
            bad.append({"row": n, "reason": "قيم خارج الحدود"})
    if not rows: raise HTTPException(422, {"message": "لا صفوف صالحة", "rejected_rows": bad[:50]})
    return _apply(db, u, "file:" + (file.filename or "")[:50], rows, hashlib.sha256(raw).hexdigest(), request, bad)

@router.get("/attendance/summary")
def summary(month: str, db=Depends(get_db), _=Depends(need("attendance.view"))):
    y, m = int(month[:4]), int(month[5:7])
    a, z = date(y, m, 1), date(y + (m == 12), m % 12 + 1, 1)
    q = (select(Employee.code, AttendanceRecord.status, func.count(), func.coalesce(func.sum(AttendanceRecord.overtime_hours), 0))
         .join(Employee, Employee.id == AttendanceRecord.employee_id)
         .where(AttendanceRecord.date >= a, AttendanceRecord.date < z).group_by(Employee.code, AttendanceRecord.status))
    out = {}
    for code, st, n, ot in db.execute(q).all():
        o = out.setdefault(code, {"present": 0, "absent": 0, "leave": 0, "holiday": 0, "overtime_hours": Decimal(0)})
        o[st] = n; o["overtime_hours"] += ot
    return out
