from datetime import date, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Contract, Invoice, Payment, AdvancePayment, JournalEntry
from ..deps import need
from .. import audit
from ..numbering import next_no
from .ledger import post
from .contracts import approved_changes, invoiced, advance_state

router = APIRouter(tags=["invoices"])
CENT = Decimal("0.01")
HIGH = Decimal("1000000")           # صافي أعلى من هذا يتطلب invoices.approve_high
q2 = lambda x: Decimal(x).quantize(CENT)

def paid(db, iid):
    return db.execute(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.invoice_id == iid)).scalar() or Decimal(0)

def idto(db, i):
    return {"id": i.id, "contract_id": i.contract_id, "no": i.no, "date": i.date, "description": i.description, "final": i.final,
            "gross": i.gross, "advance": i.advance, "retention": i.retention, "tax": i.tax, "other": i.other, "net": i.net,
            "paid": paid(db, i.id), "outstanding": i.net - paid(db, i.id), "status": i.status, "entry_id": i.entry_id, "history": i.history}

class InvIn(BaseModel):
    date: date
    description: str = ""
    gross: Decimal = Field(gt=0)
    other: Decimal = Field(default=Decimal(0), ge=0)
    final: bool = False

def _stamp(i, u, to, note=""):
    i.history = list(i.history) + [{"by": u.username, "from": i.status, "to": to, "note": note, "at": datetime.now().astimezone().isoformat()}]

@router.post("/contracts/{cid}/invoices", status_code=201)
def new_invoice(cid: str, b: InvIn, request: Request, db=Depends(get_db), u=Depends(need("invoices.create"))):
    c = db.get(Contract, cid, with_for_update=True)          # القفل يمنع استرداد نفس الرصيد من مستخلصين متزامنين
    if not c: raise HTTPException(404, "العقد غير موجود")
    if c.status != "active": raise HTTPException(409, "العقد غير ساري")
    if c.kind not in ("client", "subcontractor"): raise HTTPException(422, "المستخلصات للعملاء والمقاولين فقط")
    cur = c.original_value + approved_changes(db, c.id)
    if invoiced(db, c.id) + b.gross > cur:
        raise HTTPException(422, "إجمالي المستخلصات يتجاوز قيمة العقد الحالية؛ أضف أمر تغيير معتمدًا أولًا")
    gross = q2(b.gross)
    # الاسترداد بنسبة العقد لكن بسقف رصيد الدفعة المقدمة الفعلية (لا استرداد بلا دفعة مستلمة)
    adv = min(q2(gross * c.advance_pct / 100), advance_state(db, cid)["available"])
    ret, tax = q2(gross * c.retention_pct / 100), q2(gross * c.tax_pct / 100)
    other = q2(b.other)
    net = gross - adv - ret - tax - other
    if net < 0: raise HTTPException(422, "الاستقطاعات أكبر من إجمالي المستخلص")
    no = next_no(db, Invoice.no, Invoice.contract_id == cid, scope=cid)
    i = Invoice(contract_id=cid, no=no, date=b.date, description=b.description, final=b.final, gross=gross, advance=adv,
                retention=ret, tax=tax, other=other, net=net, created_by=u.id, history=[])
    db.add(i); db.flush()
    audit.log(db, u, "invoice.create", "invoice", i.id, after=idto(db, i), request=request)
    return idto(db, i)

@router.get("/contracts/{cid}/invoices")
def list_inv(cid: str, db=Depends(get_db), _=Depends(need("invoices.view"))):
    return [idto(db, i) for i in db.execute(select(Invoice).where(Invoice.contract_id == cid).order_by(Invoice.no)).scalars()]

class Note(BaseModel):
    note: str = ""

@router.post("/invoices/{iid}/review")
def review(iid: str, b: Note, request: Request, db=Depends(get_db), u=Depends(need("invoices.review"))):
    i = db.get(Invoice, iid)
    if not i: raise HTTPException(404, "المستخلص غير موجود")
    if i.status != "draft": raise HTTPException(409, "المستخلص ليس مسودة")
    _stamp(i, u, "review", b.note); i.status = "review"; db.flush()
    audit.log(db, u, "invoice.review", "invoice", i.id, after={"status": "review"}, request=request)
    return idto(db, i)

def _lines(c, i):
    z = Decimal(0)
    if c.kind == "client":
        L = [("1200", i.net, z), ("1250", i.retention, z), ("1270", i.tax, z), ("2200", i.advance, z), ("4100", i.other, z), ("4100", z, i.gross)]
    else:
        L = [("5300", i.gross, z), ("2300", z, i.net), ("2400", z, i.retention), ("2600", z, i.tax), ("1410", z, i.advance), ("5300", z, i.other)]
    # دمج حساب 4100/5300 المتكرر وحذف الأصفار
    agg = {}
    for code, d, cr in L:
        a = agg.setdefault(code, [z, z]); a[0] += d; a[1] += cr
    out = []
    for code, (d, cr) in agg.items():
        n = d - cr
        if n > 0: out.append({"account_code": code, "debit": n, "credit": z})
        elif n < 0: out.append({"account_code": code, "debit": z, "credit": -n})
    return out

@router.post("/invoices/{iid}/approve")
def approve(iid: str, b: Note, request: Request, db=Depends(get_db), u=Depends(need("invoices.approve"))):
    i = db.get(Invoice, iid, with_for_update=True)
    if not i: raise HTTPException(404, "المستخلص غير موجود")
    if i.status != "review": raise HTTPException(409, "يجب مراجعة المستخلص أولًا")
    if i.created_by == u.id: raise HTTPException(403, "لا يجوز اعتماد مستخلص أنشأته بنفسك")
    if i.net > HIGH and "invoices.approve_high" not in u.permissions():
        raise HTTPException(403, "مستخلص بهذه القيمة يتطلب صلاحية invoices.approve_high")
    c = db.get(Contract, i.contract_id, with_for_update=True)
    st = advance_state(db, c.id)
    if i.advance > st["balance"]:
        raise HTTPException(409, f"رصيد الدفعة المقدمة ({st['balance']}) لا يكفي لاسترداد {i.advance}؛ سجّل الدفعة المقدمة أو أعد إنشاء المستخلص")
    lines = _lines(c, i)
    who = "مستخلص عميل" if c.kind == "client" else "مستخلص مقاول"
    e = post(db, u, i.date, f"{who} رقم {i.no} - {c.code}", lines, c.project_id, source="invoice")
    _stamp(i, u, "approved", b.note); i.status = "approved"; i.approved_by = u.id; i.entry_id = e.id; db.flush()
    audit.log(db, u, "invoice.approve", "invoice", i.id, after={"status": "approved", "entry_no": e.no}, request=request)
    return idto(db, i)

@router.post("/invoices/{iid}/reject")
def reject(iid: str, b: Note, request: Request, db=Depends(get_db), u=Depends(need("invoices.review"))):
    i = db.get(Invoice, iid)
    if not i: raise HTTPException(404, "المستخلص غير موجود")
    if i.status not in ("draft", "review"): raise HTTPException(409, "لا يمكن رفض مستخلص معتمد؛ يُعكس قيده")
    if not b.note: raise HTTPException(422, "سبب الرفض إلزامي")
    _stamp(i, u, "rejected", b.note); i.status = "rejected"; db.flush()
    audit.log(db, u, "invoice.reject", "invoice", i.id, after={"status": "rejected"}, reason=b.note, request=request)
    return idto(db, i)

class PayIn(BaseModel):
    date: date
    amount: Decimal = Field(gt=0)
    method: str = "bank"
    ref: str = ""

@router.post("/invoices/{iid}/payments", status_code=201)
def pay(iid: str, b: PayIn, request: Request, db=Depends(get_db), u=Depends(need("payments.create"))):
    i = db.get(Invoice, iid, with_for_update=True)
    if not i: raise HTTPException(404, "المستخلص غير موجود")
    if i.status not in ("approved", "submitted"): raise HTTPException(409, "المستخلص غير معتمد")
    if b.method not in ("cash", "bank", "cheque"): raise HTTPException(422, "طريقة الدفع غير صحيحة")
    amt = q2(b.amount)
    if paid(db, i.id) + amt > i.net: raise HTTPException(422, "المبلغ يتجاوز المتبقي على المستخلص")
    c = db.get(Contract, i.contract_id)
    cash = "1110" if b.method == "cash" else "1100"
    z = Decimal(0)
    lines = ([{"account_code": cash, "debit": amt, "credit": z}, {"account_code": "1200", "debit": z, "credit": amt}] if c.kind == "client"
             else [{"account_code": "2300", "debit": amt, "credit": z}, {"account_code": cash, "debit": z, "credit": amt}])
    e = post(db, u, b.date, f"{'تحصيل' if c.kind == 'client' else 'سداد'} مستخلص {i.no} - {c.code}", lines, c.project_id, source="payment")
    p = Payment(invoice_id=i.id, date=b.date, amount=amt, method=b.method, ref=b.ref, entry_id=e.id, created_by=u.id)
    db.add(p); db.flush()
    audit.log(db, u, "payment.create", "payment", p.id, after={"invoice": i.id, "amount": amt, "entry_no": e.no}, request=request)
    return {"id": p.id, "entry_id": e.id, "invoice": idto(db, i)}


# ---------------- الدفعات المقدمة ----------------
class AdvIn(BaseModel):
    date: date
    amount: Decimal = Field(gt=0)
    method: str = "bank"
    ref: str = Field(default="", max_length=100)

def adto(a): return {"id": a.id, "date": a.date, "amount": a.amount, "method": a.method, "ref": a.ref, "entry_id": a.entry_id, "reversed": a.reversed, "reverse_reason": a.reverse_reason}

@router.post("/contracts/{cid}/advances", status_code=201)
def new_advance(cid: str, b: AdvIn, request: Request, db=Depends(get_db), u=Depends(need("payments.create"))):
    c = db.get(Contract, cid, with_for_update=True)
    if not c: raise HTTPException(404, "العقد غير موجود")
    if c.kind not in ("client", "subcontractor"): raise HTTPException(422, "الدفعات المقدمة للعملاء والمقاولين فقط")
    if c.status not in ("draft", "active"): raise HTTPException(409, "العقد منتهٍ")
    if b.method not in ("cash", "bank", "cheque"): raise HTTPException(422, "طريقة الدفع غير صحيحة")
    amt = q2(b.amount); cur = c.original_value + approved_changes(db, c.id)
    if advance_state(db, cid)["received"] + amt > cur: raise HTTPException(422, "الدفعات المقدمة تتجاوز قيمة العقد")
    cash = "1110" if b.method == "cash" else "1100"; z = Decimal(0)
    lines = ([{"account_code": cash, "debit": amt, "credit": z}, {"account_code": "2200", "debit": z, "credit": amt}] if c.kind == "client"
             else [{"account_code": "1410", "debit": amt, "credit": z}, {"account_code": cash, "debit": z, "credit": amt}])
    e = post(db, u, b.date, f"{'استلام' if c.kind == 'client' else 'صرف'} دفعة مقدمة - {c.code}", lines, c.project_id, source="advance")
    a = AdvancePayment(contract_id=cid, date=b.date, amount=amt, method=b.method, ref=b.ref, entry_id=e.id, created_by=u.id); db.add(a); db.flush()
    audit.log(db, u, "advance.create", "contract", cid, after={"amount": amt, "entry_no": e.no}, request=request)
    return adto(a)

@router.get("/contracts/{cid}/advances")
def list_advances(cid: str, db=Depends(get_db), _=Depends(need("invoices.view"))):
    items = [adto(a) for a in db.execute(select(AdvancePayment).where(AdvancePayment.contract_id == cid).order_by(AdvancePayment.date, AdvancePayment.id)).scalars()]
    return {"summary": advance_state(db, cid), "items": items}

@router.post("/advances/{aid}/reverse")
def reverse_advance(aid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("payments.create"))):
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب العكس مطلوب")
    a = db.get(AdvancePayment, aid)
    if not a: raise HTTPException(404, "الدفعة غير موجودة")
    c = db.get(Contract, a.contract_id, with_for_update=True)
    db.refresh(a)
    if a.reversed: raise HTTPException(409, "الدفعة معكوسة بالفعل")
    st = advance_state(db, c.id)
    if st["received"] - a.amount < st["recovered"] + st["pending"]:
        raise HTTPException(409, "جزء من هذه الدفعة استُرد أو محجوز بمستخلصات؛ ارفض/اعكس المستخلصات أولًا")
    e = db.get(JournalEntry, a.entry_id)
    r = post(db, u, date.today(), f"عكس دفعة مقدمة - {c.code}: {reason}",
             [{"account_code": l.account_code, "debit": l.credit, "credit": l.debit} for l in e.lines], c.project_id, "reversal", e.id)
    a.reversed, a.reverse_entry_id, a.reverse_reason = True, r.id, reason.strip(); db.flush()
    audit.log(db, u, "advance.reverse", "contract", c.id, after={"advance": a.id, "reversal_no": r.no}, reason=reason, request=request)
    return adto(a)
