from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select, func
from ..db import get_db
from ..models import Account, JournalEntry, JournalLine, PeriodLock, Project
from ..deps import need
from .. import audit
from ..numbering import next_no

router = APIRouter(prefix="/ledger", tags=["ledger"])
CENT = Decimal("0.01")

class Line(BaseModel):
    account_code: str
    debit: Decimal = Field(default=Decimal(0), ge=0)
    credit: Decimal = Field(default=Decimal(0), ge=0)
    @model_validator(mode="after")
    def one_side(self):
        if (self.debit > 0) == (self.credit > 0):
            raise ValueError("كل طرف إما مدين أو دائن")
        return self

class EntryIn(BaseModel):
    date: date
    description: str = Field(min_length=1, max_length=400)
    project_id: str | None = None
    lines: list[Line] = Field(min_length=2)

def lock_date(db):
    r = db.execute(select(PeriodLock)).scalars().first()
    return r.lock_date if r else None

def check_open(db, d: date):
    ld = lock_date(db)
    if ld and d <= ld:
        raise HTTPException(423, f"الفترة المالية مقفلة حتى {ld.isoformat()}")

def dto(e):
    return {"id": e.id, "no": e.no, "date": e.date, "description": e.description, "project_id": e.project_id,
            "source": e.source, "reverses_id": e.reverses_id,
            "lines": [{"account_code": l.account_code, "debit": l.debit, "credit": l.credit} for l in e.lines]}

def post(db, user, d, desc, lines, project_id=None, source="manual", reverses_id=None):
    dr = sum((l["debit"] for l in lines), Decimal(0)).quantize(CENT)
    cr = sum((l["credit"] for l in lines), Decimal(0)).quantize(CENT)
    if dr != cr:
        raise HTTPException(422, f"القيد غير متزن: مدين {dr} ودائن {cr}")
    codes = {l["account_code"] for l in lines}
    have = set(db.execute(select(Account.code).where(Account.code.in_(codes), Account.active == True)).scalars())
    if codes - have:
        raise HTTPException(422, f"حساب غير موجود أو موقوف: {sorted(codes - have)}")
    if project_id and not db.get(Project, project_id):
        raise HTTPException(422, "المشروع غير موجود")
    check_open(db, d)
    no = next_no(db, JournalEntry.no)
    e = JournalEntry(no=no, date=d, description=desc, project_id=project_id, source=source,
                     reverses_id=reverses_id, created_by=user.id,
                     lines=[JournalLine(account_code=l["account_code"], debit=l["debit"], credit=l["credit"]) for l in lines])
    db.add(e); db.flush()
    return e

@router.get("/accounts")
def accounts(db=Depends(get_db), _=Depends(need("ledger.view"))):
    return [{"code": a.code, "name": a.name, "type": a.type, "active": a.active}
            for a in db.execute(select(Account).order_by(Account.code)).scalars()]

@router.post("/entries", status_code=201)
def new_entry(b: EntryIn, request: Request, db=Depends(get_db), u=Depends(need("ledger.create"))):
    e = post(db, u, b.date, b.description, [l.model_dump() for l in b.lines], b.project_id)
    audit.log(db, u, "ledger.post", "journal_entry", e.id, after=dto(e), request=request)
    return dto(e)

@router.get("/entries")
def entries(limit: int = 100, db=Depends(get_db), _=Depends(need("ledger.view"))):
    return [dto(e) for e in db.execute(select(JournalEntry).order_by(JournalEntry.no.desc()).limit(min(limit, 500))).scalars()]

@router.post("/entries/{eid}/reverse", status_code=201)
def reverse(eid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("ledger.reverse"))):
    """القيود لا تُعدَّل ولا تُحذف؛ التصحيح يتم بقيد عكسي مرتبط بالأصل وبسبب مسجل."""
    e = db.get(JournalEntry, eid)
    if not e: raise HTTPException(404, "غير موجود")
    if not reason.strip(): raise HTTPException(422, "سبب العكس مطلوب")
    if db.execute(select(JournalEntry.id).where(JournalEntry.reverses_id == eid)).first():
        raise HTTPException(409, "القيد معكوس بالفعل")
    if e.reverses_id:
        raise HTTPException(409, "لا يمكن عكس قيد عكسي")
    if e.source == "advance":
        raise HTTPException(409, "قيد دفعة مقدمة: اعكسها من شاشة العقد (الدفعات المقدمة) ليبقى رصيدها متسقًا")
    r = post(db, u, date.today(), f"عكس قيد رقم {e.no}: {reason}",
             [{"account_code": l.account_code, "debit": l.credit, "credit": l.debit} for l in e.lines],
             e.project_id, "reversal", e.id)
    audit.log(db, u, "ledger.reverse", "journal_entry", e.id, after={"reversal_no": r.no}, reason=reason, request=request)
    return dto(r)

@router.get("/trial-balance")
def tb(db=Depends(get_db), _=Depends(need("ledger.view"))):
    rows = db.execute(select(JournalLine.account_code, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
                      .group_by(JournalLine.account_code).order_by(JournalLine.account_code)).all()
    out = [{"account_code": a, "debit": d or Decimal(0), "credit": c or Decimal(0)} for a, d, c in rows]
    td = sum((r["debit"] for r in out), Decimal(0)); tc = sum((r["credit"] for r in out), Decimal(0))
    return {"rows": out, "total_debit": td, "total_credit": tc, "balanced": td == tc}

class Lock(BaseModel):
    lock_date: date | None
    reason: str = ""

@router.put("/period-lock")
def set_lock(b: Lock, request: Request, db=Depends(get_db), u=Depends(need("ledger.close"))):
    if b.lock_date and b.lock_date >= date.today():
        raise HTTPException(422, "لا يمكن قفل فترة لم تنتهِ")
    r = db.execute(select(PeriodLock)).scalars().first() or PeriodLock()
    before = {"lock_date": r.lock_date}
    r.lock_date = b.lock_date; db.add(r); db.flush()
    audit.log(db, u, "ledger.period_lock", "period", "1", before=before, after={"lock_date": b.lock_date}, reason=b.reason, request=request)
    return {"lock_date": b.lock_date}
