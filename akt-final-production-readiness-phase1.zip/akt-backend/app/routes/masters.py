from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import Project, Party, BudgetLine
from ..deps import need
from .. import audit

router = APIRouter(tags=["masters"])

def row(o, cols): return {c: getattr(o, c) for c in cols}
PCOLS = ["id","code","name","client_id","location","start_date","end_date","contract_value","budget","progress","status","version"]
KCOLS = ["id","kind","name","contact","phone","email","tax_no","terms_days","credit_limit","version"]

class ProjectIn(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1)
    client_id: str | None = None
    location: str = ""
    start_date: date | None = None
    end_date: date | None = None
    contract_value: Decimal = Field(default=Decimal(0), ge=0)
    budget: Decimal = Field(default=Decimal(0), ge=0)
    progress: Decimal = Field(default=Decimal(0), ge=0, le=100)
    status: str = "active"

class ProjectPatch(BaseModel):
    version: int                      # إلزامي: يمنع الكتابة فوق تعديل مستخدم آخر
    name: str | None = None
    location: str | None = None
    start_date: date | None = None
    end_date: date | None = None
    contract_value: Decimal | None = Field(default=None, ge=0)
    budget: Decimal | None = Field(default=None, ge=0)
    progress: Decimal | None = Field(default=None, ge=0, le=100)
    status: str | None = None
    reason: str = ""

@router.get("/projects")
def projects(db=Depends(get_db), _=Depends(need("projects.view"))):
    return [row(p, PCOLS) for p in db.execute(select(Project).where(Project.deleted == False).order_by(Project.code)).scalars()]

@router.post("/projects", status_code=201)
def new_project(b: ProjectIn, request: Request, db=Depends(get_db), u=Depends(need("projects.create"))):
    if db.execute(select(Project).where(Project.code == b.code)).scalar_one_or_none():
        raise HTTPException(409, "كود المشروع مستخدم")
    if b.start_date and b.end_date and b.end_date < b.start_date:
        raise HTTPException(422, "تاريخ النهاية قبل البداية")
    p = Project(**b.model_dump()); db.add(p); db.flush(); db.refresh(p)
    audit.log(db, u, "projects.create", "project", p.id, after=row(p, PCOLS), request=request)
    return row(p, PCOLS)

@router.patch("/projects/{pid}")
def edit_project(pid: str, b: ProjectPatch, request: Request, db=Depends(get_db), u=Depends(need("projects.update"))):
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(404, "غير موجود")
    if p.version != b.version:
        raise HTTPException(409, "عُدّل هذا المشروع بواسطة مستخدم آخر. أعد التحميل ثم حاول مجدداً")
    before = row(p, PCOLS)
    sensitive = {"contract_value", "budget"} & set(b.model_dump(exclude_unset=True))
    if sensitive and not b.reason.strip():
        raise HTTPException(422, "سبب التعديل مطلوب عند تغيير قيمة العقد أو الميزانية")
    if "budget" in b.model_dump(exclude_unset=True) and db.execute(select(BudgetLine.id).where(BudgetLine.project_id == pid).limit(1)).first():
        raise HTTPException(409, "موازنة هذا المشروع تُدار من شاشة «الميزانية التقديرية» (فئات التكلفة)؛ عدّلها من هناك")
    for k, v in b.model_dump(exclude_unset=True, exclude={"version", "reason"}).items():
        setattr(p, k, v)
    if p.start_date and p.end_date and p.end_date < p.start_date:
        raise HTTPException(422, "تاريخ النهاية قبل البداية")
    p.version += 1
    db.flush(); db.refresh(p)                      # نسجل القيمة كما خُزّنت فعلاً (بعد التقريب)
    audit.log(db, u, "projects.update", "project", p.id, before=before, after=row(p, PCOLS), reason=b.reason, request=request)
    return row(p, PCOLS)

@router.delete("/projects/{pid}")
def del_project(pid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("projects.delete"))):
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(404, "غير موجود")
    if not reason.strip(): raise HTTPException(422, "سبب الحذف مطلوب")
    from ..models import JournalEntry
    if db.execute(select(JournalEntry.id).where(JournalEntry.project_id == pid).limit(1)).first():
        raise HTTPException(409, "لا يمكن حذف مشروع له قيود مالية")
    before = row(p, PCOLS); p.deleted = True; p.version += 1       # حذف منطقي فقط
    audit.log(db, u, "projects.delete", "project", p.id, before=before, reason=reason, request=request)
    return {"ok": True}

class PartyIn(BaseModel):
    kind: str = Field(pattern="^(client|supplier|subcontractor)$")
    name: str = Field(min_length=1)
    contact: str = ""; phone: str = ""; email: str = ""; tax_no: str = ""
    terms_days: int = Field(default=0, ge=0)
    credit_limit: Decimal = Field(default=Decimal(0), ge=0)

@router.get("/parties")
def parties(kind: str | None = None, db=Depends(get_db), _=Depends(need("parties.view"))):
    q = select(Party).where(Party.deleted == False)
    if kind: q = q.where(Party.kind == kind)
    return [row(p, KCOLS) for p in db.execute(q.order_by(Party.name)).scalars()]

@router.post("/parties", status_code=201)
def new_party(b: PartyIn, request: Request, db=Depends(get_db), u=Depends(need("parties.create"))):
    if db.execute(select(Party).where(Party.kind == b.kind, Party.name == b.name.strip())).scalar_one_or_none():
        raise HTTPException(409, "الطرف موجود بالفعل")
    p = Party(**{**b.model_dump(), "name": b.name.strip()}); db.add(p); db.flush()
    audit.log(db, u, "parties.create", "party", p.id, after=row(p, KCOLS), request=request)
    return row(p, KCOLS)
