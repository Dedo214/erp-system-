import calendar
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Employee, EmployeeLoan, AttendanceRecord, PayrollRun, PayrollLine, PayrollSetting
from ..deps import need
from .. import audit
from .ledger import post

router = APIRouter(tags=["payroll"])
Z = Decimal(0)
q2 = lambda x: Decimal(x).quantize(Decimal("0.01"), ROUND_HALF_UP)

# قيم افتراضية قابلة للتعديل من الإعدادات؛ تُراجع مع المحاسب القانوني قبل الاعتماد الفعلي.
DEFAULTS = {"ins_min": 2700, "ins_max": 16700, "ins_emp_pct": 11, "ins_er_pct": 18.75, "tax_exemption": 20000,
            "ot_multiplier": 1.35,
            "brackets": [[40000, 0], [15000, 0.10], [15000, 0.15], [130000, 0.20], [200000, 0.225], [800000, 0.25], [None, 0.275]]}

def params(db):
    p = dict(DEFAULTS)
    for s in db.execute(select(PayrollSetting)).scalars(): p[s.key] = s.value
    return p

def tax_year(annual, brackets):
    t, rest = Z, max(Z, annual)
    for w, rate in brackets:
        x = rest if w is None else min(rest, Decimal(str(w)))
        t += x * Decimal(str(rate)); rest -= x
        if rest <= 0: break
    return t

def calc(e, P, absent_days, ot_hours, bonus, penalty, loan):
    D = lambda k: Decimal(str(P[k]))
    g0 = e.basic + e.allowances
    absence = q2(absent_days * g0 / 30)
    hourly = e.basic / 30 / 8
    ot = q2(ot_hours * hourly * D("ot_multiplier"))
    gross = max(Z, g0 + ot + bonus - absence)
    iw = min(max(e.basic, D("ins_min")), D("ins_max")) if e.insured else Z
    ei, er = q2(iw * D("ins_emp_pct") / 100), q2(iw * D("ins_er_pct") / 100)
    tax = q2(tax_year((gross - ei) * 12 - D("tax_exemption"), P["brackets"]) / 12)
    net = gross - ei - tax - penalty - loan
    return dict(base=g0, absence_ded=absence, overtime_pay=ot, gross=gross, emp_ins=ei, er_ins=er, tax=tax, net=net)

def loan_due(db, eid):
    due = Z
    for l in db.execute(select(EmployeeLoan).where(EmployeeLoan.employee_id == eid)).scalars():
        due += min(l.monthly, l.amount - l.repaid)
    return due

def att(db, eid, month):
    y, m = int(month[:4]), int(month[5:])
    a, z = date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])
    r = db.execute(select(AttendanceRecord).where(AttendanceRecord.employee_id == eid, AttendanceRecord.date >= a, AttendanceRecord.date <= z)).scalars().all()
    return Decimal(sum(1 for x in r if x.status == "absent")), sum((x.overtime_hours for x in r), Z)

def rdto(db, r, with_lines=True):
    ls = r.lines; tot = lambda k: sum((getattr(l, k) for l in ls), Z)
    d = {"id": r.id, "month": r.month, "status": r.status, "entry_id": r.entry_id, "pay_entry_id": r.pay_entry_id,
         "totals": {k: tot(k) for k in ("gross", "emp_ins", "er_ins", "tax", "loan", "penalty", "net")}, "employees": len(ls)}
    d["totals"]["cost"] = d["totals"]["gross"] + d["totals"]["er_ins"]
    if with_lines:
        names = {e.id: (e.code, e.name) for e in db.execute(select(Employee)).scalars()}
        d["lines"] = [{"id": l.id, "employee_id": l.employee_id, "code": names[l.employee_id][0], "name": names[l.employee_id][1],
                       **{k: getattr(l, k) for k in ("absent_days", "overtime_hours", "bonus", "penalty", "base", "absence_ded", "overtime_pay",
                                                     "gross", "emp_ins", "er_ins", "tax", "loan", "net")}} for l in ls]
    return d

def fill(l, c):
    for k, v in c.items(): setattr(l, k, v)

class RunIn(BaseModel):
    month: str = Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$")

@router.get("/payroll/settings")
def get_settings(db=Depends(get_db), _=Depends(need("payroll.view"))):
    return params(db)

class SetIn(BaseModel):
    values: dict
    reason: str = Field(min_length=3)

@router.put("/payroll/settings")
def put_settings(b: SetIn, request: Request, db=Depends(get_db), u=Depends(need("payroll.settings"))):
    bad = set(b.values) - set(DEFAULTS)
    if bad: raise HTTPException(422, f"مفاتيح غير معروفة: {sorted(bad)}")
    before = params(db)
    for k, v in b.values.items():
        if k != "brackets" and (not isinstance(v, (int, float)) or v < 0): raise HTTPException(422, f"قيمة غير صالحة: {k}")
        if k == "brackets" and not (isinstance(v, list) and v and all(isinstance(x, list) and len(x) == 2 for x in v)):
            raise HTTPException(422, "شرائح الضريبة غير صالحة")
        row = db.get(PayrollSetting, k)
        if row: row.value = v
        else: db.add(PayrollSetting(key=k, value=v))
    db.flush()
    audit.log(db, u, "payroll.settings", "payroll_settings", "-", before=before, after=params(db), reason=b.reason, request=request)
    return params(db)

@router.post("/payroll/runs", status_code=201)
def new_run(b: RunIn, request: Request, db=Depends(get_db), u=Depends(need("payroll.create"))):
    if db.execute(select(PayrollRun.id).where(PayrollRun.month == b.month)).first(): raise HTTPException(409, "توجد مسيرة لهذا الشهر")
    P = params(db); r = PayrollRun(month=b.month, params=P, created_by=u.id); db.add(r); db.flush()
    emps = db.execute(select(Employee).where(Employee.status == "active").order_by(Employee.code)).scalars().all()
    if not emps: raise HTTPException(422, "لا يوجد موظفون نشطون")
    for e in emps:
        ab, ot = att(db, e.id, b.month); ln = loan_due(db, e.id)
        l = PayrollLine(run_id=r.id, employee_id=e.id, absent_days=ab, overtime_hours=ot, bonus=Z, penalty=Z, loan=ln)
        fill(l, calc(e, P, ab, ot, Z, Z, ln)); r.lines.append(l)
    db.flush()
    audit.log(db, u, "payroll.create", "payroll_run", r.id, after=rdto(db, r, False), request=request)
    return rdto(db, r)

@router.get("/payroll/runs")
def list_runs(db=Depends(get_db), _=Depends(need("payroll.view"))):
    return [rdto(db, r, False) for r in db.execute(select(PayrollRun).order_by(PayrollRun.month.desc())).scalars()]

@router.get("/payroll/runs/{rid}")
def get_run(rid: str, db=Depends(get_db), _=Depends(need("payroll.view"))):
    r = db.get(PayrollRun, rid)
    if not r: raise HTTPException(404, "المسيرة غير موجودة")
    return rdto(db, r)

class LinePatch(BaseModel):
    bonus: Decimal | None = Field(default=None, ge=0)
    penalty: Decimal | None = Field(default=None, ge=0)
    absent_days: Decimal | None = Field(default=None, ge=0, le=31)
    overtime_hours: Decimal | None = Field(default=None, ge=0)
    reason: str = Field(min_length=3)

@router.patch("/payroll/runs/{rid}/lines/{lid}")
def patch_line(rid: str, lid: int, b: LinePatch, request: Request, db=Depends(get_db), u=Depends(need("payroll.create"))):
    r = db.get(PayrollRun, rid)
    if not r: raise HTTPException(404, "المسيرة غير موجودة")
    if r.status != "draft": raise HTTPException(409, "المسيرة معتمدة ولا تُعدَّل")
    l = db.get(PayrollLine, lid)
    if not l or l.run_id != rid: raise HTTPException(404, "السطر غير موجود")
    before = {k: getattr(l, k) for k in ("bonus", "penalty", "absent_days", "overtime_hours", "net")}
    for k, v in b.model_dump(exclude_unset=True, exclude={"reason"}).items(): setattr(l, k, v)
    e = db.get(Employee, l.employee_id)
    c = calc(e, r.params, l.absent_days, l.overtime_hours, l.bonus, l.penalty, l.loan)
    if c["net"] < 0: raise HTTPException(422, "الاستقطاعات أكبر من الإجمالي")
    fill(l, c); db.flush()
    audit.log(db, u, "payroll.line", "payroll_line", l.id, before=before, after={k: getattr(l, k) for k in before}, reason=b.reason, request=request)
    return rdto(db, r)

@router.post("/payroll/runs/{rid}/approve")
def approve(rid: str, request: Request, db=Depends(get_db), u=Depends(need("payroll.approve"))):
    r = db.get(PayrollRun, rid, with_for_update=True)
    if not r: raise HTTPException(404, "المسيرة غير موجودة")
    if r.status != "draft": raise HTTPException(409, "المسيرة ليست مسودة")
    if r.created_by == u.id: raise HTTPException(403, "لا يجوز اعتماد مسيرة أنشأتها بنفسك")
    t = rdto(db, r, False)["totals"]
    y, m = int(r.month[:4]), int(r.month[5:])
    d = date(y, m, calendar.monthrange(y, m)[1])
    lines = [{"account_code": "5200", "debit": t["gross"] + t["er_ins"], "credit": Z},
             {"account_code": "2500", "debit": Z, "credit": t["net"]},
             {"account_code": "2510", "debit": Z, "credit": t["emp_ins"] + t["er_ins"]},
             {"account_code": "2520", "debit": Z, "credit": t["tax"]},
             {"account_code": "1400", "debit": Z, "credit": t["loan"]},
             {"account_code": "5200", "debit": Z, "credit": t["penalty"]}]
    agg = {}
    for l in lines:
        a = agg.setdefault(l["account_code"], Z); agg[l["account_code"]] = a + l["debit"] - l["credit"]
    final = [{"account_code": k, "debit": v if v > 0 else Z, "credit": -v if v < 0 else Z} for k, v in agg.items() if v != 0]
    e = post(db, u, d, f"مسيرة رواتب {r.month}", final, source="payroll")
    for l in r.lines:      # تحديث رصيد السلف المسددة
        left = l.loan
        for ln in db.execute(select(EmployeeLoan).where(EmployeeLoan.employee_id == l.employee_id)).scalars():
            take = min(ln.monthly, ln.amount - ln.repaid, left); ln.repaid += take; left -= take
    r.status, r.entry_id, r.approved_by = "approved", e.id, u.id; db.flush()
    audit.log(db, u, "payroll.approve", "payroll_run", r.id, after={"status": "approved", "entry_no": e.no, **t}, request=request)
    return rdto(db, r, False)

class PayIn(BaseModel):
    date: date
    method: str = "bank"

@router.post("/payroll/runs/{rid}/pay")
def pay(rid: str, b: PayIn, request: Request, db=Depends(get_db), u=Depends(need("payroll.pay"))):
    r = db.get(PayrollRun, rid, with_for_update=True)
    if not r: raise HTTPException(404, "المسيرة غير موجودة")
    if r.status != "approved": raise HTTPException(409, "يجب اعتماد المسيرة أولًا")
    if b.method not in ("cash", "bank"): raise HTTPException(422, "طريقة الصرف غير صحيحة")
    net = rdto(db, r, False)["totals"]["net"]
    e = post(db, u, b.date, f"صرف رواتب {r.month}", [{"account_code": "2500", "debit": net, "credit": Z},
             {"account_code": "1110" if b.method == "cash" else "1100", "debit": Z, "credit": net}], source="payroll")
    r.status, r.pay_entry_id = "paid", e.id; db.flush()
    audit.log(db, u, "payroll.pay", "payroll_run", r.id, after={"status": "paid", "net": net}, request=request)
    return rdto(db, r, False)
