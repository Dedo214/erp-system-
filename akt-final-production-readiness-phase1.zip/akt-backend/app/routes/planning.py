import csv, io
from datetime import date
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import BoqItem, ScheduleTask, Project
from ..deps import need
from .. import audit

router = APIRouter(tags=["planning"])
Z = Decimal(0)
q2 = lambda x: Decimal(x).quantize(Decimal("0.01"))

def project_or_404(db, pid):
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(404, "المشروع غير موجود")
    return p

# ---------------- المقايسات ----------------
def bdto(b):
    return {"id": b.id, "project_id": b.project_id, "section": b.section, "description": b.description, "unit": b.unit, "qty": b.qty,
            "price": b.price, "total": q2(b.qty * b.price), "done": b.done, "done_value": q2(b.done * b.price),
            "done_pct": (b.done / b.qty * 100).quantize(Decimal("0.1")) if b.qty else None,
            "over_executed": b.done > b.qty, "version": b.version}

def boq_items(db, pid):
    return db.execute(select(BoqItem).where(BoqItem.project_id == pid, BoqItem.deleted == False).order_by(BoqItem.section, BoqItem.description)).scalars().all()

class BoqIn(BaseModel):
    section: str = Field(default="", max_length=120)
    description: str = Field(min_length=1, max_length=400)
    unit: str = Field(default="", max_length=30)
    qty: Decimal = Field(ge=0)
    price: Decimal = Field(ge=0)

@router.get("/projects/{pid}/boq")
def get_boq(pid: str, db=Depends(get_db), _=Depends(need("boq.view"))):
    project_or_404(db, pid)
    items = boq_items(db, pid); rows = [bdto(b) for b in items]
    total = sum((r["total"] for r in rows), Z)
    # الإنجاز المرجَّح بالقيمة؛ والكمية المنفذة الزائدة لا تُحتسب فوق 100% في البند
    done = sum((q2(min(b.done, b.qty) * b.price) for b in items), Z)
    return {"items": rows, "direct_cost": total, "executed_value": done,
            "progress_pct": (done / total * 100).quantize(Decimal("0.1")) if total else None,
            "over_executed": [r["description"] for r in rows if r["over_executed"]]}

@router.post("/projects/{pid}/boq", status_code=201)
def add_boq(pid: str, b: BoqIn, request: Request, db=Depends(get_db), u=Depends(need("boq.create"))):
    project_or_404(db, pid)
    x = BoqItem(project_id=pid, **b.model_dump()); db.add(x); db.flush(); db.refresh(x)
    audit.log(db, u, "boq.create", "boq_item", x.id, after=bdto(x), request=request)
    return bdto(x)

class BoqPatch(BaseModel):
    version: int
    section: str | None = None
    description: str | None = Field(default=None, min_length=1)
    unit: str | None = None
    qty: Decimal | None = Field(default=None, ge=0)
    price: Decimal | None = Field(default=None, ge=0)
    done: Decimal | None = Field(default=None, ge=0)
    reason: str = ""

@router.patch("/boq/{bid}")
def patch_boq(bid: str, b: BoqPatch, request: Request, db=Depends(get_db), u=Depends(need("boq.update"))):
    x = db.get(BoqItem, bid)
    if not x or x.deleted: raise HTTPException(404, "البند غير موجود")
    if x.version != b.version: raise HTTPException(409, "عُدّل البند من مستخدم آخر، أعد التحميل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if {"qty", "price"} & set(ch) and not b.reason.strip(): raise HTTPException(422, "سبب تعديل الكمية أو السعر إلزامي")
    before = bdto(x)
    for k, v in ch.items(): setattr(x, k, v)
    x.version += 1; db.flush(); db.refresh(x)
    audit.log(db, u, "boq.update", "boq_item", x.id, before=before, after=bdto(x), reason=b.reason, request=request)
    return bdto(x)

@router.delete("/boq/{bid}")
def del_boq(bid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("boq.delete"))):
    x = db.get(BoqItem, bid)
    if not x or x.deleted: raise HTTPException(404, "البند غير موجود")
    if x.done > 0: raise HTTPException(409, "لا يُحذف بند له كمية منفذة")
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الحذف إلزامي")
    before = bdto(x); x.deleted = True; db.flush()
    audit.log(db, u, "boq.delete", "boq_item", x.id, before=before, reason=reason, request=request)
    return {"ok": True}

@router.post("/projects/{pid}/boq/import", status_code=201)
async def import_boq(pid: str, request: Request, file: UploadFile = File(...), db=Depends(get_db), u=Depends(need("boq.import"))):
    """CSV أو XLSX بالأعمدة: section,description,unit,qty,price — الصفوف المرفوضة تُعاد ولا تُخفى."""
    project_or_404(db, pid)
    raw = await file.read()
    if len(raw) > 10_000_000: raise HTTPException(413, "الملف كبير")
    name = (file.filename or "").lower()
    try:
        if name.endswith(".xlsx"):
            import openpyxl
            it = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True).active.iter_rows(values_only=True)
            hdr = [str(h or "").strip() for h in next(it)]; recs = [dict(zip(hdr, r)) for r in it if any(c is not None for c in r)]
        elif name.endswith(".csv"): recs = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
        else: raise HTTPException(415, "الصيغ المقبولة: csv أو xlsx")
    except HTTPException: raise
    except Exception: raise HTTPException(422, "تعذرت قراءة الملف")
    ok, bad = [], []
    for n, r in enumerate(recs, 1):
        try: ok.append(BoqIn(section=str(r.get("section") or ""), description=str(r["description"]).strip(), unit=str(r.get("unit") or ""),
                             qty=Decimal(str(r["qty"])), price=Decimal(str(r["price"]))))
        except Exception: bad.append({"row": n, "reason": "صف غير صالح (وصف/كمية/سعر)"})
    if not ok: raise HTTPException(422, {"message": "لا صفوف صالحة", "rejected_rows": bad[:50]})
    for b in ok: db.add(BoqItem(project_id=pid, **b.model_dump()))
    db.flush()
    audit.log(db, u, "boq.import", "project", pid, after={"added": len(ok), "rejected": len(bad), "file": (file.filename or "")[:80]}, request=request)
    return {"added": len(ok), "rejected": len(bad), "rejected_rows": bad[:200]}

# ---------------- الجدول الزمني ----------------
def tdto(t, today=None):
    today = today or date.today()
    return {"id": t.id, "project_id": t.project_id, "name": t.name, "start": t.start, "end": t.end, "progress": t.progress,
            "predecessor_id": t.predecessor_id, "days": (t.end - t.start).days + 1,
            "delayed": t.end < today and t.progress < 100, "version": t.version}

class TaskIn(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    start: date
    end: date
    progress: Decimal = Field(default=Decimal(0), ge=0, le=100)
    predecessor_id: str | None = None

def check_pred(db, pid, tid, pred):
    if not pred: return
    p = db.get(ScheduleTask, pred)
    if not p or p.deleted or p.project_id != pid: raise HTTPException(422, "المهمة السابقة غير موجودة في نفس المشروع")
    seen = set()
    while p:                                         # منع الحلقات في سلسلة الاعتماد
        if p.id == tid or p.id in seen: raise HTTPException(422, "اعتماد دائري بين المهام")
        seen.add(p.id); p = db.get(ScheduleTask, p.predecessor_id) if p.predecessor_id else None

@router.get("/projects/{pid}/tasks")
def get_tasks(pid: str, today: date | None = None, db=Depends(get_db), _=Depends(need("schedule.view"))):
    project_or_404(db, pid)
    ts = db.execute(select(ScheduleTask).where(ScheduleTask.project_id == pid, ScheduleTask.deleted == False).order_by(ScheduleTask.start)).scalars().all()
    rows = [tdto(t, today) for t in ts]; w = sum(r["days"] for r in rows)
    prog = (sum(r["progress"] * r["days"] for r in rows) / w).quantize(Decimal("0.1")) if w else None
    return {"tasks": rows, "progress_pct": prog, "delayed": [r["name"] for r in rows if r["delayed"]],
            "planned_start": min((t.start for t in ts), default=None), "planned_end": max((t.end for t in ts), default=None)}

@router.post("/projects/{pid}/tasks", status_code=201)
def add_task(pid: str, b: TaskIn, request: Request, db=Depends(get_db), u=Depends(need("schedule.create"))):
    project_or_404(db, pid)
    if b.end < b.start: raise HTTPException(422, "تاريخ الانتهاء قبل البدء")
    check_pred(db, pid, None, b.predecessor_id)
    t = ScheduleTask(project_id=pid, **b.model_dump()); db.add(t); db.flush(); db.refresh(t)
    audit.log(db, u, "task.create", "schedule_task", t.id, after=tdto(t), request=request)
    return tdto(t)

class TaskPatch(BaseModel):
    version: int
    name: str | None = Field(default=None, min_length=1)
    start: date | None = None
    end: date | None = None
    progress: Decimal | None = Field(default=None, ge=0, le=100)
    predecessor_id: str | None = None
    reason: str = ""

@router.patch("/tasks/{tid}")
def patch_task(tid: str, b: TaskPatch, request: Request, db=Depends(get_db), u=Depends(need("schedule.update"))):
    t = db.get(ScheduleTask, tid)
    if not t or t.deleted: raise HTTPException(404, "المهمة غير موجودة")
    if t.version != b.version: raise HTTPException(409, "عُدّلت المهمة من مستخدم آخر، أعد التحميل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if {"start", "end"} & set(ch) and not b.reason.strip(): raise HTTPException(422, "سبب تغيير المواعيد إلزامي")
    if "predecessor_id" in ch: check_pred(db, t.project_id, t.id, ch["predecessor_id"])
    before = tdto(t)
    for k, v in ch.items(): setattr(t, k, v)
    if t.end < t.start: raise HTTPException(422, "تاريخ الانتهاء قبل البدء")
    t.version += 1; db.flush(); db.refresh(t)
    audit.log(db, u, "task.update", "schedule_task", t.id, before=before, after=tdto(t), reason=b.reason, request=request)
    return tdto(t)

@router.delete("/tasks/{tid}")
def del_task(tid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("schedule.delete"))):
    t = db.get(ScheduleTask, tid)
    if not t or t.deleted: raise HTTPException(404, "المهمة غير موجودة")
    if db.execute(select(ScheduleTask.id).where(ScheduleTask.predecessor_id == tid, ScheduleTask.deleted == False)).first():
        raise HTTPException(409, "توجد مهام تعتمد على هذه المهمة")
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الحذف إلزامي")
    before = tdto(t); t.deleted = True; db.flush()
    audit.log(db, u, "task.delete", "schedule_task", t.id, before=before, reason=reason, request=request)
    return {"ok": True}
