from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import (Item, StockMovement, PurchaseRequest, PurchaseOrder, POLine, SupplierInvoice, Party, Project,
                      JournalLine)
from ..deps import need
from .. import audit
from ..numbering import next_no
from .ledger import post

router = APIRouter(tags=["procurement"])
Z = Decimal(0)
HIGH = Decimal("500000")       # أمر شراء أعلى من هذا يتطلب purchasing.po_approve_high
q2 = lambda x: Decimal(x).quantize(Decimal("0.01"), ROUND_HALF_UP)

def idto(i):
    return {"id": i.id, "code": i.code, "name": i.name, "unit": i.unit, "min_stock": i.min_stock, "qty": i.qty, "value": i.value,
            "avg_cost": (q2(i.value / i.qty) if i.qty else Z), "low": i.qty <= i.min_stock, "active": i.active, "version": i.version}

def locked_item(db, iid):
    i = db.get(Item, iid, with_for_update=True)
    if not i or not i.active: raise HTTPException(422, "الصنف غير موجود أو موقوف")
    return i

# ---------------- الأصناف ----------------
class ItemIn(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=200)
    unit: str = ""
    min_stock: Decimal = Field(default=Decimal(0), ge=0)

@router.post("/items", status_code=201)
def new_item(b: ItemIn, request: Request, db=Depends(get_db), u=Depends(need("items.create"))):
    if db.execute(select(Item.id).where(Item.code == b.code)).first(): raise HTTPException(409, "كود الصنف مستخدم")
    i = Item(**b.model_dump()); db.add(i); db.flush(); db.refresh(i)
    audit.log(db, u, "item.create", "item", i.id, after=idto(i), request=request)
    return idto(i)

@router.get("/items")
def items(db=Depends(get_db), _=Depends(need("items.view"))):
    return [idto(i) for i in db.execute(select(Item).order_by(Item.code)).scalars()]

# ---------------- طلبات الشراء ----------------
class PRLine(BaseModel):
    item_id: str
    qty: Decimal = Field(gt=0)
    note: str = ""

class PRIn(BaseModel):
    project_id: str
    lines: list[PRLine] = Field(min_length=1)
    note: str = ""

def prdto(r): return {"id": r.id, "no": r.no, "project_id": r.project_id, "lines": r.lines, "status": r.status, "note": r.note}

@router.post("/purchase-requests", status_code=201)
def new_pr(b: PRIn, request: Request, db=Depends(get_db), u=Depends(need("purchasing.pr_create"))):
    if not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    for l in b.lines: locked_item(db, l.item_id)
    no = next_no(db, PurchaseRequest.no)
    r = PurchaseRequest(no=no, project_id=b.project_id, note=b.note, created_by=u.id,
                        lines=[{"item_id": l.item_id, "qty": str(l.qty), "note": l.note} for l in b.lines])
    db.add(r); db.flush()
    audit.log(db, u, "pr.create", "purchase_request", r.id, after=prdto(r), request=request)
    return prdto(r)

class Decide(BaseModel):
    approve: bool
    note: str = ""

@router.post("/purchase-requests/{rid}/decide")
def decide_pr(rid: str, b: Decide, request: Request, db=Depends(get_db), u=Depends(need("purchasing.pr_approve"))):
    r = db.get(PurchaseRequest, rid)
    if not r: raise HTTPException(404, "الطلب غير موجود")
    if r.status != "pending": raise HTTPException(409, "الطلب سبق البت فيه")
    if r.created_by == u.id: raise HTTPException(403, "لا يجوز البت في طلب أنشأته بنفسك")
    if not b.approve and not b.note: raise HTTPException(422, "سبب الرفض إلزامي")
    r.status = "approved" if b.approve else "rejected"; r.decided_by = u.id; db.flush()
    audit.log(db, u, "pr.decide", "purchase_request", r.id, after={"status": r.status}, reason=b.note, request=request)
    return prdto(r)

@router.get("/purchase-requests")
def list_pr(db=Depends(get_db), _=Depends(need("items.view"))):
    return [prdto(r) for r in db.execute(select(PurchaseRequest).order_by(PurchaseRequest.no.desc())).scalars()]

# ---------------- أوامر الشراء ----------------
class POLineIn(BaseModel):
    item_id: str
    qty: Decimal = Field(gt=0)
    price: Decimal = Field(ge=0)

class POIn(BaseModel):
    supplier_id: str
    project_id: str
    request_id: str | None = None
    lines: list[POLineIn] = Field(min_length=1)

def podto(db, o):
    rec = sum((q2(l.received * l.price) for l in o.lines), Z)
    inv = db.execute(select(func.coalesce(func.sum(SupplierInvoice.amount), 0)).where(SupplierInvoice.po_id == o.id)).scalar() or Z
    return {"id": o.id, "no": o.no, "supplier_id": o.supplier_id, "project_id": o.project_id, "status": o.status, "total": o.total,
            "received_value": rec, "invoiced": inv,
            "lines": [{"id": l.id, "item_id": l.item_id, "qty": l.qty, "price": l.price, "received": l.received} for l in o.lines]}

@router.post("/purchase-orders", status_code=201)
def new_po(b: POIn, request: Request, db=Depends(get_db), u=Depends(need("purchasing.po_create"))):
    s = db.get(Party, b.supplier_id)
    if not s or s.kind != "supplier": raise HTTPException(422, "المورد غير صحيح")
    if not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    pr = None
    if b.request_id:
        pr = db.get(PurchaseRequest, b.request_id, with_for_update=True)
        if not pr or pr.status != "approved": raise HTTPException(422, "طلب الشراء غير معتمد")
        if pr.project_id != b.project_id: raise HTTPException(422, "مشروع الطلب لا يطابق")
    for l in b.lines: locked_item(db, l.item_id)
    total = sum((q2(l.qty * l.price) for l in b.lines), Z)
    no = next_no(db, PurchaseOrder.no)
    o = PurchaseOrder(no=no, supplier_id=b.supplier_id, project_id=b.project_id, request_id=b.request_id, total=total, created_by=u.id,
                      lines=[POLine(item_id=l.item_id, qty=l.qty, price=l.price) for l in b.lines])
    db.add(o)
    if pr: pr.status = "ordered"
    db.flush()
    audit.log(db, u, "po.create", "purchase_order", o.id, after=podto(db, o), request=request)
    return podto(db, o)

@router.get("/purchase-orders")
def list_po(db=Depends(get_db), _=Depends(need("items.view"))):
    return [podto(db, o) for o in db.execute(select(PurchaseOrder).order_by(PurchaseOrder.no.desc())).scalars()]

@router.post("/purchase-orders/{oid}/approve")
def approve_po(oid: str, request: Request, db=Depends(get_db), u=Depends(need("purchasing.po_approve"))):
    o = db.get(PurchaseOrder, oid)
    if not o: raise HTTPException(404, "أمر الشراء غير موجود")
    if o.status != "draft": raise HTTPException(409, "أمر الشراء ليس مسودة")
    if o.created_by == u.id: raise HTTPException(403, "لا يجوز اعتماد أمر أنشأته بنفسك")
    if o.total > HIGH and "purchasing.po_approve_high" not in u.permissions():
        raise HTTPException(403, "أمر بهذه القيمة يتطلب purchasing.po_approve_high")
    o.status, o.approved_by = "approved", u.id; db.flush()
    audit.log(db, u, "po.approve", "purchase_order", o.id, after={"status": "approved", "total": o.total}, request=request)
    return podto(db, o)

@router.post("/purchase-orders/{oid}/cancel")
def cancel_po(oid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("purchasing.po_approve"))):
    o = db.get(PurchaseOrder, oid)
    if not o: raise HTTPException(404, "أمر الشراء غير موجود")
    if o.status not in ("draft", "approved") or any(l.received > 0 for l in o.lines): raise HTTPException(409, "لا يمكن إلغاء أمر استُلم منه")
    if len(reason) < 3: raise HTTPException(422, "سبب الإلغاء إلزامي")
    o.status = "cancelled"; db.flush()
    audit.log(db, u, "po.cancel", "purchase_order", o.id, after={"status": "cancelled"}, reason=reason, request=request)
    return podto(db, o)

# ---------------- الاستلام ----------------
class RecLine(BaseModel):
    po_line_id: int
    qty: Decimal = Field(gt=0)

class RecIn(BaseModel):
    date: date
    lines: list[RecLine] = Field(min_length=1)

@router.post("/purchase-orders/{oid}/receive", status_code=201)
def receive(oid: str, b: RecIn, request: Request, db=Depends(get_db), u=Depends(need("purchasing.receive"))):
    o = db.get(PurchaseOrder, oid, with_for_update=True)
    if not o: raise HTTPException(404, "أمر الشراء غير موجود")
    if o.status != "approved": raise HTTPException(409, "أمر الشراء غير معتمد أو مغلق")
    by = {l.id: l for l in o.lines}; total = Z; moves = []
    for r in b.lines:
        l = by.get(r.po_line_id)
        if not l: raise HTTPException(422, "بند غير تابع للأمر")
        if l.received + r.qty > l.qty: raise HTTPException(422, "الكمية المستلمة تتجاوز المطلوب في الأمر")
        v = q2(r.qty * l.price); it = locked_item(db, l.item_id)
        it.qty += r.qty; it.value += v; l.received += r.qty; total += v; moves.append((it, r.qty, v))
    z = Z
    e = post(db, u, b.date, f"استلام مواد - أمر شراء {o.no}", [{"account_code": "1300", "debit": total, "credit": z},
             {"account_code": "2100", "debit": z, "credit": total}], o.project_id, source="receipt")
    for it, q, v in moves:
        db.add(StockMovement(item_id=it.id, kind="in", qty=q, amount=v, project_id=o.project_id, ref=f"PO-{o.no}", entry_id=e.id, created_by=u.id))
    if all(l.received >= l.qty for l in o.lines): o.status = "closed"
    db.flush()
    audit.log(db, u, "po.receive", "purchase_order", o.id, after={"value": total, "entry_no": e.no, "status": o.status}, request=request)
    return podto(db, o)

# ---------------- فواتير الموردين والسداد ----------------
class SInvIn(BaseModel):
    ref: str = Field(min_length=1, max_length=80)
    date: date
    amount: Decimal = Field(gt=0)

def sdto(i): return {"id": i.id, "po_id": i.po_id, "ref": i.ref, "date": i.date, "amount": i.amount, "paid": i.paid, "outstanding": i.amount - i.paid}

@router.post("/purchase-orders/{oid}/invoices", status_code=201)
def new_sinv(oid: str, b: SInvIn, request: Request, db=Depends(get_db), u=Depends(need("purchasing.invoice"))):
    o = db.get(PurchaseOrder, oid, with_for_update=True)
    if not o: raise HTTPException(404, "أمر الشراء غير موجود")
    d = podto(db, o)    # المطابقة الثلاثية: أمر شراء + استلام + فاتورة
    if d["invoiced"] + b.amount > d["received_value"]:
        raise HTTPException(422, "قيمة الفاتورة تتجاوز قيمة ما تم استلامه فعليًا ولم يُفوتر")
    if db.execute(select(SupplierInvoice.id).where(SupplierInvoice.po_id == oid, SupplierInvoice.ref == b.ref)).first():
        raise HTTPException(409, "رقم الفاتورة مسجل من قبل لهذا الأمر")
    i = SupplierInvoice(po_id=oid, created_by=u.id, **b.model_dump()); db.add(i); db.flush()
    audit.log(db, u, "supplier_invoice.create", "supplier_invoice", i.id, after=sdto(i), request=request)
    return sdto(i)

@router.get("/purchase-orders/{oid}/invoices")
def list_sinv(oid: str, db=Depends(get_db), _=Depends(need("items.view"))):
    return [sdto(i) for i in db.execute(select(SupplierInvoice).where(SupplierInvoice.po_id == oid).order_by(SupplierInvoice.date)).scalars()]

class SPay(BaseModel):
    date: date
    amount: Decimal = Field(gt=0)
    method: str = "bank"

@router.post("/supplier-invoices/{iid}/pay", status_code=201)
def pay_sinv(iid: str, b: SPay, request: Request, db=Depends(get_db), u=Depends(need("purchasing.pay"))):
    i = db.get(SupplierInvoice, iid, with_for_update=True)
    if not i: raise HTTPException(404, "الفاتورة غير موجودة")
    if b.method not in ("cash", "bank"): raise HTTPException(422, "طريقة الدفع غير صحيحة")
    if i.paid + b.amount > i.amount: raise HTTPException(422, "المبلغ يتجاوز المتبقي")
    o = db.get(PurchaseOrder, i.po_id); z = Z
    e = post(db, u, b.date, f"سداد فاتورة مورد {i.ref}", [{"account_code": "2100", "debit": b.amount, "credit": z},
             {"account_code": "1110" if b.method == "cash" else "1100", "debit": z, "credit": b.amount}], o.project_id, source="supplier_payment")
    i.paid += b.amount; db.flush()
    audit.log(db, u, "supplier_invoice.pay", "supplier_invoice", i.id, after={"paid": i.paid, "entry_no": e.no}, request=request)
    return sdto(i)

# ---------------- الصرف والجرد ----------------
class Issue(BaseModel):
    item_id: str
    project_id: str
    qty: Decimal = Field(gt=0)
    date: date
    note: str = ""

@router.post("/stock/issue", status_code=201)
def issue(b: Issue, request: Request, db=Depends(get_db), u=Depends(need("stock.issue"))):
    if not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    it = locked_item(db, b.item_id)
    if b.qty > it.qty: raise HTTPException(422, f"الرصيد لا يكفي: المتاح {it.qty}")      # لا رصيد سالب
    cost = it.value if b.qty == it.qty else q2(it.value * b.qty / it.qty); z = Z
    e = post(db, u, b.date, f"صرف مواد {it.code} لمشروع", [{"account_code": "5100", "debit": cost, "credit": z},
             {"account_code": "1300", "debit": z, "credit": cost}], b.project_id, source="issue")
    it.qty -= b.qty; it.value -= cost
    m = StockMovement(item_id=it.id, kind="out", qty=-b.qty, amount=-cost, project_id=b.project_id, note=b.note, entry_id=e.id, created_by=u.id)
    db.add(m); db.flush()
    audit.log(db, u, "stock.issue", "item", it.id, after={"qty": b.qty, "cost": cost, "project": b.project_id, "entry_no": e.no}, request=request)
    return {"item": idto(it), "cost": cost, "entry_id": e.id}

class Adjust(BaseModel):
    item_id: str
    counted_qty: Decimal = Field(ge=0)
    date: date
    unit_cost: Decimal | None = Field(default=None, ge=0)     # مطلوب فقط عند الزيادة على صنف رصيده صفر
    reason: str = Field(min_length=3)

def apply_adjust(db, u, it, counted_qty, d, unit_cost, reason, request, ref=""):
    """تسوية صنف إلى الكمية المعدودة (قيد + حركة + تدقيق). الصنف يجب أن يكون مقفولًا (with_for_update)."""
    diff = counted_qty - it.qty
    if diff == 0: raise HTTPException(422, "لا فرق بين الجرد والرصيد")
    if diff < 0: amt = it.value if counted_qty == 0 else q2(it.value * (-diff) / it.qty)
    else:
        uc = (it.value / it.qty) if it.qty else unit_cost
        if uc is None: raise HTTPException(422, f"حدد unit_cost للصنف {it.code} (رصيده صفر)")
        amt = q2(diff * uc)
    z = Z
    lines = ([{"account_code": "5900", "debit": amt, "credit": z}, {"account_code": "1300", "debit": z, "credit": amt}] if diff < 0 else
             [{"account_code": "1300", "debit": amt, "credit": z}, {"account_code": "5900", "debit": z, "credit": amt}])
    e = post(db, u, d, f"تسوية جرد {it.code}: {reason}", lines, source="stock_adjust")
    sign = -1 if diff < 0 else 1
    it.qty = counted_qty; it.value += sign * amt
    db.add(StockMovement(item_id=it.id, kind="adjust", qty=diff, amount=sign * amt, ref=ref, note=reason, entry_id=e.id, created_by=u.id)); db.flush()
    audit.log(db, u, "stock.adjust", "item", it.id, after={"diff": diff, "amount": sign * amt, "entry_no": e.no, "ref": ref}, reason=reason, request=request)
    return diff, sign * amt

@router.post("/stock/adjust", status_code=201)
def adjust(b: Adjust, request: Request, db=Depends(get_db), u=Depends(need("stock.adjust"))):
    it = locked_item(db, b.item_id)
    apply_adjust(db, u, it, b.counted_qty, b.date, b.unit_cost, b.reason, request)
    return idto(it)

@router.get("/reports/stock")
def stock_report(db=Depends(get_db), _=Depends(need("stock.view"))):
    its = [idto(i) for i in db.execute(select(Item).order_by(Item.code)).scalars()]
    book = sum((Decimal(str(i["value"])) for i in its), Z)
    gl = db.execute(select(func.coalesce(func.sum(JournalLine.debit - JournalLine.credit), 0)).where(JournalLine.account_code == "1300")).scalar() or Z
    return {"items": its, "stock_value": book, "ledger_1300": gl, "difference": gl - book,
            "low_stock": [i["code"] for i in its if i["low"] and i["active"]]}
