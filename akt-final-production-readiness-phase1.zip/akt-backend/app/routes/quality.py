from datetime import date
from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import Inspection, Snag, Handover, Project, Contract, Invoice
from ..deps import need
from .. import audit
from ..numbering import next_no

router = APIRouter(tags=["quality"])
HOCK = {"initial": ["اكتمال الأعمال حسب العقد والمقايسة", "إغلاق ملاحظات الاستشاري والعميل", "اختبار الأنظمة الكهربائية والميكانيكية والإطفاء",
                    "تسليم رسومات ما بعد التنفيذ (As-Built)", "تسليم الكتالوجات وشهادات الضمان", "تنظيف الموقع وإزالة المخلفات"],
        "final": ["انتهاء فترة الصيانة دون عيوب جوهرية", "إصلاح كل عيوب فترة الصيانة", "إخلاء طرف المقاولين من الباطن والموردين",
                  "تسوية المستخلص الختامي", "تسليم المفاتيح والمستندات النهائية"]}

def proj(db, pid):
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(422, "المشروع غير موجود")
    return p

# ---------------- طلبات الفحص ----------------
def idto(i): return {"id": i.id, "ref": f"IR-{i.no:03d}", "project_id": i.project_id, "item": i.item, "kind": i.kind, "date": i.date,
                     "inspector": i.inspector, "status": i.status, "note": i.note}

class InspIn(BaseModel):
    project_id: str
    item: str = Field(min_length=1, max_length=300)
    kind: str
    date: date
    inspector: str = ""

@router.post("/inspections", status_code=201)
def new_insp(b: InspIn, request: Request, db=Depends(get_db), u=Depends(need("quality.create"))):
    proj(db, b.project_id)
    if b.kind not in ("work", "material"): raise HTTPException(422, "نوع الفحص: work أو material")
    i = Inspection(no=next_no(db, Inspection.no), created_by=u.id, **b.model_dump()); db.add(i); db.flush()
    audit.log(db, u, "inspection.create", "inspection", i.id, after=idto(i), request=request)
    return idto(i)

@router.get("/inspections")
def list_insp(project_id: str | None = None, db=Depends(get_db), _=Depends(need("quality.view"))):
    q = select(Inspection).order_by(Inspection.no.desc())
    if project_id: q = q.where(Inspection.project_id == project_id)
    return [idto(i) for i in db.execute(q).scalars()]

class Decision(BaseModel):
    result: str                       # accepted | accepted_notes | rejected
    note: str = ""
    due: date | None = None

def sdto(s):
    return {"id": s.id, "ref": f"NCR-{s.no:03d}", "project_id": s.project_id, "inspection_id": s.inspection_id, "location": s.location,
            "description": s.description, "severity": s.severity, "due": s.due, "status": s.status, "responsible": s.responsible,
            "opened": s.opened, "closed": s.closed, "closure_note": s.closure_note, "overdue": s.status == "open" and bool(s.due) and s.due < date.today(),
            "version": s.version}

@router.post("/inspections/{iid}/decide")
def decide(iid: str, b: Decision, request: Request, db=Depends(get_db), u=Depends(need("quality.decide"))):
    i = db.get(Inspection, iid, with_for_update=True)
    if not i: raise HTTPException(404, "طلب الفحص غير موجود")
    if i.status != "pending": raise HTTPException(409, "سبق البت في الفحص")
    if b.result not in ("accepted", "accepted_notes", "rejected"): raise HTTPException(422, "نتيجة غير صحيحة")
    snag = None
    if b.result != "accepted":
        if not b.note.strip(): raise HTTPException(422, "الملاحظات إلزامية عند القبول بملاحظات أو الرفض")
        snag = Snag(no=next_no(db, Snag.no), project_id=i.project_id, inspection_id=i.id, location=i.item, description=b.note,
                    severity="high" if b.result == "rejected" else "medium", due=b.due, opened=date.today())
        db.add(snag)
    i.status, i.note, i.decided_by = b.result, b.note, u.id; db.flush()   # القرار والملاحظة الناتجة في معاملة واحدة
    audit.log(db, u, "inspection.decide", "inspection", i.id, after={"status": i.status, "snag": snag.no if snag else None}, reason=b.note, request=request)
    return {"inspection": idto(i), "snag": sdto(snag) if snag else None}

# ---------------- الملاحظات ----------------
class SnagIn(BaseModel):
    project_id: str
    location: str = Field(min_length=1, max_length=300)
    description: str = Field(min_length=1)
    severity: str
    due: date | None = None
    responsible: str = ""

@router.post("/snags", status_code=201)
def new_snag(b: SnagIn, request: Request, db=Depends(get_db), u=Depends(need("quality.create"))):
    proj(db, b.project_id)
    if b.severity not in ("low", "medium", "high"): raise HTTPException(422, "الخطورة: low/medium/high")
    s = Snag(no=next_no(db, Snag.no), opened=date.today(), **b.model_dump()); db.add(s); db.flush()
    audit.log(db, u, "snag.create", "snag", s.id, after=sdto(s), request=request)
    return sdto(s)

@router.get("/snags")
def list_snags(project_id: str | None = None, status: str | None = None, db=Depends(get_db), _=Depends(need("quality.view"))):
    q = select(Snag).order_by(Snag.no.desc())
    if project_id: q = q.where(Snag.project_id == project_id)
    if status: q = q.where(Snag.status == status)
    return [sdto(s) for s in db.execute(q).scalars()]

class SnagAct(BaseModel):
    version: int
    action: str                       # close | reopen
    note: str = Field(min_length=3)

@router.post("/snags/{sid}/act")
def snag_act(sid: str, b: SnagAct, request: Request, db=Depends(get_db), u=Depends(need("quality.close"))):
    s = db.get(Snag, sid)
    if not s: raise HTTPException(404, "الملاحظة غير موجودة")
    if s.version != b.version: raise HTTPException(409, "عُدّلت الملاحظة من مستخدم آخر، أعد التحميل")
    before = sdto(s)
    if b.action == "close":
        if s.status != "open": raise HTTPException(409, "الملاحظة مغلقة")
        s.status, s.closed, s.closure_note = "closed", date.today(), b.note
    elif b.action == "reopen":
        if s.status != "closed": raise HTTPException(409, "الملاحظة مفتوحة")
        s.status, s.closed = "open", None
    else: raise HTTPException(422, "إجراء غير معروف")
    s.version += 1; db.flush()
    audit.log(db, u, f"snag.{b.action}", "snag", s.id, before=before, after=sdto(s), reason=b.note, request=request)
    return sdto(s)

# ---------------- محاضر الاستلام ----------------
def hdto(db, h):
    items = HOCK[h.kind]
    open_snags = db.execute(select(Snag.id).where(Snag.project_id == h.project_id, Snag.status == "open")).all()
    warranty_end = (h.date + relativedelta(months=h.warranty_months)) if h.date and h.warranty_months else None
    return {"id": h.id, "project_id": h.project_id, "kind": h.kind, "status": h.status, "date": h.date, "warranty_months": h.warranty_months,
            "warranty_end": warranty_end, "checklist": [{"i": n, "text": t, "done": bool(h.checks.get(str(n)))} for n, t in enumerate(items)],
            "open_snags": len(open_snags), "version": h.version}

class HOIn(BaseModel):
    project_id: str
    kind: str
    warranty_months: int = Field(default=0, ge=0, le=120)

@router.post("/handovers", status_code=201)
def new_ho(b: HOIn, request: Request, db=Depends(get_db), u=Depends(need("handover.create"))):
    proj(db, b.project_id)
    if b.kind not in HOCK: raise HTTPException(422, "نوع الاستلام: initial أو final")
    if db.execute(select(Handover.id).where(Handover.project_id == b.project_id, Handover.kind == b.kind)).first():
        raise HTTPException(409, "يوجد محضر من هذا النوع للمشروع")
    h = Handover(project_id=b.project_id, kind=b.kind, warranty_months=b.warranty_months, checks={}); db.add(h); db.flush()
    audit.log(db, u, "handover.create", "handover", h.id, after=hdto(db, h), request=request)
    return hdto(db, h)

@router.get("/handovers")
def list_ho(db=Depends(get_db), _=Depends(need("handover.view"))):
    return [hdto(db, h) for h in db.execute(select(Handover).order_by(Handover.project_id, Handover.kind.desc())).scalars()]

class Check(BaseModel):
    index: int
    value: bool

@router.post("/handovers/{hid}/check")
def check(hid: str, b: Check, request: Request, db=Depends(get_db), u=Depends(need("handover.check"))):
    h = db.get(Handover, hid)
    if not h: raise HTTPException(404, "المحضر غير موجود")
    if h.status == "done": raise HTTPException(409, "المحضر معتمد ولا يُعدَّل")
    if not 0 <= b.index < len(HOCK[h.kind]): raise HTTPException(422, "بند غير موجود")
    h.checks = {**h.checks, str(b.index): b.value}; h.version += 1; db.flush()
    audit.log(db, u, "handover.check", "handover", h.id, after={"index": b.index, "value": b.value}, request=request)
    return hdto(db, h)

class Complete(BaseModel):
    date: date
    override_reason: str = ""

@router.post("/handovers/{hid}/complete")
def complete(hid: str, b: Complete, request: Request, db=Depends(get_db), u=Depends(need("handover.complete"))):
    h = db.get(Handover, hid, with_for_update=True)
    if not h: raise HTTPException(404, "المحضر غير موجود")
    if h.status == "done": raise HTTPException(409, "المحضر معتمد من قبل")
    miss = [t for n, t in enumerate(HOCK[h.kind]) if not h.checks.get(str(n))]
    if miss: raise HTTPException(422, f"بنود غير مستوفاة ({len(miss)}): " + "، ".join(miss))
    n_open = len(db.execute(select(Snag.id).where(Snag.project_id == h.project_id, Snag.status == "open")).all())
    if n_open: raise HTTPException(422, f"توجد {n_open} ملاحظات مفتوحة على المشروع")
    override = ""
    if h.kind == "final":
        ini = db.execute(select(Handover).where(Handover.project_id == h.project_id, Handover.kind == "initial")).scalar()
        if not ini or ini.status != "done": raise HTTPException(422, "لا يتم الاستلام النهائي قبل اعتماد الاستلام الابتدائي")
        problems = []
        wend = ini.date + relativedelta(months=ini.warranty_months) if ini.date and ini.warranty_months else None
        if wend and b.date < wend: problems.append(f"لم تنتهِ فترة الصيانة حتى {wend.isoformat()}")
        for c in db.execute(select(Contract).where(Contract.project_id == h.project_id, Contract.kind == "client", Contract.status == "active")).scalars():
            if not db.execute(select(Invoice.id).where(Invoice.contract_id == c.id, Invoice.final == True, Invoice.status.in_(("approved", "submitted")))).first():
                problems.append(f"لا يوجد مستخلص ختامي معتمد للعقد {c.code}")
        if problems:
            if not (b.override_reason.strip() and "handover.override" in u.permissions()):
                raise HTTPException(422, "؛ ".join(problems) + ("" if "handover.override" not in u.permissions() else " — يمكن التجاوز بسبب مسجل"))
            override = b.override_reason.strip()
    h.status, h.date, h.override_reason = "done", b.date, override
    if h.kind == "final": db.get(Project, h.project_id).status = "completed"
    h.version += 1; db.flush()
    audit.log(db, u, "handover.complete", "handover", h.id, after=hdto(db, h), reason=override, request=request)
    return hdto(db, h)
