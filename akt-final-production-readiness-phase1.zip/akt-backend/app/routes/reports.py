from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select, func
from ..db import get_db
from ..models import Account, JournalEntry, JournalLine, Guarantee, Invoice, Contract, Payment, Project
from ..deps import need
from .. import audit
from .invoices import paid

router = APIRouter(tags=["reports"])
Z = Decimal(0)

# ---------- الضمانات ----------
class GIn(BaseModel):
    kind: str
    project_id: str
    contract_id: str | None = None
    party_id: str | None = None
    bank: str = ""
    ref: str = ""
    amount: Decimal = Field(gt=0)
    issue_date: date
    expiry_date: date
    @model_validator(mode="after")
    def ok(self):
        if self.kind not in ("bid", "performance", "advance", "insurance"): raise ValueError("نوع الضمان غير صحيح")
        if self.expiry_date < self.issue_date: raise ValueError("تاريخ الانتهاء قبل الإصدار")
        return self

def gdto(g):
    return {"id": g.id, "kind": g.kind, "project_id": g.project_id, "contract_id": g.contract_id, "party_id": g.party_id, "bank": g.bank,
            "ref": g.ref, "amount": g.amount, "remaining": g.remaining, "issue_date": g.issue_date, "expiry_date": g.expiry_date,
            "status": g.status, "days_left": (g.expiry_date - date.today()).days}

@router.post("/guarantees", status_code=201)
def new_g(b: GIn, request: Request, db=Depends(get_db), u=Depends(need("guarantees.create"))):
    if not db.get(Project, b.project_id): raise HTTPException(422, "المشروع غير موجود")
    g = Guarantee(**b.model_dump(), remaining=b.amount); db.add(g); db.flush()
    audit.log(db, u, "guarantee.create", "guarantee", g.id, after=gdto(g), request=request)
    return gdto(g)

@router.get("/guarantees")
def list_g(expiring_days: int | None = None, db=Depends(get_db), _=Depends(need("guarantees.view"))):
    q = select(Guarantee).order_by(Guarantee.expiry_date)
    if expiring_days is not None:
        q = q.where(Guarantee.status == "active", Guarantee.expiry_date <= date.today() + timedelta(days=expiring_days))
    return [gdto(g) for g in db.execute(q).scalars()]

class GAct(BaseModel):
    action: str                      # renew | release | claim | reduce
    new_expiry: date | None = None
    amount: Decimal | None = Field(default=None, gt=0)
    reason: str = Field(min_length=3)

@router.post("/guarantees/{gid}/act")
def act_g(gid: str, b: GAct, request: Request, db=Depends(get_db), u=Depends(need("guarantees.update"))):
    g = db.get(Guarantee, gid)
    if not g: raise HTTPException(404, "الضمان غير موجود")
    if g.status not in ("active", "renewed"): raise HTTPException(409, "الضمان منتهٍ")
    before = gdto(g)
    if b.action == "renew":
        if not b.new_expiry or b.new_expiry <= g.expiry_date: raise HTTPException(422, "تاريخ التجديد يجب أن يكون لاحقًا")
        g.expiry_date = b.new_expiry; g.status = "renewed"
    elif b.action == "reduce":
        if not b.amount or b.amount > g.remaining: raise HTTPException(422, "مبلغ التخفيض غير صالح")
        g.remaining = g.remaining - b.amount
        if g.remaining == 0: g.status = "released"
    elif b.action in ("release", "claim"):
        g.status = "released" if b.action == "release" else "claimed"; g.remaining = Z
    else: raise HTTPException(422, "إجراء غير معروف")
    db.flush()
    audit.log(db, u, f"guarantee.{b.action}", "guarantee", g.id, before=before, after=gdto(g), reason=b.reason, request=request)
    return gdto(g)

# ---------- التدفق النقدي 30/60/90 ----------
@router.get("/reports/cashflow")
def cashflow(today: date | None = None, db=Depends(get_db), _=Depends(need("cashflow.view"))):
    t = today or date.today()
    buckets = {k: {"in": Z, "out": Z} for k in ("overdue", "d0_30", "d31_60", "d61_90", "later")}
    def put(due, amt, side):
        n = (due - t).days
        k = "overdue" if n < 0 else "d0_30" if n <= 30 else "d31_60" if n <= 60 else "d61_90" if n <= 90 else "later"
        buckets[k][side] += amt
    rows = db.execute(select(Invoice, Contract).join(Contract, Contract.id == Invoice.contract_id)
                      .where(Invoice.status.in_(("approved", "submitted")))).all()
    for i, c in rows:
        rest = i.net - paid(db, i.id)
        if rest > 0: put(i.date + timedelta(days=c.payment_days), rest, "in" if c.kind == "client" else "out")
    for k, v in buckets.items(): v["net"] = v["in"] - v["out"]
    cash = db.execute(select(func.coalesce(func.sum(JournalLine.debit - JournalLine.credit), 0))
                      .where(JournalLine.account_code.in_(("1100", "1110")))).scalar() or Z
    run, proj = cash, {}
    for k in ("d0_30", "d31_60", "d61_90"):
        run += buckets["overdue"]["net"] if k == "d0_30" else 0
        run += buckets[k]["net"]; proj[k] = run
    return {"as_of": t, "opening_cash": cash, "buckets": buckets, "projected_cash": proj}

# ---------- القوائم المالية ----------
def balances(db, upto=None, frm=None, project_id=None):
    q = (select(JournalLine.account_code, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
         .join(JournalEntry, JournalEntry.id == JournalLine.entry_id).group_by(JournalLine.account_code))
    if upto: q = q.where(JournalEntry.date <= upto)
    if frm: q = q.where(JournalEntry.date >= frm)
    if project_id: q = q.where(JournalEntry.project_id == project_id)
    return {a: (d or Z, c or Z) for a, d, c in db.execute(q).all()}

@router.get("/reports/general-ledger/{code}")
def gl(code: str, frm: date | None = None, to: date | None = None, limit: int = 5000, offset: int = 0,
       db=Depends(get_db), _=Depends(need("reports.view"))):
    """دفتر الأستاذ: الرصيد الجاري يُحسب في قاعدة البيانات (نافذة) وتُرجَع صفحة بحد أقصى، والرصيد الختامي دائمًا للنطاق كله."""
    a = db.get(Account, code)
    if not a: raise HTTPException(404, "الحساب غير موجود")
    limit = max(1, min(limit, 20000)); offset = max(0, offset)
    opening = Z
    if frm:
        od, oc = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
                            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                            .where(JournalLine.account_code == code, JournalEntry.date < frm)).one()
        opening = od - oc
    cond = [JournalLine.account_code == code]
    if frm: cond.append(JournalEntry.date >= frm)
    if to: cond.append(JournalEntry.date <= to)
    td, tc, total = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0), func.count())
                               .join(JournalEntry, JournalEntry.id == JournalLine.entry_id).where(*cond)).one()
    order = (JournalEntry.date, JournalEntry.no, JournalLine.id)
    running = func.sum(JournalLine.debit - JournalLine.credit).over(order_by=order)
    q = (select(JournalEntry.date, JournalEntry.no, JournalEntry.description, JournalLine.debit, JournalLine.credit, running.label("run"))
         .join(JournalLine, JournalLine.entry_id == JournalEntry.id).where(*cond).order_by(*order).limit(limit).offset(offset))
    rows = [{"date": d, "entry_no": n, "description": ds, "debit": dr, "credit": cr, "balance": opening + r}
            for d, n, ds, dr, cr, r in db.execute(q).all()]
    return {"account": code, "name": a.name, "opening": opening, "rows": rows, "closing": opening + td - tc,
            "total_rows": total, "offset": offset, "returned": len(rows), "truncated": offset + len(rows) < total}

@router.get("/reports/income-statement")
def income(frm: date | None = None, to: date | None = None, project_id: str | None = None, db=Depends(get_db), _=Depends(need("reports.view"))):
    b = balances(db, upto=to, frm=frm, project_id=project_id)
    accts = {a.code: a for a in db.execute(select(Account)).scalars()}
    rev = [{"code": k, "name": accts[k].name, "amount": c - d} for k, (d, c) in sorted(b.items()) if accts[k].type == "revenue"]
    exp = [{"code": k, "name": accts[k].name, "amount": d - c} for k, (d, c) in sorted(b.items()) if accts[k].type == "expense"]
    tr, te = sum((r["amount"] for r in rev), Z), sum((r["amount"] for r in exp), Z)
    return {"revenue": rev, "expenses": exp, "total_revenue": tr, "total_expenses": te, "net_income": tr - te}

@router.get("/reports/balance-sheet")
def balance_sheet(as_of: date | None = None, db=Depends(get_db), _=Depends(need("reports.view"))):
    b = balances(db, upto=as_of or date.today())
    accts = {a.code: a for a in db.execute(select(Account)).scalars()}
    out = {"asset": [], "liability": [], "equity": []}; ni = Z
    for k, (d, c) in sorted(b.items()):
        t = accts[k].type
        if t == "asset": out[t].append({"code": k, "name": accts[k].name, "amount": d - c})
        elif t in ("liability", "equity"): out[t].append({"code": k, "name": accts[k].name, "amount": c - d})
        elif t == "revenue": ni += c - d
        else: ni -= d - c
    ta = sum((r["amount"] for r in out["asset"]), Z)
    tl = sum((r["amount"] for r in out["liability"]), Z)
    te = sum((r["amount"] for r in out["equity"]), Z) + ni
    return {**out, "current_earnings": ni, "total_assets": ta, "total_liabilities": tl, "total_equity": te, "balanced": ta == tl + te}

@router.get("/reports/project/{pid}")
def project_dash(pid: str, db=Depends(get_db), _=Depends(need("reports.view"))):
    p = db.get(Project, pid)
    if not p: raise HTTPException(404, "المشروع غير موجود")
    b = balances(db, project_id=pid)
    accts = {a.code: a.type for a in db.execute(select(Account)).scalars()}
    rev = sum((c - d for k, (d, c) in b.items() if accts[k] == "revenue"), Z)
    cost = sum((d - c for k, (d, c) in b.items() if accts[k] == "expense"), Z)
    inv = db.execute(select(Invoice, Contract).join(Contract, Contract.id == Invoice.contract_id)
                     .where(Contract.project_id == pid, Contract.kind == "client", Invoice.status.in_(("approved", "submitted")))).all()
    billed = sum((i.gross for i, _ in inv), Z); collected = sum((paid(db, i.id) for i, _ in inv), Z)
    alerts = []
    if p.budget and cost > p.budget: alerts.append("التكاليف تجاوزت الموازنة")
    return {"project": p.name, "budget": p.budget, "contract_value": p.contract_value, "revenue": rev, "cost": cost, "profit": rev - cost,
            "billed": billed, "collected": collected, "budget_used_pct": (cost / p.budget * 100).quantize(Decimal("0.1")) if p.budget else None,
            "alerts": alerts}

@router.get("/reports/alerts")
def alerts(db=Depends(get_db), u=Depends(need("reports.view"))):
    t = date.today(); out = []
    for g in db.execute(select(Guarantee).where(Guarantee.status.in_(("active", "renewed")), Guarantee.expiry_date <= t + timedelta(days=30))).scalars():
        out.append({"type": "guarantee_expiry", "id": g.id, "days_left": (g.expiry_date - t).days})
    for i, c in db.execute(select(Invoice, Contract).join(Contract, Contract.id == Invoice.contract_id)
                           .where(Invoice.status.in_(("approved", "submitted")))).all():
        if i.date + timedelta(days=c.payment_days) < t and i.net - paid(db, i.id) > 0:
            out.append({"type": "overdue_" + ("receivable" if c.kind == "client" else "payable"), "id": i.id, "amount": i.net - paid(db, i.id)})
    return out
