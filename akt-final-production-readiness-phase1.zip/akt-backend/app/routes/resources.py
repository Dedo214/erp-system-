from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Equipment, EquipmentUsage, Worker, LaborDay, Custody, CustodyExpense, Project
from ..deps import need
from .. import audit
from .ledger import post

router = APIRouter(tags=["resources"])
Z = Decimal(0)
q2 = lambda x: Decimal(x).quantize(Decimal("0.01"))

def proj(db, pid, required=True):
    if pid is None and not required: return None
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(422, "المشروع غير موجود")
    return p

def row(o, *cols): return {c: getattr(o, c) for c in cols}

# ---------------- المعدات ----------------
EQ = ("id", "name", "type", "daily_rate", "status", "maint_interval_days", "last_maint", "version")
def edto(e):
    due = (e.last_maint + timedelta(days=e.maint_interval_days)) if e.last_maint else None
    return {**row(e, *EQ), "next_maint": due, "maint_overdue": bool(due and due < date.today())}

class EQIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    type: str = ""
    daily_rate: Decimal = Field(default=Z, ge=0)
    maint_interval_days: int = Field(default=90, ge=1, le=3650)
    last_maint: date | None = None

@router.post("/equipment", status_code=201)
def new_eq(b: EQIn, request: Request, db=Depends(get_db), u=Depends(need("equipment.create"))):
    if db.execute(select(Equipment.id).where(Equipment.name == b.name)).first(): raise HTTPException(409, "اسم المعدة مستخدم")
    e = Equipment(**b.model_dump()); db.add(e); db.flush(); db.refresh(e)
    audit.log(db, u, "equipment.create", "equipment", e.id, after=edto(e), request=request)
    return edto(e)

@router.get("/equipment")
def list_eq(db=Depends(get_db), _=Depends(need("equipment.view"))):
    return [edto(e) for e in db.execute(select(Equipment).order_by(Equipment.name)).scalars()]

class EQPatch(BaseModel):
    version: int
    daily_rate: Decimal | None = Field(default=None, ge=0)
    status: str | None = None
    maint_interval_days: int | None = Field(default=None, ge=1, le=3650)
    reason: str = ""

@router.patch("/equipment/{eid}")
def patch_eq(eid: str, b: EQPatch, request: Request, db=Depends(get_db), u=Depends(need("equipment.update"))):
    e = db.get(Equipment, eid)
    if not e: raise HTTPException(404, "المعدة غير موجودة")
    if e.version != b.version: raise HTTPException(409, "عُدّلت المعدة من مستخدم آخر، أعد التحميل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if ch.get("status") not in (None, "working", "maintenance", "idle"): raise HTTPException(422, "حالة غير صحيحة")
    if "daily_rate" in ch and not b.reason.strip(): raise HTTPException(422, "سبب تغيير الأجر اليومي إلزامي")
    before = edto(e)
    for k, v in ch.items(): setattr(e, k, v)
    e.version += 1; db.flush(); db.refresh(e)
    audit.log(db, u, "equipment.update", "equipment", e.id, before=before, after=edto(e), reason=b.reason, request=request)
    return edto(e)

class Maint(BaseModel):
    date: date
    note: str = Field(min_length=3)

@router.post("/equipment/{eid}/maintenance")
def maintenance(eid: str, b: Maint, request: Request, db=Depends(get_db), u=Depends(need("equipment.update"))):
    e = db.get(Equipment, eid)
    if not e: raise HTTPException(404, "المعدة غير موجودة")
    if b.date > date.today(): raise HTTPException(422, "تاريخ مستقبلي")
    before = edto(e); e.last_maint = b.date; e.status = "working"; e.version += 1; db.flush()
    audit.log(db, u, "equipment.maintenance", "equipment", e.id, before=before, after=edto(e), reason=b.note, request=request)
    return edto(e)

class EUIn(BaseModel):
    equipment_id: str
    project_id: str
    date: date
    days: Decimal = Field(gt=0, le=31)

@router.post("/equipment/usage", status_code=201)
def usage(b: EUIn, request: Request, db=Depends(get_db), u=Depends(need("equipment.usage"))):
    e = db.get(Equipment, b.equipment_id)
    if not e: raise HTTPException(422, "المعدة غير موجودة")
    proj(db, b.project_id)
    if e.status != "working": raise HTTPException(422, "المعدة ليست في حالة تشغيل (صيانة/متوقفة)")
    if b.date > date.today(): raise HTTPException(422, "تاريخ مستقبلي")
    if db.execute(select(EquipmentUsage.id).where(EquipmentUsage.equipment_id == e.id, EquipmentUsage.project_id == b.project_id, EquipmentUsage.date == b.date)).first():
        raise HTTPException(409, "سُجّل تشغيل هذه المعدة لهذا المشروع في هذا اليوم")
    x = EquipmentUsage(rate=e.daily_rate, **b.model_dump()); db.add(x); db.flush()
    audit.log(db, u, "equipment.usage", "equipment", e.id, after={"project": b.project_id, "date": b.date, "days": b.days, "cost": q2(b.days * e.daily_rate)}, request=request)
    return {"id": x.id, "cost": q2(x.days * x.rate)}

@router.get("/reports/equipment-cost")
def equipment_cost(db=Depends(get_db), _=Depends(need("equipment.view"))):
    q = (select(EquipmentUsage.project_id, Equipment.name, func.sum(EquipmentUsage.days), func.sum(EquipmentUsage.days * EquipmentUsage.rate))
         .join(Equipment, Equipment.id == EquipmentUsage.equipment_id).group_by(EquipmentUsage.project_id, Equipment.name))
    out = [{"project_id": p, "equipment": n, "days": d, "cost": q2(c)} for p, n, d, c in db.execute(q).all()]
    return {"rows": out, "total": sum((r["cost"] for r in out), Z),
            "note": "تكلفة تشغيل داخلية للتحليل فقط؛ لا تُرحَّل إلى الأستاذ إلا بقرار محاسبي."}

# ---------------- العمالة اليومية ----------------
WK = ("id", "name", "trade", "daily_rate", "active", "version")

class WKIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    trade: str = ""
    daily_rate: Decimal = Field(ge=0)

@router.post("/workers", status_code=201)
def new_worker(b: WKIn, request: Request, db=Depends(get_db), u=Depends(need("labor.create"))):
    w = Worker(**b.model_dump()); db.add(w); db.flush()
    audit.log(db, u, "worker.create", "worker", w.id, after=row(w, *WK), request=request)
    return row(w, *WK)

@router.get("/workers")
def list_workers(db=Depends(get_db), _=Depends(need("labor.view"))):
    unpaid = dict(db.execute(select(LaborDay.worker_id, func.sum(LaborDay.days * LaborDay.rate)).where(LaborDay.paid == False).group_by(LaborDay.worker_id)).all())
    return [{**row(w, *WK), "unpaid": q2(unpaid.get(w.id, Z))} for w in db.execute(select(Worker).order_by(Worker.name)).scalars()]

class WKPatch(BaseModel):
    version: int
    daily_rate: Decimal | None = Field(default=None, ge=0)
    active: bool | None = None
    reason: str = Field(min_length=3)

@router.patch("/workers/{wid}")
def patch_worker(wid: str, b: WKPatch, request: Request, db=Depends(get_db), u=Depends(need("labor.create"))):
    w = db.get(Worker, wid)
    if not w: raise HTTPException(404, "العامل غير موجود")
    if w.version != b.version: raise HTTPException(409, "عُدّل السجل من مستخدم آخر، أعد التحميل")
    before = row(w, *WK)
    for k, v in b.model_dump(exclude_unset=True, exclude={"version", "reason"}).items(): setattr(w, k, v)
    w.version += 1; db.flush()      # تغيير الأجر لا يؤثر على أيام سُجّلت سابقًا (أجر اليوم مثبّت)
    audit.log(db, u, "worker.update", "worker", w.id, before=before, after=row(w, *WK), reason=b.reason, request=request)
    return row(w, *WK)

class LDIn(BaseModel):
    worker_id: str
    project_id: str
    date: date
    days: Decimal = Field(gt=0, le=2)

@router.post("/labor/days", status_code=201)
def record_day(b: LDIn, request: Request, db=Depends(get_db), u=Depends(need("labor.record"))):
    w = db.get(Worker, b.worker_id)
    if not w or not w.active: raise HTTPException(422, "العامل غير موجود أو موقوف")
    proj(db, b.project_id)
    if b.date > date.today(): raise HTTPException(422, "تاريخ مستقبلي")
    if db.execute(select(LaborDay.id).where(LaborDay.worker_id == w.id, LaborDay.date == b.date)).first():
        raise HTTPException(409, "سُجّل هذا العامل في هذا اليوم من قبل")       # يمنع احتساب اليوم مرتين على مشروعين
    d = LaborDay(rate=w.daily_rate, **b.model_dump()); db.add(d); db.flush()
    audit.log(db, u, "labor.record", "worker", w.id, after={"date": b.date, "days": b.days, "project": b.project_id, "amount": q2(d.days * d.rate)}, request=request)
    return {"id": d.id, "amount": q2(d.days * d.rate)}

@router.get("/labor/days")
def list_days(paid: bool | None = None, db=Depends(get_db), _=Depends(need("labor.view"))):
    q = select(LaborDay, Worker.name).join(Worker, Worker.id == LaborDay.worker_id).order_by(LaborDay.date.desc())
    if paid is not None: q = q.where(LaborDay.paid == paid)
    return [{"id": d.id, "worker": n, "project_id": d.project_id, "date": d.date, "days": d.days, "rate": d.rate, "amount": q2(d.days * d.rate), "paid": d.paid}
            for d, n in db.execute(q.limit(1000)).all()]

class LPay(BaseModel):
    date: date
    up_to: date
    method: str = "cash"
    worker_id: str | None = None

@router.post("/labor/pay", status_code=201)
def pay_labor(b: LPay, request: Request, db=Depends(get_db), u=Depends(need("labor.pay"))):
    if b.method not in ("cash", "bank"): raise HTTPException(422, "طريقة الدفع غير صحيحة")
    q = select(LaborDay).where(LaborDay.paid == False, LaborDay.date <= b.up_to).with_for_update()
    if b.worker_id: q = q.where(LaborDay.worker_id == b.worker_id)
    days = db.execute(q).scalars().all()
    if not days: raise HTTPException(422, "لا توجد أيام غير مسددة")
    by = {}
    for d in days: by.setdefault(d.project_id, []).append(d)
    cash = "1110" if b.method == "cash" else "1100"; entries = []; total = Z
    for pid, L in by.items():                       # قيد لكل مشروع لأن القيد الواحد يخص مشروعًا واحدًا
        amt = sum((q2(d.days * d.rate) for d in L), Z)
        e = post(db, u, b.date, f"أجور عمالة يومية حتى {b.up_to.isoformat()}", [{"account_code": "5200", "debit": amt, "credit": Z},
                 {"account_code": cash, "debit": Z, "credit": amt}], pid, source="labor")
        for d in L: d.paid, d.entry_id = True, e.id
        entries.append({"project_id": pid, "entry_no": e.no, "amount": amt}); total += amt
    db.flush()
    audit.log(db, u, "labor.pay", "labor", "batch", after={"days": len(days), "total": total, "entries": [x["entry_no"] for x in entries]}, request=request)
    return {"days_paid": len(days), "total": total, "entries": entries}

# ---------------- العهد ----------------
CAT = {"materials": "5100", "labor": "5200", "equipment": "5400", "admin": "5500", "other": "5900"}

def spent(db, cid): return db.execute(select(func.coalesce(func.sum(CustodyExpense.amount), 0)).where(CustodyExpense.custody_id == cid)).scalar() or Z
def cudto(db, c):
    s = spent(db, c.id)
    return {"id": c.id, "person": c.person, "project_id": c.project_id, "amount": c.amount, "date": c.date, "spent": s, "remaining": c.amount - s,
            "settled": c.settled, "age_days": (date.today() - c.date).days}

class CUIn(BaseModel):
    person: str = Field(min_length=1, max_length=200)
    project_id: str | None = None
    amount: Decimal = Field(gt=0)
    date: date
    method: str = "cash"

@router.post("/custodies", status_code=201)
def new_custody(b: CUIn, request: Request, db=Depends(get_db), u=Depends(need("custody.create"))):
    proj(db, b.project_id, required=False)
    if b.method not in ("cash", "bank"): raise HTTPException(422, "طريقة غير صحيحة")
    amt = q2(b.amount)
    e = post(db, u, b.date, f"صرف عهدة إلى {b.person}", [{"account_code": "1400", "debit": amt, "credit": Z},
             {"account_code": "1110" if b.method == "cash" else "1100", "debit": Z, "credit": amt}], b.project_id, source="custody")
    c = Custody(person=b.person, project_id=b.project_id, amount=amt, date=b.date, entry_id=e.id, created_by=u.id); db.add(c); db.flush()
    audit.log(db, u, "custody.create", "custody", c.id, after=cudto(db, c), request=request)
    return cudto(db, c)

@router.get("/custodies")
def list_custody(db=Depends(get_db), _=Depends(need("custody.view"))):
    return [cudto(db, c) for c in db.execute(select(Custody).order_by(Custody.date.desc())).scalars()]

class CEIn(BaseModel):
    date: date
    category: str
    description: str = Field(min_length=1, max_length=300)
    amount: Decimal = Field(gt=0)

@router.post("/custodies/{cid}/expenses", status_code=201)
def custody_expense(cid: str, b: CEIn, request: Request, db=Depends(get_db), u=Depends(need("custody.expense"))):
    c = db.get(Custody, cid, with_for_update=True)
    if not c: raise HTTPException(404, "العهدة غير موجودة")
    if c.settled: raise HTTPException(409, "العهدة مسوّاة")
    if b.category not in CAT: raise HTTPException(422, "بند المصروف: " + "/".join(CAT))
    amt = q2(b.amount)
    if spent(db, cid) + amt > c.amount: raise HTTPException(422, "المصروفات تتجاوز قيمة العهدة")
    if b.date < c.date: raise HTTPException(422, "تاريخ المصروف قبل صرف العهدة")
    e = post(db, u, b.date, f"مصروف عهدة {c.person}: {b.description}", [{"account_code": CAT[b.category], "debit": amt, "credit": Z},
             {"account_code": "1400", "debit": Z, "credit": amt}], c.project_id, source="custody")
    x = CustodyExpense(custody_id=cid, date=b.date, category=b.category, description=b.description, amount=amt, entry_id=e.id); db.add(x); db.flush()
    audit.log(db, u, "custody.expense", "custody", cid, after={"amount": amt, "category": b.category, "entry_no": e.no}, request=request)
    return cudto(db, c)

class CSet(BaseModel):
    date: date
    method: str = "cash"

@router.post("/custodies/{cid}/settle")
def settle(cid: str, b: CSet, request: Request, db=Depends(get_db), u=Depends(need("custody.settle"))):
    c = db.get(Custody, cid, with_for_update=True)
    if not c: raise HTTPException(404, "العهدة غير موجودة")
    if c.settled: raise HTTPException(409, "العهدة مسوّاة")
    rest = c.amount - spent(db, cid)
    if rest > 0:                                       # ما لم يُنفق يُردّ للخزينة/البنك
        e = post(db, u, b.date, f"رد باقي عهدة {c.person}", [{"account_code": "1110" if b.method == "cash" else "1100", "debit": rest, "credit": Z},
                 {"account_code": "1400", "debit": Z, "credit": rest}], c.project_id, source="custody")
        c.settle_entry_id = e.id
    c.settled = True; db.flush()
    audit.log(db, u, "custody.settle", "custody", c.id, after={"returned": rest}, request=request)
    return cudto(db, c)
