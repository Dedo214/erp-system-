from datetime import date, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import DailyReport, SafetyRecord, SiteDocument, Risk, Correspondence, Project, Attachment
from ..deps import need
from .. import audit

router = APIRouter(tags=["site"])

def proj(db, pid, required=True):
    if pid is None and not required: return None
    p = db.get(Project, pid)
    if not p or p.deleted: raise HTTPException(422, "المشروع غير موجود")
    return p

def row(o, *cols): return {c: getattr(o, c) for c in cols}

def conflict(o, version):
    if o.version != version: raise HTTPException(409, "عُدّل السجل من مستخدم آخر، أعد التحميل")

# ---------------- التقارير اليومية ----------------
DR = ("id", "project_id", "date", "weather", "workers_count", "work", "issues", "version")

class DRIn(BaseModel):
    project_id: str
    date: date
    weather: str = ""
    workers_count: int = Field(default=0, ge=0, le=100000)
    work: str = Field(min_length=3)
    issues: str = ""

@router.post("/daily-reports", status_code=201)
def new_dr(b: DRIn, request: Request, db=Depends(get_db), u=Depends(need("site.create"))):
    proj(db, b.project_id)
    if b.date > date.today(): raise HTTPException(422, "لا يُسجَّل تقرير بتاريخ مستقبلي")
    if db.execute(select(DailyReport.id).where(DailyReport.project_id == b.project_id, DailyReport.date == b.date)).first():
        raise HTTPException(409, "يوجد تقرير لهذا المشروع في هذا اليوم")
    r = DailyReport(created_by=u.id, **b.model_dump()); db.add(r); db.flush()
    audit.log(db, u, "daily_report.create", "daily_report", r.id, after=row(r, *DR), request=request)
    return row(r, *DR)

@router.get("/daily-reports")
def list_dr(project_id: str | None = None, db=Depends(get_db), _=Depends(need("site.view"))):
    q = select(DailyReport).order_by(DailyReport.date.desc())
    if project_id: q = q.where(DailyReport.project_id == project_id)
    return [row(r, *DR) for r in db.execute(q.limit(500)).scalars()]

class DRPatch(BaseModel):
    version: int
    weather: str | None = None
    workers_count: int | None = Field(default=None, ge=0, le=100000)
    work: str | None = Field(default=None, min_length=3)
    issues: str | None = None
    reason: str = Field(min_length=3)

@router.patch("/daily-reports/{rid}")
def patch_dr(rid: str, b: DRPatch, request: Request, db=Depends(get_db), u=Depends(need("site.update"))):
    r = db.get(DailyReport, rid)
    if not r: raise HTTPException(404, "التقرير غير موجود")
    conflict(r, b.version); before = row(r, *DR)
    for k, v in b.model_dump(exclude_unset=True, exclude={"version", "reason"}).items(): setattr(r, k, v)
    r.version += 1; db.flush()
    audit.log(db, u, "daily_report.update", "daily_report", r.id, before=before, after=row(r, *DR), reason=b.reason, request=request)
    return row(r, *DR)

# ---------------- السلامة ----------------
SF = ("id", "project_id", "date", "kind", "severity", "description", "action", "status", "version")

class SFIn(BaseModel):
    project_id: str
    date: date
    kind: str
    severity: str
    description: str = Field(min_length=3)
    action: str = ""

@router.post("/safety", status_code=201)
def new_sf(b: SFIn, request: Request, db=Depends(get_db), u=Depends(need("site.create"))):
    proj(db, b.project_id)
    if b.kind not in ("inspection", "accident", "near_miss"): raise HTTPException(422, "النوع: inspection/accident/near_miss")
    if b.severity not in ("low", "medium", "high"): raise HTTPException(422, "الخطورة: low/medium/high")
    if b.date > date.today(): raise HTTPException(422, "تاريخ مستقبلي")
    s = SafetyRecord(**b.model_dump()); db.add(s); db.flush()
    audit.log(db, u, "safety.create", "safety", s.id, after=row(s, *SF), request=request)
    return row(s, *SF)

@router.get("/safety")
def list_sf(project_id: str | None = None, db=Depends(get_db), _=Depends(need("site.view"))):
    q = select(SafetyRecord).order_by(SafetyRecord.date.desc())
    if project_id: q = q.where(SafetyRecord.project_id == project_id)
    return [row(s, *SF) for s in db.execute(q.limit(500)).scalars()]

class SFAct(BaseModel):
    version: int
    action: str = Field(min_length=3)      # الإجراء التصحيحي المتخذ

@router.post("/safety/{sid}/close")
def close_sf(sid: str, b: SFAct, request: Request, db=Depends(get_db), u=Depends(need("site.update"))):
    s = db.get(SafetyRecord, sid)
    if not s: raise HTTPException(404, "السجل غير موجود")
    conflict(s, b.version)
    if s.status == "closed": raise HTTPException(409, "السجل مغلق")
    before = row(s, *SF); s.status, s.action = "closed", b.action; s.version += 1; db.flush()
    audit.log(db, u, "safety.close", "safety", s.id, before=before, after=row(s, *SF), reason=b.action, request=request)
    return row(s, *SF)

# ---------------- المستندات ----------------
DC = ("id", "project_id", "doc_type", "name", "issue_date", "expiry_date", "attachment_id")
def ddto(d): return {**row(d, *DC), "days_to_expiry": (d.expiry_date - date.today()).days if d.expiry_date else None}

class DCIn(BaseModel):
    project_id: str | None = None
    doc_type: str = Field(min_length=1, max_length=60)
    name: str = Field(min_length=1, max_length=300)
    issue_date: date | None = None
    expiry_date: date | None = None
    attachment_id: str | None = None

@router.post("/documents", status_code=201)
def new_doc(b: DCIn, request: Request, db=Depends(get_db), u=Depends(need("docs.create"))):
    proj(db, b.project_id, required=False)
    if b.issue_date and b.expiry_date and b.expiry_date < b.issue_date: raise HTTPException(422, "تاريخ الانتهاء قبل الإصدار")
    if b.attachment_id and not db.get(Attachment, b.attachment_id): raise HTTPException(422, "المرفق غير موجود")
    d = SiteDocument(**b.model_dump()); db.add(d); db.flush()
    audit.log(db, u, "document.create", "document", d.id, after=ddto(d), request=request)
    return ddto(d)

@router.get("/documents")
def list_docs(project_id: str | None = None, db=Depends(get_db), _=Depends(need("docs.view"))):
    q = select(SiteDocument).where(SiteDocument.deleted == False).order_by(SiteDocument.expiry_date)
    if project_id: q = q.where(SiteDocument.project_id == project_id)
    return [ddto(d) for d in db.execute(q).scalars()]

@router.delete("/documents/{did}")
def del_doc(did: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("docs.delete"))):
    d = db.get(SiteDocument, did)
    if not d or d.deleted: raise HTTPException(404, "المستند غير موجود")
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الحذف إلزامي")
    before = ddto(d); d.deleted = True; db.flush()
    audit.log(db, u, "document.delete", "document", d.id, before=before, reason=reason, request=request)
    return {"ok": True}

# ---------------- المخاطر ----------------
RK = ("id", "project_id", "description", "prob", "impact", "owner", "mitigation", "status", "version")
def rdto(r): return {**row(r, *RK), "score": r.prob * r.impact, "level": "high" if r.prob * r.impact >= 15 else "medium" if r.prob * r.impact >= 8 else "low"}

class RKIn(BaseModel):
    project_id: str
    description: str = Field(min_length=3)
    prob: int = Field(ge=1, le=5)
    impact: int = Field(ge=1, le=5)
    owner: str = ""
    mitigation: str = ""

@router.post("/risks", status_code=201)
def new_risk(b: RKIn, request: Request, db=Depends(get_db), u=Depends(need("risks.create"))):
    proj(db, b.project_id)
    r = Risk(**b.model_dump()); db.add(r); db.flush()
    audit.log(db, u, "risk.create", "risk", r.id, after=rdto(r), request=request)
    return rdto(r)

@router.get("/risks")
def list_risks(project_id: str | None = None, db=Depends(get_db), _=Depends(need("risks.view"))):
    q = select(Risk)
    if project_id: q = q.where(Risk.project_id == project_id)
    return sorted((rdto(r) for r in db.execute(q).scalars()), key=lambda x: -x["score"])

class RKPatch(BaseModel):
    version: int
    prob: int | None = Field(default=None, ge=1, le=5)
    impact: int | None = Field(default=None, ge=1, le=5)
    mitigation: str | None = None
    owner: str | None = None
    status: str | None = None
    reason: str = Field(min_length=3)

@router.patch("/risks/{rid}")
def patch_risk(rid: str, b: RKPatch, request: Request, db=Depends(get_db), u=Depends(need("risks.update"))):
    r = db.get(Risk, rid)
    if not r: raise HTTPException(404, "الخطر غير موجود")
    conflict(r, b.version); ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if ch.get("status") not in (None, "open", "mitigated", "closed"): raise HTTPException(422, "حالة غير صحيحة")
    before = rdto(r)
    for k, v in ch.items(): setattr(r, k, v)
    r.version += 1; db.flush()
    audit.log(db, u, "risk.update", "risk", r.id, before=before, after=rdto(r), reason=b.reason, request=request)
    return rdto(r)

# ---------------- المراسلات ----------------
CR = ("id", "direction", "ref_no", "date", "party", "project_id", "subject", "due", "status", "closure_note", "version")
def cdto(c): return {**row(c, *CR), "overdue": c.status == "open" and bool(c.due) and c.due < date.today()}

class CRIn(BaseModel):
    direction: str
    ref_no: str = Field(min_length=1, max_length=60)
    date: date
    party: str = Field(min_length=1, max_length=200)
    project_id: str | None = None
    subject: str = Field(min_length=1, max_length=400)
    due: date | None = None

@router.post("/correspondence", status_code=201)
def new_corr(b: CRIn, request: Request, db=Depends(get_db), u=Depends(need("docs.create"))):
    if b.direction not in ("in", "out"): raise HTTPException(422, "الاتجاه: in/out")
    proj(db, b.project_id, required=False)
    if db.execute(select(Correspondence.id).where(Correspondence.direction == b.direction, Correspondence.ref_no == b.ref_no)).first():
        raise HTTPException(409, "رقم المراسلة مستخدم")
    c = Correspondence(**b.model_dump()); db.add(c); db.flush()
    audit.log(db, u, "correspondence.create", "correspondence", c.id, after=cdto(c), request=request)
    return cdto(c)

@router.get("/correspondence")
def list_corr(status: str | None = None, db=Depends(get_db), _=Depends(need("docs.view"))):
    q = select(Correspondence).order_by(Correspondence.date.desc())
    if status: q = q.where(Correspondence.status == status)
    return [cdto(c) for c in db.execute(q.limit(500)).scalars()]

class CRClose(BaseModel):
    version: int
    note: str = Field(min_length=3)

@router.post("/correspondence/{cid}/close")
def close_corr(cid: str, b: CRClose, request: Request, db=Depends(get_db), u=Depends(need("docs.update"))):
    c = db.get(Correspondence, cid)
    if not c: raise HTTPException(404, "المراسلة غير موجودة")
    conflict(c, b.version)
    if c.status == "closed": raise HTTPException(409, "المراسلة مغلقة")
    before = cdto(c); c.status, c.closure_note = "closed", b.note; c.version += 1; db.flush()
    audit.log(db, u, "correspondence.close", "correspondence", c.id, before=before, after=cdto(c), reason=b.note, request=request)
    return cdto(c)
