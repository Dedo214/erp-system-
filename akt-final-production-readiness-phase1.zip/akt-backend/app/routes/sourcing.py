from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from ..db import get_db
from ..models import Rating, Rfq, RfqQuote, StockCount, StockCountLine, Item, Party, Project
from ..deps import need
from .. import audit
from ..numbering import next_no
from .procurement import locked_item, apply_adjust

router = APIRouter(tags=["sourcing"])
Z = Decimal(0)

def party_of(db, pid, kinds):
    p = db.get(Party, pid)
    if not p or getattr(p, "deleted", False) or p.kind not in kinds: raise HTTPException(422, "الطرف غير موجود أو نوعه غير مناسب")
    return p

# ---------------- التقييمات ----------------
class RatingIn(BaseModel):
    party_id: str
    date: date
    quality: int = Field(ge=1, le=5)
    punctuality: int = Field(ge=1, le=5)
    price: int = Field(ge=1, le=5)
    note: str = Field(default="", max_length=500)

@router.post("/ratings", status_code=201)
def new_rating(b: RatingIn, request: Request, db=Depends(get_db), u=Depends(need("ratings.create"))):
    party_of(db, b.party_id, ("supplier", "subcontractor"))
    r = Rating(**b.model_dump(), created_by=u.id); db.add(r); db.flush()
    audit.log(db, u, "ratings.create", "party", b.party_id, after=b.model_dump(mode="json"), request=request)
    return {"id": r.id}

@router.get("/ratings")
def list_ratings(party_id: str | None = None, db=Depends(get_db), _=Depends(need("ratings.view"))):
    q = select(Rating).order_by(Rating.date.desc())
    if party_id: q = q.where(Rating.party_id == party_id)
    return [{"id": r.id, "party_id": r.party_id, "date": r.date, "quality": r.quality, "punctuality": r.punctuality, "price": r.price, "note": r.note} for r in db.execute(q.limit(1000)).scalars()]

@router.get("/reports/vendor-ratings")
def vendor_ratings(db=Depends(get_db), _=Depends(need("ratings.view"))):
    out = []
    for p in db.execute(select(Party).where(Party.kind.in_(("supplier", "subcontractor")))).scalars():
        if getattr(p, "deleted", False): continue
        n, q, t, pr = db.execute(select(func.count(), func.avg(Rating.quality), func.avg(Rating.punctuality), func.avg(Rating.price)).where(Rating.party_id == p.id)).one()
        f = lambda x: round(float(x), 2) if x is not None else None
        out.append({"party_id": p.id, "name": p.name, "kind": p.kind, "count": n, "quality": f(q), "punctuality": f(t), "price": f(pr),
                    "overall": f((float(q) + float(t) + float(pr)) / 3) if n else None})
    return sorted(out, key=lambda r: (r["overall"] is None, -(r["overall"] or 0), r["name"]))

# ---------------- طلبات الأسعار ----------------
class RfqIn(BaseModel):
    item: str = Field(min_length=1, max_length=300)
    unit: str = Field(default="", max_length=20)
    qty: Decimal = Field(gt=0)
    project_id: str | None = None

class QuoteIn(BaseModel):
    party_id: str
    price: Decimal = Field(gt=0)
    note: str = Field(default="", max_length=300)
    version: int

class AwardIn(BaseModel):
    party_id: str
    version: int
    reason: str = Field(default="", max_length=300)

def rfq_dto(db, r):
    qs = sorted(r.quotes, key=lambda x: x.price); names = {p.id: p.name for p in db.execute(select(Party).where(Party.id.in_([q.party_id for q in qs] + ([r.awarded_party_id] if r.awarded_party_id else [])))).scalars()}
    return {"id": r.id, "no": r.no, "item": r.item, "unit": r.unit, "qty": r.qty, "project_id": r.project_id, "status": r.status, "version": r.version,
            "awarded_party_id": r.awarded_party_id, "awarded_name": names.get(r.awarded_party_id, ""), "award_note": r.award_note,
            "quotes": [{"party_id": q.party_id, "name": names.get(q.party_id, ""), "price": q.price, "total": (q.price * r.qty).quantize(Decimal("0.01")), "note": q.note} for q in qs],
            "lowest": names.get(qs[0].party_id, "") if qs else "", "quotes_count": len(qs)}

def get_open(db, rid, version):
    r = db.get(Rfq, rid, with_for_update=True)
    if not r: raise HTTPException(404, "الطلب غير موجود")
    if r.version != version: raise HTTPException(409, "عُدّل الطلب من مستخدم آخر، أعد التحميل")
    if r.status != "open": raise HTTPException(409, "الطلب مغلق")
    return r

@router.post("/rfqs", status_code=201)
def new_rfq(b: RfqIn, request: Request, db=Depends(get_db), u=Depends(need("rfq.create"))):
    if b.project_id:
        p = db.get(Project, b.project_id)
        if not p or p.deleted: raise HTTPException(422, "المشروع غير موجود")
    r = Rfq(no=next_no(db, Rfq.no), created_by=u.id, **b.model_dump()); db.add(r); db.flush()
    audit.log(db, u, "rfq.create", "rfq", r.id, after=b.model_dump(mode="json"), request=request)
    return rfq_dto(db, r)

@router.get("/rfqs")
def list_rfqs(db=Depends(get_db), _=Depends(need("rfq.view"))):
    return [rfq_dto(db, r) for r in db.execute(select(Rfq).order_by(Rfq.no.desc()).limit(500)).scalars()]

@router.post("/rfqs/{rid}/quotes", status_code=201)
def add_quote(rid: str, b: QuoteIn, request: Request, db=Depends(get_db), u=Depends(need("rfq.update"))):
    r = get_open(db, rid, b.version); party_of(db, b.party_id, ("supplier",))
    ex = next((q for q in r.quotes if q.party_id == b.party_id), None)
    if ex: ex.price, ex.note = b.price, b.note                       # عرض جديد من نفس المورد يحل محل القديم
    else: r.quotes.append(RfqQuote(party_id=b.party_id, price=b.price, note=b.note))
    r.version += 1; db.flush()
    audit.log(db, u, "rfq.quote", "rfq", r.id, after={"party_id": b.party_id, "price": b.price}, request=request)
    return rfq_dto(db, r)

@router.post("/rfqs/{rid}/award")
def award(rid: str, b: AwardIn, request: Request, db=Depends(get_db), u=Depends(need("rfq.update"))):
    r = get_open(db, rid, b.version)
    q = next((x for x in r.quotes if x.party_id == b.party_id), None)
    if not q: raise HTTPException(422, "لا يوجد عرض من هذا المورد")
    if q.price > min(x.price for x in r.quotes) and len(b.reason.strip()) < 3:
        raise HTTPException(422, "الترسية على غير الأقل سعرًا تتطلب سببًا")
    r.status, r.awarded_party_id, r.award_note = "awarded", b.party_id, b.reason.strip(); r.version += 1; db.flush()
    audit.log(db, u, "rfq.award", "rfq", r.id, after={"party_id": b.party_id, "price": q.price}, reason=b.reason or None, request=request)
    return rfq_dto(db, r)

@router.post("/rfqs/{rid}/cancel")
def cancel_rfq(rid: str, version: int, reason: str, request: Request, db=Depends(get_db), u=Depends(need("rfq.update"))):
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الإلغاء مطلوب")
    r = get_open(db, rid, version); r.status = "cancelled"; r.award_note = reason.strip(); r.version += 1; db.flush()
    audit.log(db, u, "rfq.cancel", "rfq", r.id, reason=reason, request=request)
    return rfq_dto(db, r)

# ---------------- الجرد المخزني ----------------
class CountIn(BaseModel):
    date: date
    note: str = Field(default="", max_length=300)
    item_ids: list[str] | None = None

class CLine(BaseModel):
    item_id: str
    counted_qty: Decimal | None = Field(default=None, ge=0)
    unit_cost: Decimal | None = Field(default=None, ge=0)

class CountLines(BaseModel):
    version: int
    lines: list[CLine] = Field(min_length=1, max_length=5000)

def count_dto(db, c):
    items = {i.id: i for i in db.execute(select(Item).where(Item.id.in_([l.item_id for l in c.lines]))).scalars()}
    ls = []
    for l in sorted(c.lines, key=lambda x: items[x.item_id].code):
        it = items[l.item_id]; diff = (l.counted_qty - l.system_qty) if l.counted_qty is not None else None
        avg = (it.value / it.qty) if it.qty else (l.unit_cost or Z)
        ls.append({"item_id": l.item_id, "code": it.code, "name": it.name, "unit": it.unit, "system_qty": l.system_qty, "counted_qty": l.counted_qty,
                   "diff": diff, "est_value": (diff * avg).quantize(Decimal("0.01")) if diff is not None else None, "unit_cost": l.unit_cost})
    return {"id": c.id, "no": c.no, "date": c.date, "note": c.note, "status": c.status, "version": c.version, "created_by": c.created_by, "approved_by": c.approved_by,
            "lines": ls, "counted": sum(1 for l in ls if l["counted_qty"] is not None), "total": len(ls), "variances": sum(1 for l in ls if l["diff"]),
            "net_value": sum((l["est_value"] or Z for l in ls), Z)}

def get_count(db, cid, version=None, draft=True):
    c = db.get(StockCount, cid, with_for_update=True)
    if not c: raise HTTPException(404, "الجرد غير موجود")
    if version is not None and c.version != version: raise HTTPException(409, "عُدّل الجرد من مستخدم آخر، أعد التحميل")
    if draft and c.status != "draft": raise HTTPException(409, "الجرد مغلق")
    return c

@router.post("/stock-counts", status_code=201)
def new_count(b: CountIn, request: Request, db=Depends(get_db), u=Depends(need("stockcount.create"))):
    q = select(Item).where(Item.active == True)
    if b.item_ids: q = q.where(Item.id.in_(b.item_ids))
    items = list(db.execute(q.order_by(Item.code)).scalars())
    if not items: raise HTTPException(422, "لا أصناف للجرد")
    c = StockCount(no=next_no(db, StockCount.no), date=b.date, note=b.note, created_by=u.id)
    c.lines = [StockCountLine(item_id=i.id, system_qty=i.qty) for i in items]; db.add(c); db.flush()
    audit.log(db, u, "stockcount.create", "stock_count", c.id, after={"items": len(items), "no": c.no}, request=request)
    return count_dto(db, c)

@router.get("/stock-counts")
def list_counts(db=Depends(get_db), _=Depends(need("stockcount.view"))):
    return [{k: v for k, v in count_dto(db, c).items() if k != "lines"} for c in db.execute(select(StockCount).order_by(StockCount.no.desc()).limit(200)).scalars()]

@router.get("/stock-counts/{cid}")
def get_one(cid: str, db=Depends(get_db), _=Depends(need("stockcount.view"))):
    return count_dto(db, get_count(db, cid, draft=False))

@router.put("/stock-counts/{cid}/lines")
def set_lines(cid: str, b: CountLines, request: Request, db=Depends(get_db), u=Depends(need("stockcount.create"))):
    c = get_count(db, cid, b.version); by = {l.item_id: l for l in c.lines}
    for x in b.lines:
        l = by.get(x.item_id)
        if not l: raise HTTPException(422, "صنف ليس ضمن هذا الجرد")
        l.counted_qty, l.unit_cost = x.counted_qty, x.unit_cost
    c.version += 1; db.flush()
    audit.log(db, u, "stockcount.lines", "stock_count", c.id, after={"lines": len(b.lines)}, request=request)
    return count_dto(db, c)

class Approve(BaseModel):
    version: int
    reason: str = Field(min_length=3, max_length=300)

@router.post("/stock-counts/{cid}/approve")
def approve_count(cid: str, b: Approve, request: Request, db=Depends(get_db), u=Depends(need("stockcount.approve"))):
    c = get_count(db, cid, b.version)
    if c.created_by == u.id: raise HTTPException(403, "لا يعتمد الجرد من أجراه (فصل المهام)")
    counted = [l for l in c.lines if l.counted_qty is not None]
    if not counted: raise HTTPException(422, "لم يُدخل أي عدّ")
    items = {l.item_id: locked_item(db, l.item_id) for l in counted}                    # قفل بترتيب ثابت لتفادي التشابك
    moved = sorted(items[l.item_id].code for l in counted if items[l.item_id].qty != l.system_qty)
    if moved: raise HTTPException(409, "تغيّر رصيد هذه الأصناف بعد بدء الجرد، أعد عدّها: " + "، ".join(moved))
    total, n = Z, 0
    for l in sorted(counted, key=lambda l: items[l.item_id].code):
        if l.counted_qty == l.system_qty: continue
        _, amt = apply_adjust(db, u, items[l.item_id], l.counted_qty, c.date, l.unit_cost, f"جرد رقم {c.no}: {b.reason}", request, ref=f"COUNT-{c.no}")
        total += amt; n += 1
    c.status, c.approved_by = "approved", u.id; c.version += 1; db.flush()
    audit.log(db, u, "stockcount.approve", "stock_count", c.id, after={"adjusted": n, "net_value": total}, reason=b.reason, request=request)
    return {**count_dto(db, c), "adjusted_items": n, "net_adjustment": total}

@router.post("/stock-counts/{cid}/cancel")
def cancel_count(cid: str, version: int, reason: str, request: Request, db=Depends(get_db), u=Depends(need("stockcount.create"))):
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الإلغاء مطلوب")
    c = get_count(db, cid, version); c.status = "cancelled"; c.note = (c.note + " | ملغى: " + reason.strip())[:300]; c.version += 1; db.flush()
    audit.log(db, u, "stockcount.cancel", "stock_count", c.id, reason=reason, request=request)
    return count_dto(db, c)
