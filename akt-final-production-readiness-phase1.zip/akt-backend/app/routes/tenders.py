import re
from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import Tender, Party, Project, Contract
from ..deps import need
from .. import audit

router = APIRouter(tags=["tenders"])
Z = Decimal(0)
PROB = {"study": 10, "submitted": 30, "negotiation": 60, "won": 100, "lost": 0}
STAGES = list(PROB)

def margin(t): return ((t.value - t.cost) / t.value * 100).quantize(Decimal("0.1")) if t.value else None

def tdto(t, today=None):
    today = today or date.today()
    return {"id": t.id, "name": t.name, "client_id": t.client_id, "type": t.type, "due": t.due, "value": t.value, "cost": t.cost,
            "margin_pct": margin(t), "stage": t.stage, "note": t.note, "project_id": t.project_id,
            "days_to_due": (t.due - today).days if t.due else None,
            "due_missed": bool(t.stage == "study" and t.due and t.due < today), "version": t.version}

class TIn(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    client_id: str | None = None
    type: str = ""
    due: date | None = None
    value: Decimal = Field(default=Z, ge=0)
    cost: Decimal = Field(default=Z, ge=0)
    note: str = ""

def client_ok(db, cid):
    if cid:
        p = db.get(Party, cid)
        if not p or p.kind != "client": raise HTTPException(422, "العميل غير صحيح")

@router.post("/tenders", status_code=201)
def new_tender(b: TIn, request: Request, db=Depends(get_db), u=Depends(need("tenders.create"))):
    client_ok(db, b.client_id)
    t = Tender(**b.model_dump()); db.add(t); db.flush(); db.refresh(t)
    audit.log(db, u, "tender.create", "tender", t.id, after=tdto(t), request=request)
    return tdto(t)

@router.get("/tenders")
def list_tenders(db=Depends(get_db), _=Depends(need("tenders.view"))):
    return [tdto(t) for t in db.execute(select(Tender).where(Tender.deleted == False).order_by(Tender.due)).scalars()]

class TPatch(BaseModel):
    version: int
    name: str | None = Field(default=None, min_length=1)
    client_id: str | None = None
    type: str | None = None
    due: date | None = None
    value: Decimal | None = Field(default=None, ge=0)
    cost: Decimal | None = Field(default=None, ge=0)
    stage: str | None = None
    note: str | None = None
    reason: str = ""

@router.patch("/tenders/{tid}")
def patch_tender(tid: str, b: TPatch, request: Request, db=Depends(get_db), u=Depends(need("tenders.update"))):
    t = db.get(Tender, tid)
    if not t or t.deleted: raise HTTPException(404, "العطاء غير موجود")
    if t.version != b.version: raise HTTPException(409, "عُدّل العطاء من مستخدم آخر، أعد التحميل")
    if t.project_id: raise HTTPException(409, "العطاء تحوّل إلى مشروع ولا يُعدَّل")
    ch = b.model_dump(exclude_unset=True, exclude={"version", "reason"})
    if "client_id" in ch: client_ok(db, ch["client_id"])
    if "stage" in ch:
        if ch["stage"] not in STAGES: raise HTTPException(422, "مرحلة غير معروفة")
        if ch["stage"] == "lost" and not (b.reason.strip() or ch.get("note")): raise HTTPException(422, "سبب الخسارة إلزامي")
    if {"value", "cost"} & set(ch) and t.stage in ("submitted", "negotiation", "won") and not b.reason.strip():
        raise HTTPException(422, "تغيير السعر/التكلفة بعد التقديم يتطلب سببًا")
    before = tdto(t)
    for k, v in ch.items(): setattr(t, k, v)
    if t.stage == "won" and t.value <= 0: raise HTTPException(422, "لا يُعتمد عطاء فائز بسعر صفر")
    t.version += 1; db.flush(); db.refresh(t)
    audit.log(db, u, "tender.update", "tender", t.id, before=before, after=tdto(t), reason=b.reason, request=request)
    return tdto(t)

class Conv(BaseModel):
    project_code: str = Field(min_length=1, max_length=40)
    contract_code: str = Field(min_length=1, max_length=40)

@router.post("/tenders/{tid}/convert", status_code=201)
def convert(tid: str, b: Conv, request: Request, db=Depends(get_db), u=Depends(need("tenders.convert"))):
    """عطاء فائز ← مشروع + عقد عميل (مسودة) في معاملة واحدة؛ يكتمل العقد ويُفعَّل من دورة العقود."""
    t = db.get(Tender, tid, with_for_update=True)
    if not t or t.deleted: raise HTTPException(404, "العطاء غير موجود")
    if t.stage != "won": raise HTTPException(422, "التحويل للعطاءات الفائزة فقط")
    if t.project_id: raise HTTPException(409, "العطاء تحوّل من قبل")
    if not t.client_id: raise HTTPException(422, "حدد العميل قبل التحويل")
    if db.execute(select(Project.id).where(Project.code == b.project_code)).first(): raise HTTPException(409, "كود المشروع مستخدم")
    if db.execute(select(Contract.id).where(Contract.code == b.contract_code)).first(): raise HTTPException(409, "كود العقد مستخدم")
    p = Project(code=b.project_code, name=t.name, client_id=t.client_id, contract_value=t.value, budget=t.cost, status="active")
    db.add(p); db.flush()
    c = Contract(code=b.contract_code, kind="client", project_id=p.id, party_id=t.client_id, title=t.name, original_value=t.value,
                 status="draft", created_by=u.id)
    db.add(c); t.project_id = p.id; t.version += 1; db.flush()
    audit.log(db, u, "tender.convert", "tender", t.id, after={"project": p.code, "contract": c.code, "value": t.value}, request=request)
    return {"project_id": p.id, "contract_id": c.id, "tender": tdto(t)}

@router.delete("/tenders/{tid}")
def del_tender(tid: str, reason: str, request: Request, db=Depends(get_db), u=Depends(need("tenders.delete"))):
    t = db.get(Tender, tid)
    if not t or t.deleted: raise HTTPException(404, "العطاء غير موجود")
    if t.project_id: raise HTTPException(409, "لا يُحذف عطاء تحوّل إلى مشروع")
    if len(reason.strip()) < 3: raise HTTPException(422, "سبب الحذف إلزامي")
    before = tdto(t); t.deleted = True; db.flush()
    audit.log(db, u, "tender.delete", "tender", t.id, before=before, reason=reason, request=request)
    return {"ok": True}

@router.get("/tenders/pipeline/summary")
def pipeline(db=Depends(get_db), _=Depends(need("tenders.view"))):
    ts = db.execute(select(Tender).where(Tender.deleted == False)).scalars().all(); out = []
    for s in STAGES:
        L = [t for t in ts if t.stage == s]; v = sum((t.value for t in L), Z)
        out.append({"stage": s, "count": len(L), "value": v, "probability_pct": PROB[s], "weighted": v * PROB[s] / 100})
    closed = [t for t in ts if t.stage in ("won", "lost")]
    won = [t for t in closed if t.stage == "won"]
    return {"stages": out, "weighted_total": sum((r["weighted"] for r in out if r["stage"] not in ("won", "lost")), Z),
            "win_rate_pct": (Decimal(len(won)) / len(closed) * 100).quantize(Decimal("0.1")) if closed else None}
