from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from ..db import get_db
from ..models import User, Role
from ..security import hash_password
from ..deps import need
from .. import audit

router = APIRouter(prefix="/users", tags=["users"])

class NewUser(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    full_name: str = ""
    email: str = ""
    password: str
    roles: list[str] = []

class Patch(BaseModel):
    full_name: str | None = None
    email: str | None = None
    is_active: bool | None = None
    roles: list[str] | None = None
    new_password: str | None = None
    reason: str = ""

def dto(u): return {"id": u.id, "username": u.username, "full_name": u.full_name, "email": u.email,
                    "is_active": u.is_active, "roles": sorted(r.name for r in u.roles)}

def _roles(db, names):
    rs = db.execute(select(Role).where(Role.name.in_(names))).scalars().all()
    if len(rs) != len(set(names)):
        raise HTTPException(422, "دور غير موجود")
    return rs

@router.get("")
def list_users(db=Depends(get_db), _=Depends(need("users.view"))):
    return [dto(u) for u in db.execute(select(User).order_by(User.username)).scalars()]

@router.post("", status_code=201)
def create(b: NewUser, request: Request, db=Depends(get_db), me=Depends(need("users.manage"))):
    name = b.username.strip().lower()
    if db.execute(select(User).where(User.username == name)).scalar_one_or_none():
        raise HTTPException(409, "اسم المستخدم موجود")
    try:
        h = hash_password(b.password)
    except ValueError as e:
        raise HTTPException(422, str(e))
    u = User(username=name, full_name=b.full_name, email=b.email, password_hash=h, roles=_roles(db, b.roles))
    db.add(u); db.flush()
    audit.log(db, me, "users.create", "user", u.id, after=dto(u), request=request)
    return dto(u)

@router.patch("/{uid}")
def patch(uid: str, b: Patch, request: Request, db=Depends(get_db), me=Depends(need("users.manage"))):
    u = db.get(User, uid)
    if not u: raise HTTPException(404, "غير موجود")
    before = dto(u)
    if b.full_name is not None: u.full_name = b.full_name
    if b.email is not None: u.email = b.email
    if b.is_active is not None:
        if u.id == me.id and not b.is_active:
            raise HTTPException(400, "لا يمكنك إيقاف حسابك")
        u.is_active = b.is_active; u.token_version += 1
    if b.roles is not None:
        u.roles = _roles(db, b.roles); u.token_version += 1
    if b.new_password:
        try: u.password_hash = hash_password(b.new_password)
        except ValueError as e: raise HTTPException(422, str(e))
        u.token_version += 1
    audit.log(db, me, "users.update", "user", u.id, before=before, after=dto(u), reason=b.reason, request=request)
    return dto(u)
