import hashlib, hmac, base64, json, time
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from .config import settings

_ph = PasswordHasher()

def hash_password(pw: str) -> str:
    if len(pw) < 10:
        raise ValueError("كلمة المرور أقصر من 10 أحرف")
    if pw.isdigit() or pw.isalpha() or pw.lower() in {"password123", "1234567890", "qwertyuiop", "admin12345", "aktgroup123"}:
        raise ValueError("كلمة المرور ضعيفة: اجمع بين حروف وأرقام أو رموز")
    return _ph.hash(pw)

def verify_password(h: str, pw: str) -> bool:
    try:
        return _ph.verify(h, pw)
    except (VerifyMismatchError, InvalidHashError):
        return False

# رمز جلسة موقّع HMAC-SHA256 (بدون اعتماد خارجي)، يحمل نسخة الرمز لإبطاله فوراً عند الحاجة.
def _b(x: bytes) -> str: return base64.urlsafe_b64encode(x).rstrip(b"=").decode()
def _ub(s: str) -> bytes: return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def make_token(uid: str, ver: int) -> str:
    body = _b(json.dumps({"u": uid, "v": ver, "exp": int(time.time()) + settings.token_minutes * 60}).encode())
    sig = _b(hmac.new(settings.secret_key.encode(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"

def read_token(tok: str):
    try:
        body, sig = tok.split(".")
        good = _b(hmac.new(settings.secret_key.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, good):
            return None
        d = json.loads(_ub(body))
        return d if d["exp"] > time.time() else None
    except Exception:
        return None
