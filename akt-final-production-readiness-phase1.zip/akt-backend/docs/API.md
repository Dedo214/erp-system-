# مرجع الـ API (مولّد تلقائيًا)

| الطريقة | المسار | الوصف |
|---|---|---|
| POST | `/admin/backup` | Backup |
| POST | `/admin/restore` | Do Restore |
| POST | `/advances/{aid}/reverse` | Reverse Advance |
| POST | `/attendance/import` | Import Json |
| POST | `/attendance/import-file` | Import File |
| GET | `/attendance/summary` | Summary |
| GET | `/audit` | Audit List |
| GET | `/audit/verify` | Audit Verify |
| POST | `/auth/change-password` | Change Pw |
| POST | `/auth/login` | Login |
| GET | `/auth/me` | Me |
| PATCH | `/boq/{bid}` | Patch Boq |
| DELETE | `/boq/{bid}` | Del Boq |
| POST | `/change-orders/{oid}/advance` | Advance |
| POST | `/change-orders/{oid}/reject` | Reject |
| POST | `/contracts` | Create Contract |
| GET | `/contracts` | List Contracts |
| GET | `/contracts/{cid}` | Get Contract |
| PATCH | `/contracts/{cid}` | Patch Contract |
| POST | `/contracts/{cid}/activate` | Activate |
| POST | `/contracts/{cid}/advances` | New Advance |
| GET | `/contracts/{cid}/advances` | List Advances |
| POST | `/contracts/{cid}/change-orders` | New Co |
| GET | `/contracts/{cid}/change-orders` | List Co |
| POST | `/contracts/{cid}/invoices` | New Invoice |
| GET | `/contracts/{cid}/invoices` | List Inv |
| POST | `/correspondence` | New Corr |
| GET | `/correspondence` | List Corr |
| POST | `/correspondence/{cid}/close` | Close Corr |
| GET | `/custodies` | List Custody |
| POST | `/custodies` | New Custody |
| POST | `/custodies/{cid}/expenses` | Custody Expense |
| POST | `/custodies/{cid}/settle` | Settle |
| POST | `/daily-reports` | New Dr |
| GET | `/daily-reports` | List Dr |
| PATCH | `/daily-reports/{rid}` | Patch Dr |
| POST | `/documents` | New Doc |
| GET | `/documents` | List Docs |
| DELETE | `/documents/{did}` | Del Doc |
| GET | `/employees` | List Emp |
| POST | `/employees` | New Emp |
| PATCH | `/employees/{eid}` | Patch Emp |
| POST | `/employees/{eid}/loans` | New Loan |
| GET | `/equipment` | List Eq |
| POST | `/equipment` | New Eq |
| POST | `/equipment/usage` | Usage |
| PATCH | `/equipment/{eid}` | Patch Eq |
| POST | `/equipment/{eid}/maintenance` | Maintenance |
| GET | `/executive/aging` | Aging Report |
| GET | `/executive/dashboard` | Dashboard |
| GET | `/executive/export/projects.csv` | Export Projects |
| POST | `/export/{fmt}` | Export |
| POST | `/files` | Upload |
| GET | `/files` | List Files |
| DELETE | `/files/{fid}` | Delete File |
| GET | `/files/{fid}/download` | Download |
| POST | `/guarantees` | New G |
| GET | `/guarantees` | List G |
| POST | `/guarantees/{gid}/act` | Act G |
| GET | `/handovers` | List Ho |
| POST | `/handovers` | New Ho |
| POST | `/handovers/{hid}/check` | Check |
| POST | `/handovers/{hid}/complete` | Complete |
| GET | `/health` | Health |
| POST | `/inspections` | New Insp |
| GET | `/inspections` | List Insp |
| POST | `/inspections/{iid}/decide` | Decide |
| POST | `/invoices/{iid}/approve` | Approve |
| POST | `/invoices/{iid}/payments` | Pay |
| POST | `/invoices/{iid}/reject` | Reject |
| POST | `/invoices/{iid}/review` | Review |
| GET | `/items` | Items |
| POST | `/items` | New Item |
| POST | `/labor/days` | Record Day |
| GET | `/labor/days` | List Days |
| POST | `/labor/pay` | Pay Labor |
| GET | `/ledger/accounts` | Accounts |
| POST | `/ledger/entries` | New Entry |
| GET | `/ledger/entries` | Entries |
| POST | `/ledger/entries/{eid}/reverse` | Reverse |
| PUT | `/ledger/period-lock` | Set Lock |
| GET | `/ledger/trial-balance` | Tb |
| POST | `/legacy/import` | Legacy |
| GET | `/parties` | Parties |
| POST | `/parties` | New Party |
| GET | `/payroll/runs` | List Runs |
| POST | `/payroll/runs` | New Run |
| GET | `/payroll/runs/{rid}` | Get Run |
| POST | `/payroll/runs/{rid}/approve` | Approve |
| PATCH | `/payroll/runs/{rid}/lines/{lid}` | Patch Line |
| POST | `/payroll/runs/{rid}/pay` | Pay |
| GET | `/payroll/settings` | Get Settings |
| PUT | `/payroll/settings` | Put Settings |
| GET | `/projects` | Projects |
| POST | `/projects` | New Project |
| PATCH | `/projects/{pid}` | Edit Project |
| DELETE | `/projects/{pid}` | Del Project |
| GET | `/projects/{pid}/boq` | Get Boq |
| POST | `/projects/{pid}/boq` | Add Boq |
| POST | `/projects/{pid}/boq/import` | Import Boq |
| GET | `/projects/{pid}/budget` | Get Budget |
| PUT | `/projects/{pid}/budget` | Set Budget |
| GET | `/projects/{pid}/tasks` | Get Tasks |
| POST | `/projects/{pid}/tasks` | Add Task |
| GET | `/purchase-orders` | List Po |
| POST | `/purchase-orders` | New Po |
| POST | `/purchase-orders/{oid}/approve` | Approve Po |
| POST | `/purchase-orders/{oid}/cancel` | Cancel Po |
| POST | `/purchase-orders/{oid}/invoices` | New Sinv |
| GET | `/purchase-orders/{oid}/invoices` | List Sinv |
| POST | `/purchase-orders/{oid}/receive` | Receive |
| GET | `/purchase-requests` | List Pr |
| POST | `/purchase-requests` | New Pr |
| POST | `/purchase-requests/{rid}/decide` | Decide Pr |
| POST | `/ratings` | New Rating |
| GET | `/ratings` | List Ratings |
| GET | `/reports/alerts` | Alerts |
| GET | `/reports/balance-sheet` | Balance Sheet |
| GET | `/reports/budget-vs-actual` | Overview |
| GET | `/reports/cashflow` | Cashflow |
| GET | `/reports/equipment-cost` | Equipment Cost |
| GET | `/reports/general-ledger/{code}` | Gl |
| GET | `/reports/income-statement` | Income |
| GET | `/reports/project/{pid}` | Project Dash |
| GET | `/reports/stock` | Stock Report |
| GET | `/reports/vendor-ratings` | Vendor Ratings |
| GET | `/rfqs` | List Rfqs |
| POST | `/rfqs` | New Rfq |
| POST | `/rfqs/{rid}/award` | Award |
| POST | `/rfqs/{rid}/cancel` | Cancel Rfq |
| POST | `/rfqs/{rid}/quotes` | Add Quote |
| POST | `/risks` | New Risk |
| GET | `/risks` | List Risks |
| PATCH | `/risks/{rid}` | Patch Risk |
| POST | `/safety` | New Sf |
| GET | `/safety` | List Sf |
| POST | `/safety/{sid}/close` | Close Sf |
| POST | `/snags` | New Snag |
| GET | `/snags` | List Snags |
| POST | `/snags/{sid}/act` | Snag Act |
| GET | `/stock-counts` | List Counts |
| POST | `/stock-counts` | New Count |
| GET | `/stock-counts/{cid}` | Get One |
| POST | `/stock-counts/{cid}/approve` | Approve Count |
| POST | `/stock-counts/{cid}/cancel` | Cancel Count |
| PUT | `/stock-counts/{cid}/lines` | Set Lines |
| POST | `/stock/adjust` | Adjust |
| POST | `/stock/issue` | Issue |
| POST | `/supplier-invoices/{iid}/pay` | Pay Sinv |
| PATCH | `/tasks/{tid}` | Patch Task |
| DELETE | `/tasks/{tid}` | Del Task |
| GET | `/tenders` | List Tenders |
| POST | `/tenders` | New Tender |
| GET | `/tenders/pipeline/summary` | Pipeline |
| PATCH | `/tenders/{tid}` | Patch Tender |
| DELETE | `/tenders/{tid}` | Del Tender |
| POST | `/tenders/{tid}/convert` | Convert |
| GET | `/users` | List Users |
| POST | `/users` | Create |
| PATCH | `/users/{uid}` | Patch |
| GET | `/workers` | List Workers |
| POST | `/workers` | New Worker |
| PATCH | `/workers/{wid}` | Patch Worker |
