# مرجع قاعدة البيانات (مولّد تلقائيًا)

## accounts

| العمود | النوع | قيود |
|---|---|---|
| code | VARCHAR(20) | PK NOT NULL |
| name | VARCHAR(200) | NOT NULL |
| type | VARCHAR(12) | NOT NULL |
| active | BOOLEAN | NOT NULL |

## attachments

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| entity | VARCHAR(60) | NOT NULL |
| entity_id | VARCHAR(64) | NOT NULL |
| filename | VARCHAR(250) | NOT NULL |
| mime | VARCHAR(100) | NOT NULL |
| size | INTEGER | NOT NULL |
| sha256 | VARCHAR(64) | NOT NULL |
| path | VARCHAR(400) | NOT NULL |
| uploaded_by | VARCHAR(32) | NOT NULL |
| uploaded_at | DATETIME | NOT NULL |

## attendance_imports

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| source | VARCHAR(60) | NOT NULL |
| sha256 | VARCHAR(64) | NOT NULL UNIQUE |
| rows_total | INTEGER | NOT NULL |
| rows_new | INTEGER | NOT NULL |
| rows_updated | INTEGER | NOT NULL |
| rows_rejected | INTEGER | NOT NULL |
| rejected | JSON | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| created_at | DATETIME | NOT NULL |

## audit_log

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| ts | DATETIME | NOT NULL |
| user_id | VARCHAR(32) | NOT NULL |
| username | VARCHAR(80) | NOT NULL |
| action | VARCHAR(80) | NOT NULL |
| entity | VARCHAR(60) | NOT NULL |
| entity_id | VARCHAR(64) | NOT NULL |
| before | JSON |  |
| after | JSON |  |
| reason | TEXT | NOT NULL |
| ip | VARCHAR(64) | NOT NULL |
| user_agent | VARCHAR(300) | NOT NULL |
| prev_hash | VARCHAR(64) | NOT NULL |
| hash | VARCHAR(64) | NOT NULL |

## equipment

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| name | VARCHAR(200) | NOT NULL UNIQUE |
| type | VARCHAR(60) | NOT NULL |
| daily_rate | NUMERIC(18, 2) | NOT NULL |
| status | VARCHAR(12) | NOT NULL |
| maint_interval_days | INTEGER | NOT NULL |
| last_maint | DATE |  |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## items

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| code | VARCHAR(40) | NOT NULL UNIQUE |
| name | VARCHAR(200) | NOT NULL |
| unit | VARCHAR(20) | NOT NULL |
| min_stock | NUMERIC(18, 3) | NOT NULL |
| qty | NUMERIC(18, 3) | NOT NULL |
| value | NUMERIC(18, 2) | NOT NULL |
| active | BOOLEAN | NOT NULL |
| version | INTEGER | NOT NULL |

## legacy_snapshots

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| ts | DATETIME | NOT NULL |
| sha256 | VARCHAR(64) | NOT NULL UNIQUE |
| data | JSON | NOT NULL |
| imported_by | VARCHAR(32) | NOT NULL |
| summary | JSON | NOT NULL |

## login_attempts

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| ts | DATETIME | NOT NULL |
| username | VARCHAR(80) | NOT NULL |
| ok | BOOLEAN | NOT NULL |
| ip | VARCHAR(64) | NOT NULL |

## parties

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| kind | VARCHAR(20) | NOT NULL |
| name | VARCHAR(200) | NOT NULL |
| contact | VARCHAR(200) | NOT NULL |
| phone | VARCHAR(60) | NOT NULL |
| email | VARCHAR(200) | NOT NULL |
| tax_no | VARCHAR(60) | NOT NULL |
| terms_days | INTEGER | NOT NULL |
| credit_limit | NUMERIC(18, 2) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |
| deleted | BOOLEAN | NOT NULL |

## payroll_settings

| العمود | النوع | قيود |
|---|---|---|
| key | VARCHAR(40) | PK NOT NULL |
| value | JSON | NOT NULL |

## period_lock

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| lock_date | DATE |  |

## permissions

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| code | VARCHAR(80) | NOT NULL UNIQUE |
| label | VARCHAR(200) | NOT NULL |

## roles

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| name | VARCHAR(80) | NOT NULL UNIQUE |

## stock_counts

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| date | DATE | NOT NULL |
| note | VARCHAR(300) | NOT NULL |
| status | VARCHAR(12) | NOT NULL |
| version | INTEGER | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| approved_by | VARCHAR(32) |  |

## users

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| username | VARCHAR(80) | NOT NULL UNIQUE |
| full_name | VARCHAR(200) | NOT NULL |
| email | VARCHAR(200) | NOT NULL |
| password_hash | VARCHAR(255) | NOT NULL |
| is_active | BOOLEAN | NOT NULL |
| failed_attempts | INTEGER | NOT NULL |
| locked_until | DATETIME |  |
| token_version | INTEGER | NOT NULL |
| created_at | DATETIME | NOT NULL |

## workers

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| name | VARCHAR(200) | NOT NULL |
| trade | VARCHAR(80) | NOT NULL |
| daily_rate | NUMERIC(18, 2) | NOT NULL |
| active | BOOLEAN | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## projects

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| code | VARCHAR(40) | NOT NULL UNIQUE |
| name | VARCHAR(250) | NOT NULL |
| client_id | VARCHAR(32) | FK→parties.id |
| location | VARCHAR(250) | NOT NULL |
| start_date | DATE |  |
| end_date | DATE |  |
| contract_value | NUMERIC(18, 2) | NOT NULL |
| budget | NUMERIC(18, 2) | NOT NULL |
| progress | NUMERIC(5, 2) | NOT NULL |
| status | VARCHAR(20) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |
| deleted | BOOLEAN | NOT NULL |

## ratings

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| party_id | VARCHAR(32) | NOT NULL FK→parties.id |
| date | DATE | NOT NULL |
| quality | INTEGER | NOT NULL |
| punctuality | INTEGER | NOT NULL |
| price | INTEGER | NOT NULL |
| note | VARCHAR(500) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| legacy_id | VARCHAR(64) |  |

## role_permissions

| العمود | النوع | قيود |
|---|---|---|
| role_id | INTEGER | PK NOT NULL FK→roles.id |
| perm_id | INTEGER | PK NOT NULL FK→permissions.id |

## stock_count_lines

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| count_id | VARCHAR(32) | NOT NULL FK→stock_counts.id |
| item_id | VARCHAR(32) | NOT NULL FK→items.id |
| system_qty | NUMERIC(18, 3) | NOT NULL |
| counted_qty | NUMERIC(18, 3) |  |
| unit_cost | NUMERIC(18, 2) |  |

## user_roles

| العمود | النوع | قيود |
|---|---|---|
| user_id | VARCHAR(32) | PK NOT NULL FK→users.id |
| role_id | INTEGER | PK NOT NULL FK→roles.id |

## boq_items

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| section | VARCHAR(120) | NOT NULL |
| description | VARCHAR(400) | NOT NULL |
| unit | VARCHAR(30) | NOT NULL |
| qty | NUMERIC(18, 3) | NOT NULL |
| price | NUMERIC(18, 2) | NOT NULL |
| done | NUMERIC(18, 3) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |
| deleted | BOOLEAN | NOT NULL |

## budget_lines

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| category | VARCHAR(20) | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| note | VARCHAR(300) | NOT NULL |

## contracts

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| code | VARCHAR(40) | NOT NULL UNIQUE |
| kind | VARCHAR(20) | NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| party_id | VARCHAR(32) | NOT NULL FK→parties.id |
| title | VARCHAR(300) | NOT NULL |
| original_value | NUMERIC(18, 2) | NOT NULL |
| start_date | DATE |  |
| end_date | DATE |  |
| advance_pct | NUMERIC(5, 2) | NOT NULL |
| retention_pct | NUMERIC(5, 2) | NOT NULL |
| tax_pct | NUMERIC(5, 2) | NOT NULL |
| payment_days | INTEGER | NOT NULL |
| penalty_terms | TEXT | NOT NULL |
| status | VARCHAR(20) | NOT NULL |
| version | INTEGER | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |

## correspondence

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| direction | VARCHAR(4) | NOT NULL |
| ref_no | VARCHAR(60) | NOT NULL |
| date | DATE | NOT NULL |
| party | VARCHAR(200) | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| subject | VARCHAR(400) | NOT NULL |
| due | DATE |  |
| status | VARCHAR(8) | NOT NULL |
| closure_note | TEXT | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## daily_reports

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| date | DATE | NOT NULL |
| weather | VARCHAR(40) | NOT NULL |
| workers_count | INTEGER | NOT NULL |
| work | TEXT | NOT NULL |
| issues | TEXT | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## employees

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| code | VARCHAR(40) | NOT NULL UNIQUE |
| name | VARCHAR(200) | NOT NULL |
| job | VARCHAR(120) | NOT NULL |
| dept | VARCHAR(80) | NOT NULL |
| national_id | VARCHAR(20) | NOT NULL |
| phone | VARCHAR(60) | NOT NULL |
| hire_date | DATE |  |
| basic | NUMERIC(18, 2) | NOT NULL |
| allowances | NUMERIC(18, 2) | NOT NULL |
| insured | BOOLEAN | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| status | VARCHAR(20) | NOT NULL |
| version | INTEGER | NOT NULL |

## equipment_usage

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| equipment_id | VARCHAR(32) | NOT NULL FK→equipment.id |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| date | DATE | NOT NULL |
| days | NUMERIC(6, 2) | NOT NULL |
| rate | NUMERIC(18, 2) | NOT NULL |
| legacy_id | VARCHAR(40) |  |

## handovers

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| kind | VARCHAR(10) | NOT NULL |
| status | VARCHAR(12) | NOT NULL |
| date | DATE |  |
| warranty_months | INTEGER | NOT NULL |
| checks | JSON | NOT NULL |
| override_reason | VARCHAR(300) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## inspections

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| item | VARCHAR(300) | NOT NULL |
| kind | VARCHAR(10) | NOT NULL |
| date | DATE | NOT NULL |
| inspector | VARCHAR(120) | NOT NULL |
| status | VARCHAR(20) | NOT NULL |
| note | TEXT | NOT NULL |
| decided_by | VARCHAR(32) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| legacy_id | VARCHAR(40) |  |

## journal_entries

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| date | DATE | NOT NULL |
| description | VARCHAR(400) | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| source | VARCHAR(30) | NOT NULL |
| reverses_id | VARCHAR(32) | UNIQUE FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |
| created_at | DATETIME | NOT NULL |

## purchase_requests

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| lines | JSON | NOT NULL |
| status | VARCHAR(12) | NOT NULL |
| note | VARCHAR(400) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| decided_by | VARCHAR(32) | NOT NULL |

## rfqs

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| item | VARCHAR(300) | NOT NULL |
| unit | VARCHAR(20) | NOT NULL |
| qty | NUMERIC(18, 3) | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| status | VARCHAR(12) | NOT NULL |
| awarded_party_id | VARCHAR(32) | FK→parties.id |
| award_note | VARCHAR(300) | NOT NULL |
| version | INTEGER | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| created_at | DATETIME | NOT NULL |
| legacy_id | VARCHAR(64) |  |

## risks

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| description | TEXT | NOT NULL |
| prob | INTEGER | NOT NULL |
| impact | INTEGER | NOT NULL |
| owner | VARCHAR(120) | NOT NULL |
| mitigation | TEXT | NOT NULL |
| status | VARCHAR(10) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## safety_records

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| date | DATE | NOT NULL |
| kind | VARCHAR(12) | NOT NULL |
| severity | VARCHAR(8) | NOT NULL |
| description | TEXT | NOT NULL |
| action | TEXT | NOT NULL |
| status | VARCHAR(8) | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## schedule_tasks

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| name | VARCHAR(300) | NOT NULL |
| start | DATE | NOT NULL |
| end | DATE | NOT NULL |
| progress | NUMERIC(5, 2) | NOT NULL |
| predecessor_id | VARCHAR(32) | FK→schedule_tasks.id |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |
| deleted | BOOLEAN | NOT NULL |

## site_documents

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| doc_type | VARCHAR(60) | NOT NULL |
| name | VARCHAR(300) | NOT NULL |
| issue_date | DATE |  |
| expiry_date | DATE |  |
| attachment_id | VARCHAR(32) | FK→attachments.id |
| legacy_id | VARCHAR(40) |  |
| deleted | BOOLEAN | NOT NULL |

## tenders

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| name | VARCHAR(300) | NOT NULL |
| client_id | VARCHAR(32) | FK→parties.id |
| type | VARCHAR(80) | NOT NULL |
| due | DATE |  |
| value | NUMERIC(18, 2) | NOT NULL |
| cost | NUMERIC(18, 2) | NOT NULL |
| stage | VARCHAR(12) | NOT NULL |
| note | TEXT | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |
| deleted | BOOLEAN | NOT NULL |

## advance_payments

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| contract_id | VARCHAR(32) | NOT NULL FK→contracts.id |
| date | DATE | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| method | VARCHAR(20) | NOT NULL |
| ref | VARCHAR(100) | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| reversed | BOOLEAN | NOT NULL |
| reverse_entry_id | VARCHAR(32) | FK→journal_entries.id |
| reverse_reason | VARCHAR(300) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |

## attendance_records

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| employee_id | VARCHAR(32) | NOT NULL FK→employees.id |
| date | DATE | NOT NULL |
| status | VARCHAR(12) | NOT NULL |
| hours | NUMERIC(5, 2) | NOT NULL |
| overtime_hours | NUMERIC(5, 2) | NOT NULL |
| import_id | VARCHAR(32) | NOT NULL FK→attendance_imports.id |

## change_orders

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| contract_id | VARCHAR(32) | NOT NULL FK→contracts.id |
| no | INTEGER | NOT NULL |
| title | VARCHAR(300) | NOT NULL |
| reason | TEXT | NOT NULL |
| items | JSON | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| time_days | INTEGER | NOT NULL |
| status | VARCHAR(20) | NOT NULL |
| history | JSON | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |

## custodies

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| person | VARCHAR(200) | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| amount | NUMERIC(18, 2) | NOT NULL |
| date | DATE | NOT NULL |
| settled | BOOLEAN | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| settle_entry_id | VARCHAR(32) | FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |

## employee_loans

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| employee_id | VARCHAR(32) | NOT NULL FK→employees.id |
| amount | NUMERIC(18, 2) | NOT NULL |
| monthly | NUMERIC(18, 2) | NOT NULL |
| repaid | NUMERIC(18, 2) | NOT NULL |
| note | VARCHAR(300) | NOT NULL |

## guarantees

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| kind | VARCHAR(20) | NOT NULL |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| contract_id | VARCHAR(32) | FK→contracts.id |
| party_id | VARCHAR(32) | FK→parties.id |
| bank | VARCHAR(120) | NOT NULL |
| ref | VARCHAR(80) | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| remaining | NUMERIC(18, 2) | NOT NULL |
| issue_date | DATE | NOT NULL |
| expiry_date | DATE | NOT NULL |
| status | VARCHAR(20) | NOT NULL |

## invoices

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| contract_id | VARCHAR(32) | NOT NULL FK→contracts.id |
| no | INTEGER | NOT NULL |
| date | DATE | NOT NULL |
| description | VARCHAR(300) | NOT NULL |
| final | BOOLEAN | NOT NULL |
| gross | NUMERIC(18, 2) | NOT NULL |
| advance | NUMERIC(18, 2) | NOT NULL |
| retention | NUMERIC(18, 2) | NOT NULL |
| tax | NUMERIC(18, 2) | NOT NULL |
| other | NUMERIC(18, 2) | NOT NULL |
| net | NUMERIC(18, 2) | NOT NULL |
| status | VARCHAR(20) | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |
| approved_by | VARCHAR(32) | NOT NULL |
| history | JSON | NOT NULL |

## journal_lines

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| entry_id | VARCHAR(32) | NOT NULL FK→journal_entries.id |
| account_code | VARCHAR(20) | NOT NULL FK→accounts.code |
| debit | NUMERIC(18, 2) | NOT NULL |
| credit | NUMERIC(18, 2) | NOT NULL |

## labor_days

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| worker_id | VARCHAR(32) | NOT NULL FK→workers.id |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| date | DATE | NOT NULL |
| days | NUMERIC(4, 2) | NOT NULL |
| rate | NUMERIC(18, 2) | NOT NULL |
| paid | BOOLEAN | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| legacy_id | VARCHAR(40) |  |

## payroll_runs

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| month | VARCHAR(7) | NOT NULL UNIQUE |
| status | VARCHAR(12) | NOT NULL |
| params | JSON | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| pay_entry_id | VARCHAR(32) | FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |
| approved_by | VARCHAR(32) | NOT NULL |

## purchase_orders

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| supplier_id | VARCHAR(32) | NOT NULL FK→parties.id |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| request_id | VARCHAR(32) | FK→purchase_requests.id |
| status | VARCHAR(12) | NOT NULL |
| total | NUMERIC(18, 2) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
| approved_by | VARCHAR(32) | NOT NULL |

## rfq_quotes

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| rfq_id | VARCHAR(32) | NOT NULL FK→rfqs.id |
| party_id | VARCHAR(32) | NOT NULL FK→parties.id |
| price | NUMERIC(18, 2) | NOT NULL |
| note | VARCHAR(300) | NOT NULL |

## snags

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| no | INTEGER | NOT NULL UNIQUE |
| project_id | VARCHAR(32) | NOT NULL FK→projects.id |
| inspection_id | VARCHAR(32) | FK→inspections.id |
| location | VARCHAR(300) | NOT NULL |
| description | TEXT | NOT NULL |
| severity | VARCHAR(10) | NOT NULL |
| due | DATE |  |
| status | VARCHAR(10) | NOT NULL |
| responsible | VARCHAR(200) | NOT NULL |
| opened | DATE | NOT NULL |
| closed | DATE |  |
| closure_note | TEXT | NOT NULL |
| legacy_id | VARCHAR(40) |  |
| version | INTEGER | NOT NULL |

## stock_movements

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| item_id | VARCHAR(32) | NOT NULL FK→items.id |
| kind | VARCHAR(10) | NOT NULL |
| qty | NUMERIC(18, 3) | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| project_id | VARCHAR(32) | FK→projects.id |
| ref | VARCHAR(80) | NOT NULL |
| note | VARCHAR(300) | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |
| created_at | DATETIME | NOT NULL |

## custody_expenses

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| custody_id | VARCHAR(32) | NOT NULL FK→custodies.id |
| date | DATE | NOT NULL |
| category | VARCHAR(10) | NOT NULL |
| description | VARCHAR(300) | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |

## payments

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| invoice_id | VARCHAR(32) | NOT NULL FK→invoices.id |
| date | DATE | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| method | VARCHAR(20) | NOT NULL |
| ref | VARCHAR(100) | NOT NULL |
| entry_id | VARCHAR(32) | FK→journal_entries.id |
| created_by | VARCHAR(32) | NOT NULL |

## payroll_lines

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| run_id | VARCHAR(32) | NOT NULL FK→payroll_runs.id |
| employee_id | VARCHAR(32) | NOT NULL FK→employees.id |
| absent_days | NUMERIC(5, 2) | NOT NULL |
| overtime_hours | NUMERIC(6, 2) | NOT NULL |
| bonus | NUMERIC(18, 2) | NOT NULL |
| penalty | NUMERIC(18, 2) | NOT NULL |
| base | NUMERIC(18, 2) | NOT NULL |
| absence_ded | NUMERIC(18, 2) | NOT NULL |
| overtime_pay | NUMERIC(18, 2) | NOT NULL |
| gross | NUMERIC(18, 2) | NOT NULL |
| emp_ins | NUMERIC(18, 2) | NOT NULL |
| er_ins | NUMERIC(18, 2) | NOT NULL |
| tax | NUMERIC(18, 2) | NOT NULL |
| loan | NUMERIC(18, 2) | NOT NULL |
| net | NUMERIC(18, 2) | NOT NULL |

## po_lines

| العمود | النوع | قيود |
|---|---|---|
| id | INTEGER | PK NOT NULL |
| po_id | VARCHAR(32) | NOT NULL FK→purchase_orders.id |
| item_id | VARCHAR(32) | NOT NULL FK→items.id |
| qty | NUMERIC(18, 3) | NOT NULL |
| price | NUMERIC(18, 2) | NOT NULL |
| received | NUMERIC(18, 3) | NOT NULL |

## supplier_invoices

| العمود | النوع | قيود |
|---|---|---|
| id | VARCHAR(32) | PK NOT NULL |
| po_id | VARCHAR(32) | NOT NULL FK→purchase_orders.id |
| ref | VARCHAR(80) | NOT NULL |
| date | DATE | NOT NULL |
| amount | NUMERIC(18, 2) | NOT NULL |
| paid | NUMERIC(18, 2) | NOT NULL |
| created_by | VARCHAR(32) | NOT NULL |
