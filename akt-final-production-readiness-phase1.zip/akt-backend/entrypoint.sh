#!/bin/sh
set -e
alembic upgrade head          # ترحيل المخطط قبل التشغيل (آمن للتكرار)
exec uvicorn app.main:create_app --factory --host 0.0.0.0 --port 8000 --proxy-headers --forwarded-allow-ips='*'
