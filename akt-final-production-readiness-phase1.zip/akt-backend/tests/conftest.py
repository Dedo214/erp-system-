import os, tempfile, pytest
d = tempfile.mkdtemp()
os.environ.update(DATABASE_URL=os.getenv("AKT_TEST_DB_URL") or f"sqlite:///{d}/t.db", AKT_SECRET_KEY="x" * 40, AKT_UPLOAD_DIR=f"{d}/up", AKT_MAX_FAILED_LOGINS="3")
from fastapi.testclient import TestClient
from app.main import create_app
from app.db import SessionLocal, Base, engine
from app.models import User, Role
from app.security import hash_password
from sqlalchemy import select

@pytest.fixture()
def env():
    Base.metadata.drop_all(engine)
    app = create_app()
    c = TestClient(app, raise_server_exceptions=False)
    with SessionLocal() as db:
        for name, role in (("admin1", "admin"), ("acct1", "accountant"), ("store1", "storekeeper")):
            r = db.execute(select(Role).where(Role.name == role)).scalar_one()
            db.add(User(username=name, password_hash=hash_password("Passw0rd!long"), roles=[r]))
        db.commit()
    def login(u, p="Passw0rd!long"):
        r = c.post("/auth/login", json={"username": u, "password": p})
        return {"authorization": "Bearer " + r.json()["token"]} if r.status_code == 200 else r
    return c, login
