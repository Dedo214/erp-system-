import os, pytest
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient

pytestmark = pytest.mark.skipif("postgresql" not in os.environ.get("DATABASE_URL", ""), reason="يتطلب PostgreSQL")

def test_parallel_postings_unique_numbers_and_chain_ok(env):
    c, login = env
    A = login("admin1")
    from app.main import create_app
    app = c.app
    body = {"date": "2026-11-01", "description": "t", "lines": [{"account_code": "1100", "debit": 10}, {"account_code": "3100", "credit": 10}]}
    def one(_):
        with TestClient(app) as cc:
            r = cc.post("/ledger/entries", json=body, headers=A); return r.status_code, (r.json().get("no") if r.status_code == 201 else r.text)
    with ThreadPoolExecutor(8) as ex: res = list(ex.map(one, range(24)))
    assert all(s == 201 for s, _ in res), res
    nos = [n for _, n in res]; assert len(set(nos)) == 24 and sorted(nos) == list(range(1, 25))
    assert c.get("/audit/verify", headers=A).json()["ok"]
    assert c.get("/ledger/trial-balance", headers=A).json()["balanced"]
