import json
from sqlalchemy import select, update
from app.db import SessionLocal
from app.models import AuditLog, User, JournalEntry

PROJ = {"code": "P1", "name": "برج", "contract_value": "1000000", "budget": "800000"}

def test_auth_required_and_wrong_password(env):
    c, login = env
    assert c.get("/projects").status_code == 401
    assert c.post("/auth/login", json={"username": "admin1", "password": "bad"}).status_code == 401

def test_lockout_after_failed_attempts(env):
    c, login = env
    for _ in range(3): c.post("/auth/login", json={"username": "acct1", "password": "bad"})
    r = c.post("/auth/login", json={"username": "acct1", "password": "Passw0rd!long"})
    assert r.status_code == 423                        # حتى كلمة المرور الصحيحة مرفوضة أثناء القفل

def test_rbac_enforced_on_server(env):
    c, login = env
    st, ac, ad = login("store1"), login("acct1"), login("admin1")
    assert c.post("/projects", json=PROJ, headers=st).status_code == 403       # أمين المخزن لا ينشئ مشروعاً
    assert c.post("/projects", json=PROJ, headers=ac).status_code == 403       # المحاسب أيضاً
    assert c.post("/projects", json=PROJ, headers=ad).status_code == 201
    assert c.get("/projects", headers=st).status_code == 200
    assert c.get("/audit", headers=ac).status_code == 403
    assert c.post("/admin/backup", headers=ac).status_code == 403
    assert c.get("/users", headers=st).status_code == 403

def test_optimistic_concurrency(env):
    c, login = env; ad = login("admin1")
    p = c.post("/projects", json=PROJ, headers=ad).json()
    ok = c.patch(f"/projects/{p['id']}", json={"version": 1, "progress": "10"}, headers=ad)
    assert ok.status_code == 200 and ok.json()["version"] == 2
    stale = c.patch(f"/projects/{p['id']}", json={"version": 1, "progress": "20"}, headers=ad)
    assert stale.status_code == 409                    # مستخدم ثانٍ بنسخة قديمة لا يكتب فوق التعديل
    assert c.patch(f"/projects/{p['id']}", json={"version": 2, "budget": "1"}, headers=ad).status_code == 422   # سبب مطلوب

def test_validation_rejects_bad_data(env):
    c, login = env; ad = login("admin1")
    assert c.post("/projects", json={**PROJ, "progress": "150"}, headers=ad).status_code == 422
    assert c.post("/projects", json={**PROJ, "contract_value": "-5"}, headers=ad).status_code == 422
    assert c.post("/projects", json={**PROJ, "start_date": "2026-05-01", "end_date": "2026-01-01"}, headers=ad).status_code == 422

def test_journal_balanced_and_immutable(env):
    c, login = env; ac = login("acct1")
    bad = {"date": "2026-01-10", "description": "x", "lines": [{"account_code": "1100", "debit": "100"}, {"account_code": "4100", "credit": "90"}]}
    assert c.post("/ledger/entries", json=bad, headers=ac).status_code == 422
    good = {**bad, "lines": [{"account_code": "1100", "debit": "100.10"}, {"account_code": "4100", "credit": "100.10"}]}
    e = c.post("/ledger/entries", json=good, headers=ac)
    assert e.status_code == 201 and e.json()["no"] == 1
    assert c.delete(f"/ledger/entries/{e.json()['id']}", headers=ac).status_code in (404, 405)   # لا يوجد مسار حذف للقيود أصلاً
    assert c.post("/ledger/entries", json={**good, "lines": [{"account_code": "9999", "debit": "1"}, {"account_code": "4100", "credit": "1"}]}, headers=ac).status_code == 422
    r = c.post(f"/ledger/entries/{e.json()['id']}/reverse", params={"reason": "خطأ"}, headers=ac)
    assert r.status_code == 201
    assert c.post(f"/ledger/entries/{e.json()['id']}/reverse", params={"reason": "ثانية"}, headers=ac).status_code == 409
    tb = c.get("/ledger/trial-balance", headers=ac).json()
    assert tb["balanced"] and float(tb["total_debit"]) == 200.2

def test_period_lock(env):
    c, login = env; ac, ad = login("acct1"), login("admin1")
    e = {"date": "2026-01-10", "description": "x", "lines": [{"account_code": "1100", "debit": "5"}, {"account_code": "4100", "credit": "5"}]}
    assert c.put("/ledger/period-lock", json={"lock_date": "2026-03-31"}, headers=ac).status_code == 403
    assert c.put("/ledger/period-lock", json={"lock_date": "2026-03-31", "reason": "إقفال ربع"}, headers=ad).status_code == 200
    assert c.post("/ledger/entries", json=e, headers=ac).status_code == 423
    assert c.put("/ledger/period-lock", json={"lock_date": "2999-01-01"}, headers=ad).status_code == 422

def test_failed_operation_is_rolled_back_and_not_audited(env):
    c, login = env; ac = login("acct1")
    before = c.get("/ledger/entries", headers=ac).json()
    c.post("/ledger/entries", json={"date": "2026-01-10", "description": "x", "lines": [{"account_code": "1100", "debit": "9"}, {"account_code": "4100", "credit": "1"}]}, headers=ac)
    assert c.get("/ledger/entries", headers=ac).json() == before
    with SessionLocal() as db:
        assert db.execute(select(AuditLog).where(AuditLog.action == "ledger.post")).first() is None

def test_audit_log_records_before_after_and_chain_detects_tamper(env):
    c, login = env; ad = login("admin1")
    p = c.post("/projects", json=PROJ, headers=ad).json()
    c.patch(f"/projects/{p['id']}", json={"version": 1, "budget": "900000", "reason": "تعديل ميزانية معتمد"}, headers=ad)
    a = [x for x in c.get("/audit", params={"entity": "project"}, headers=ad).json() if x["action"] == "projects.update"][0]
    assert a["before"]["budget"] == "800000.00" and a["after"]["budget"] == "900000.00" and a["reason"]
    assert a["username"] == "admin1"
    assert c.get("/audit/verify", headers=ad).json()["ok"] is True
    with SessionLocal() as db:                         # عبث مباشر بقاعدة البيانات
        db.execute(update(AuditLog).where(AuditLog.id == a["id"]).values(reason="مزوّر")); db.commit()
    v = c.get("/audit/verify", headers=ad).json()
    assert v["ok"] is False and v["broken_at"] == a["id"]

def test_password_change_revokes_old_sessions(env):
    c, login = env; h = login("acct1")
    assert c.post("/auth/change-password", json={"old_password": "Passw0rd!long", "new_password": "N3w-Password-ok"}, headers=h).status_code == 200
    assert c.get("/auth/me", headers=h).status_code == 401
    assert c.post("/auth/change-password", json={"old_password": "N3w-Password-ok", "new_password": "short"}, headers=login("acct1", "N3w-Password-ok")).status_code == 422

def test_passwords_are_hashed(env):
    with SessionLocal() as db:
        u = db.execute(select(User).where(User.username == "admin1")).scalar_one()
        assert u.password_hash.startswith("$argon2") and "Passw0rd" not in u.password_hash

LEGACY = {"projects": [{"id": "p1", "name": "برج الياسمين", "client": "العمران", "location": "القاهرة", "start": "2026-01-01", "end": "2027-01-01", "value": 10000000, "budget": 8500000, "progress": 46, "status": "جارٍ"},
                       {"id": "p2", "name": "", "client": "x"}],
          "suppliers": [{"id": "s1", "name": "الأمل", "phone": "010", "terms": 10, "limit": 5000000}],
          "subs": [{"id": "u1", "name": "الفنار"}], "invoices": [{"id": "i1", "amount": 5}], "txs": [{"id": "t1"}]}

def test_legacy_import_keeps_everything_and_is_idempotent(env):
    c, login = env; ad = login("admin1")
    r = c.post("/legacy/import", json=LEGACY, headers=ad)
    assert r.status_code == 201
    j = r.json()
    assert (j["projects"], j["suppliers"], j["subcontractors"], j["clients"], j["skipped"]) == (1, 1, 1, 1, 1)
    nm = {x["module"] for x in j["not_migrated"]}; assert {"invoices", "txs"} <= nm   # التاريخ المالي يُبلَّغ عنه صراحة ولا يُرحَّل آليًا
    again = c.post("/legacy/import", json=LEGACY, headers=ad).json()
    assert again["new_snapshot"] is False and again["projects"] == 0 and again["suppliers"] == 0
    assert len(c.get("/projects", headers=ad).json()) == 1
    from app.models import LegacySnapshot
    with SessionLocal() as db:
        snap = db.execute(select(LegacySnapshot)).scalar_one()
        assert snap.data["invoices"] == LEGACY["invoices"]          # لا ضياع للبيانات غير المنقولة بعد
    assert c.post("/legacy/import", json={"x": 1}, headers=ad).status_code == 422
    assert c.post("/legacy/import", json=LEGACY, headers=login("acct1")).status_code == 403

def test_backup_restore_roundtrip(env):
    c, login = env; ad = login("admin1"); ac = login("acct1")
    p = c.post("/projects", json=PROJ, headers=ad).json()
    c.post("/ledger/entries", json={"date": "2026-01-10", "description": "x", "lines": [{"account_code": "1100", "debit": "7.5"}, {"account_code": "4100", "credit": "7.5"}]}, headers=ac)
    bk = c.post("/admin/backup", headers=ad).json()
    c.patch(f"/projects/{p['id']}", json={"version": 1, "name": "اسم جديد"}, headers=ad)
    tampered = json.loads(json.dumps(bk)); tampered["tables"]["projects"][0]["name"] = "عبث"
    assert c.post("/admin/restore", params={"reason": "x"}, json=tampered, headers=ad).status_code == 422
    assert c.post("/admin/restore", params={"reason": "اختبار"}, json=bk, headers=ad).status_code == 200
    assert c.get("/projects", headers=ad).json()[0]["name"] == "برج"
    assert len(c.get("/ledger/entries", headers=ad).json()) == 1
    assert c.get("/audit/verify", headers=ad).json()["ok"] is True

def test_file_upload_rules(env):
    c, login = env; ad = login("admin1"); st = login("store1")
    ok = c.post("/files", params={"entity": "project", "entity_id": "x"}, files={"file": ("a.pdf", b"%PDF-1.4 hi", "application/pdf")}, headers=st)
    assert ok.status_code == 201
    assert c.post("/files", params={"entity": "p", "entity_id": "x"}, files={"file": ("a.exe", b"MZ", "application/octet-stream")}, headers=ad).status_code == 415
    assert c.post("/files", params={"entity": "p", "entity_id": "x"}, files={"file": ("a.pdf", b"not pdf", "application/pdf")}, headers=ad).status_code == 415
    assert c.post("/files", params={"entity": "p", "entity_id": "x"}, files={"file": ("../../etc/x.pdf", b"%PDF-1", "application/pdf")}, headers=ad).status_code == 201

def test_user_management_and_deactivation(env):
    c, login = env; ad = login("admin1")
    r = c.post("/users", json={"username": "New1", "password": "Passw0rd!long", "roles": ["storekeeper"]}, headers=ad)
    assert r.status_code == 201
    assert c.post("/users", json={"username": "x", "password": "short", "roles": []}, headers=ad).status_code in (422,)
    assert c.post("/users", json={"username": "bad1", "password": "Passw0rd!long", "roles": ["nope"]}, headers=ad).status_code == 422
    h = login("new1")
    assert c.get("/auth/me", headers=h).status_code == 200
    c.patch(f"/users/{r.json()['id']}", json={"is_active": False}, headers=ad)
    assert c.get("/auth/me", headers=h).status_code == 401

def test_ui_served_with_csp(env):
    c, login = env
    r = c.get("/")
    assert r.status_code == 200 and "Akt Group ERP" in r.text
    assert "frame-ancestors 'none'" in r.headers["content-security-policy"]
    assert r.headers["x-frame-options"] == "DENY"
