from decimal import Decimal

def mk(c, H):
    pid = c.post("/projects", json={"code": "P1", "name": "م"}, headers=H).json()["id"]
    sup = c.post("/parties", json={"kind": "supplier", "name": "مورد أ"}, headers=H).json()["id"]
    sup2 = c.post("/parties", json={"kind": "supplier", "name": "مورد ب"}, headers=H).json()["id"]
    sub = c.post("/parties", json={"kind": "subcontractor", "name": "مقاول"}, headers=H).json()["id"]
    cl = c.post("/parties", json={"kind": "client", "name": "عميل"}, headers=H).json()["id"]
    return pid, sup, sup2, sub, cl

def test_ratings(env):
    from sqlalchemy import select
    from app.db import SessionLocal; from app.models import User, Role; from app.security import hash_password
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    c, login = env; A, E = login("admin1"), login("eng1")
    pid, sup, sup2, sub, cl = mk(c, A)
    ok = {"date": "2026-11-01", "quality": 5, "punctuality": 4, "price": 3}
    assert c.post("/ratings", json={**ok, "party_id": sup}, headers=E).status_code == 201          # المهندس يقيّم
    assert c.post("/ratings", json={**ok, "party_id": sup, "quality": 4}, headers=A).status_code == 201
    assert c.post("/ratings", json={**ok, "party_id": cl}, headers=A).status_code == 422             # العميل لا يُقيَّم
    assert c.post("/ratings", json={**ok, "party_id": sup, "quality": 6}, headers=A).status_code == 422
    rep = c.get("/reports/vendor-ratings", headers=E).json()
    s = next(r for r in rep if r["party_id"] == sup); assert s["count"] == 2 and s["quality"] == 4.5 and s["overall"] == 3.83
    assert next(r for r in rep if r["party_id"] == sub)["overall"] is None and rep[0]["party_id"] == sup   # غير المُقيَّم آخرًا

def test_rfq_flow(env):
    c, login = env; A, S = login("admin1"), login("store1")
    pid, sup, sup2, sub, cl = mk(c, A)
    r = c.post("/rfqs", json={"item": "حديد 16", "unit": "طن", "qty": 10, "project_id": pid}, headers=A).json(); assert r["no"] == 1
    assert c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup, "price": 100, "version": 1}, headers=S).status_code == 403   # أمين المخزن لا يضيف عروضًا
    r = c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup, "price": 100, "version": 1}, headers=A).json()
    assert c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sub, "price": 90, "version": r["version"]}, headers=A).status_code == 422   # مورد فقط
    assert c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup2, "price": 90, "version": 1}, headers=A).status_code == 409           # نسخة قديمة
    r = c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup2, "price": 90, "version": r["version"]}, headers=A).json()
    assert r["lowest"] == "مورد ب" and r["quotes"][0]["total"] == 900
    r = c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup, "price": 95, "version": r["version"]}, headers=A).json()     # يحل محل القديم
    assert r["quotes_count"] == 2 and next(q for q in r["quotes"] if q["name"] == "مورد أ")["price"] == 95
    assert c.post(f"/rfqs/{r['id']}/award", json={"party_id": sup, "version": r["version"]}, headers=A).status_code == 422      # غير الأقل بلا سبب
    r = c.post(f"/rfqs/{r['id']}/award", json={"party_id": sup, "version": r["version"], "reason": "أسرع توريد"}, headers=A).json()
    assert r["status"] == "awarded" and r["awarded_name"] == "مورد أ"
    assert c.post(f"/rfqs/{r['id']}/quotes", json={"party_id": sup2, "price": 80, "version": r["version"]}, headers=A).status_code == 409   # مغلق
    assert [a for a in c.get("/audit?limit=60", headers=A).json() if a["action"] == "rfq.award"]

def test_stock_count(env):
    c, login = env; A, S = login("admin1"), login("store1")
    pid, sup, *_ = mk(c, A)
    a = c.post("/items", json={"code": "A", "name": "إسمنت", "unit": "كيس"}, headers=A).json()["id"]
    b = c.post("/items", json={"code": "B", "name": "رمل", "unit": "م3"}, headers=A).json()["id"]
    po = c.post("/purchase-orders", json={"supplier_id": sup, "project_id": pid, "lines": [{"item_id": a, "qty": 100, "price": 50}, {"item_id": b, "qty": 10, "price": 200}]}, headers=login("acct1"))
    assert po.status_code == 201, po.text
    po = po.json(); assert c.post(f"/purchase-orders/{po['id']}/approve", headers=A).status_code in (200, 201)
    pl = {l["item_id"]: l["id"] for l in po["lines"]}
    rc = c.post(f"/purchase-orders/{po['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": pl[a], "qty": 100}, {"po_line_id": pl[b], "qty": 10}]}, headers=A); assert rc.status_code == 201, rc.text
    cnt = c.post("/stock-counts", json={"date": "2026-11-05"}, headers=S); assert cnt.status_code == 201; cnt = cnt.json()
    assert cnt["total"] == 2 and cnt["no"] == 1
    cnt = c.put(f"/stock-counts/{cnt['id']}/lines", json={"version": cnt["version"], "lines": [{"item_id": a, "counted_qty": 96}, {"item_id": b, "counted_qty": 10}]}, headers=S).json()
    assert cnt["variances"] == 1 and float(cnt["net_value"]) == -200.0          # 4 أكياس × 50
    ap = {"version": cnt["version"], "reason": "عجز مخزني بعد الجرد"}
    assert c.post(f"/stock-counts/{cnt['id']}/approve", json=ap, headers=S).status_code == 403          # أمين المخزن لا يملك الاعتماد
    # صنف تحرك بعد بدء الجرد → يمنع الاعتماد
    c.post("/stock/issue", json={"item_id": a, "qty": 1, "project_id": pid, "date": "2026-11-06"}, headers=A)
    r = c.post(f"/stock-counts/{cnt['id']}/approve", json=ap, headers=A); assert r.status_code == 409 and "A" in r.text
    cnt2 = c.post("/stock-counts", json={"date": "2026-11-07", "item_ids": [a]}, headers=S).json()
    cnt2 = c.put(f"/stock-counts/{cnt2['id']}/lines", json={"version": cnt2["version"], "lines": [{"item_id": a, "counted_qty": 90}]}, headers=S).json()
    ap2 = {"version": cnt2["version"], "reason": "جرد دوري"}
    # الذي أجرى الجرد لا يعتمده ولو كان يملك الصلاحية
    adm_cnt = c.post("/stock-counts", json={"date": "2026-11-07", "item_ids": [b]}, headers=A).json()
    assert c.post(f"/stock-counts/{adm_cnt['id']}/approve", json={"version": adm_cnt["version"], "reason": "تجربة"}, headers=A).status_code in (403, 422)
    r = c.post(f"/stock-counts/{cnt2['id']}/approve", json=ap2, headers=A); assert r.status_code == 200, r.text
    r = r.json(); assert r["status"] == "approved" and r["adjusted_items"] == 1 and float(r["net_adjustment"]) == -450.0   # 99→90 = 9×50
    its = {i["code"]: i for i in c.get("/items", headers=A).json()}; assert Decimal(str(its["A"]["qty"])) == 90
    st = c.get("/reports/stock", headers=A).json(); assert float(st["difference"]) == 0             # الأستاذ = دفاتر المخزون
    assert c.post(f"/stock-counts/{cnt2['id']}/approve", json={"version": r["version"], "reason": "مرة ثانية"}, headers=A).status_code == 409

def test_legacy_ratings_rfqs(env):
    c, login = env; A = login("admin1")
    data = {"projects": [{"id": "p1", "name": "مشروع", "client": "c1"}], "clients": [{"id": "c1", "name": "عميل"}],
            "suppliers": [{"id": "s1", "name": "مورد 1"}, {"id": "s2", "name": "مورد 2"}], "subs": [{"id": "u1", "name": "مقاول 1"}],
            "ratings": [{"id": "r1", "kind": "sup", "rid": "s1", "date": "2026-10-01", "quality": 5, "time": 4, "price": 3},
                        {"id": "r2", "kind": "sub", "rid": "u1", "date": "2026-10-02", "quality": 4, "time": 4, "price": 4},
                        {"id": "r3", "kind": "sup", "rid": "zz", "date": "2026-10-02", "quality": 4, "time": 4, "price": 4}],
            "rfqs": [{"id": "q1", "item": "حديد", "unit": "طن", "qty": 120, "pid": "p1", "done": False,
                      "quotes": [{"sid": "s1", "price": 38100}, {"sid": "s2", "price": 38600, "note": "ن"}, {"sid": "zz", "price": 1}]}],
            "cos": [{"id": "o1", "pid": "p1", "no": 1, "desc": "تعديل", "amount": 1, "status": "معتمد"}],
            "counts": [{"id": "k1", "date": "2026-01-01", "lines": []}], "plan": [{"id": "pl1"}], "approvals": [{"id": "a1"}]}
    r = c.post("/legacy/import", json=data, headers=A); assert r.status_code == 201, r.text; r = r.json()
    assert r["ratings"] == 2 and r["rfqs"] == 1 and r["skipped"] >= 1 and not r["pending_modules"]
    assert {"cos", "counts", "plan", "approvals"} <= {x["module"] for x in r["not_migrated"]}
    assert all(x["reason"] for x in r["not_migrated"])
    rf = c.get("/rfqs", headers=A).json()[0]; assert rf["quotes_count"] == 2 and rf["lowest"] == "مورد 1" and rf["status"] == "open"
    assert len(c.get("/reports/vendor-ratings", headers=A).json()) == 3
    r2 = c.post("/legacy/import", json=data, headers=A).json(); assert r2["ratings"] == 0 and r2["rfqs"] == 0          # إعادة الاستيراد لا تكرر
