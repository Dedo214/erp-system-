from decimal import Decimal
D = lambda x: Decimal(str(x))

def mkp(c, H, cv=1000000):
    r = c.post("/projects", json={"code": "B1", "name": "مشروع الموازنة", "contract_value": cv}, headers=H); assert r.status_code == 201, r.text
    return r.json()

def spend(c, H, pid, acct, amt, d="2026-11-02"):
    r = c.post("/ledger/entries", json={"date": d, "description": "مصروف", "project_id": pid,
                                        "lines": [{"account_code": acct, "debit": amt}, {"account_code": "1100", "credit": amt}]}, headers=H)
    assert r.status_code == 201, r.text

def test_budget_vs_actual_and_rules(env):
    from sqlalchemy import select
    from app.db import SessionLocal; from app.models import User, Role; from app.security import hash_password
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    c, login = env; A, C, E, S = login("admin1"), login("acct1"), login("eng1"), login("store1")
    p = mkp(c, A)
    assert c.get(f"/projects/{p['id']}/budget", headers=S).status_code == 403                     # أمين المخزن لا يرى الموازنة
    b0 = c.get(f"/projects/{p['id']}/budget", headers=C).json(); assert b0["total_budget"] == 0 and b0["forecast_profit"] == 1000000
    body = {"version": p["version"], "lines": [{"category": "materials", "amount": 400000}, {"category": "labor", "amount": 200000}, {"category": "subcontractors", "amount": 100000}]}
    assert c.put(f"/projects/{p['id']}/budget", json=body, headers=E).status_code == 403          # المهندس يرى فقط
    r = c.put(f"/projects/{p['id']}/budget", json=body, headers=C); assert r.status_code == 200, r.text; r = r.json()
    assert D(r["total_budget"]) == 700000 and D(r["planned_profit"]) == 300000
    pj = next(x for x in c.get("/projects", headers=A).json() if x["id"] == p["id"]); assert D(pj["budget"]) == 700000
    assert c.patch(f"/projects/{p['id']}", json={"version": pj["version"], "budget": 1, "reason": "تجربة"}, headers=A).status_code == 409     # لا تعديل يدوي يخالف الفئات       # يغذي تنبيه الموازنة القائم
    # مصروفات فعلية على المشروع: 380k مواد (95%)، 210k عمالة (تجاوز)، 30k إدارية بلا موازنة
    spend(c, A, p["id"], "5100", 380000); spend(c, A, p["id"], "5200", 210000); spend(c, A, p["id"], "5500", 30000)
    d = c.get(f"/projects/{p['id']}/budget", headers=A).json(); rows = {x["category"]: x for x in d["rows"]}
    assert D(rows["materials"]["actual"]) == 380000 and rows["materials"]["status"] == "warn" and float(rows["materials"]["used_pct"]) == 95.0
    assert rows["labor"]["status"] == "over" and D(rows["labor"]["variance"]) == -10000
    assert rows["admin"]["status"] == "unbudgeted" and rows["subcontractors"]["status"] == "ok"
    assert D(d["total_actual"]) == 620000 and D(d["total_variance"]) == 80000
    # بلا مقايسة: التوقع = الأكبر من الموازنة والفعلي
    assert D(rows["materials"]["forecast"]) == 400000 and D(rows["labor"]["forecast"]) == 210000 and d["progress_pct"] is None
    # تعديل موازنة قائمة: سبب إلزامي + نسخة
    ver = d["version"]
    body2 = {"version": ver, "lines": [{"category": "materials", "amount": 400000}, {"category": "labor", "amount": 230000}, {"category": "subcontractors", "amount": 100000}]}
    assert c.put(f"/projects/{p['id']}/budget", json=body2, headers=C).status_code == 422
    assert c.put(f"/projects/{p['id']}/budget", json={**body2, "version": ver - 1, "reason": "زيادة أجور"}, headers=C).status_code == 409
    ok = c.put(f"/projects/{p['id']}/budget", json={**body2, "reason": "زيادة أجور العمالة"}, headers=C); assert ok.status_code == 200
    assert next(x for x in ok.json()["rows"] if x["category"] == "labor")["status"] == "warn"           # 210/230 = 91%
    assert c.put(f"/projects/{p['id']}/budget", json={"version": ok.json()["version"], "reason": "تجربة", "lines": [{"category": "x", "amount": 1}]}, headers=C).status_code == 422
    assert [a for a in c.get("/audit?limit=80", headers=A).json() if a["action"] == "budget.set"]
    ov = c.get("/reports/budget-vs-actual", headers=A).json(); assert ov[0]["has_budget"] and ov[0]["over_categories"] == 0

def test_forecast_uses_boq_progress(env):
    c, login = env; A = login("admin1")
    p = mkp(c, A)
    c.put(f"/projects/{p['id']}/budget", json={"version": p["version"], "lines": [{"category": "materials", "amount": 500000}]}, headers=A)
    it = c.post(f"/projects/{p['id']}/boq", json={"description": "خرسانة", "unit": "م3", "qty": 100, "price": 10000}, headers=A).json()
    c.patch(f"/boq/{it['id']}", json={"version": it["version"], "done": 40}, headers=A)                   # إنجاز 40%
    spend(c, A, p["id"], "5100", 300000)
    d = c.get(f"/projects/{p['id']}/budget", headers=A).json()
    assert float(d["progress_pct"]) == 40.0 and D(d["rows"][0]["forecast"]) == 750000                    # 300k ÷ 0.4
    assert D(d["forecast_profit"]) == 1000000 - 750000 and "الإنجاز" in d["forecast_basis"]
