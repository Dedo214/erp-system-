from decimal import Decimal
from sqlalchemy import select
from app.db import SessionLocal
from app.models import User, Role
from app.security import hash_password

def mk(c, login):
    with SessionLocal() as db:
        r = db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[r])); db.commit()
    A, C, E = login("admin1"), login("acct1"), login("eng1")
    pr = c.post("/projects", json={"code": "P1", "name": "مشروع", "contract_value": 5000000, "budget": 3000000}, headers=A).json()
    cl = c.post("/parties", json={"kind": "client", "name": "عميل"}, headers=A).json()
    sb = c.post("/parties", json={"kind": "subcontractor", "name": "مقاول"}, headers=A).json()
    return A, C, E, pr, cl, sb

def contract(c, A, pr, party, kind="client", code="C1", val=1000000, **kw):
    b = {"code": code, "kind": kind, "project_id": pr["id"], "party_id": party["id"], "title": "عقد", "original_value": val,
         "advance_pct": 10, "retention_pct": 5, "tax_pct": 3, "payment_days": 30, **kw}
    r = c.post("/contracts", json=b, headers=A); assert r.status_code == 201, r.text
    k = r.json(); assert c.post(f"/contracts/{k['id']}/activate", headers=A).status_code == 200
    return k

def test_contract_party_mismatch_and_dup(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    b = {"code": "X", "kind": "client", "project_id": pr["id"], "party_id": sb["id"], "title": "t", "original_value": 1}
    assert c.post("/contracts", json=b, headers=A).status_code == 422
    contract(c, A, pr, cl)
    b.update(party_id=cl["id"], code="C1")
    assert c.post("/contracts", json=b, headers=A).status_code == 409

def test_change_order_workflow_and_rbac(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    r = c.post(f"/contracts/{k['id']}/change-orders", json={"title": "إضافة", "reason": "طلب العميل", "amount": 200000}, headers=E)
    assert r.status_code == 201; o = r.json()["id"]
    adv = lambda h: c.post(f"/change-orders/{o}/advance", json={}, headers=h)
    assert adv(E).status_code == 200            # مهندس: يرسل للمراجعة الفنية
    assert adv(C).status_code == 403            # محاسب لا يملك المراجعة الفنية
    assert adv(E).status_code == 200            # مهندس يراجع فنيًا
    assert adv(E).status_code == 403            # لا يملك المراجعة المالية
    assert adv(C).status_code == 200            # محاسب مالي
    assert adv(E).status_code == 403            # الاعتماد النهائي ليس للمهندس
    assert adv(A).status_code == 200            # المدير يعتمد
    cur = c.get(f"/contracts/{k['id']}", headers=A).json()
    assert Decimal(str(cur["current_value"])) == Decimal("1200000")
    assert Decimal(str(cur["original_value"])) == Decimal("1000000")

def test_change_order_reject_needs_reason(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    o = c.post(f"/contracts/{k['id']}/change-orders", json={"title": "x", "reason": "سبب", "amount": 5}, headers=E).json()["id"]
    c.post(f"/change-orders/{o}/advance", json={}, headers=E)
    assert c.post(f"/change-orders/{o}/reject", json={}, headers=E).status_code == 422
    assert c.post(f"/change-orders/{o}/reject", json={"note": "مرفوض"}, headers=E).json()["status"] == "rejected"
    assert c.post(f"/change-orders/{o}/advance", json={}, headers=A).status_code == 409

def test_client_invoice_posting_and_collection(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    assert c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 10000}, headers=C).status_code == 201   # الدفعة المقدمة المستلمة فعلًا
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 100000}, headers=C).json()
    assert Decimal(str(i["net"])) == Decimal("82000")        # 100000 - 10% - 5% - 3%
    assert c.post(f"/invoices/{i['id']}/approve", json={}, headers=A).status_code == 409   # لم تتم المراجعة
    assert c.post(f"/invoices/{i['id']}/review", json={}, headers=C).status_code == 200
    assert c.post(f"/invoices/{i['id']}/approve", json={}, headers=C).status_code == 403   # نفس المنشئ
    ok = c.post(f"/invoices/{i['id']}/approve", json={}, headers=A); assert ok.status_code == 200, ok.text
    tb = c.get("/ledger/trial-balance", headers=A).json(); assert tb["balanced"]
    bal = {r["account_code"]: Decimal(str(r["debit"])) - Decimal(str(r["credit"])) for r in tb["rows"]}
    assert bal["1200"] == 82000 and bal["1250"] == 5000 and bal["1270"] == 3000 and bal["2200"] == 0 and bal["4100"] == -100000
    p = c.post(f"/invoices/{i['id']}/payments", json={"date": "2026-11-05", "amount": 50000}, headers=C); assert p.status_code == 201
    assert c.post(f"/invoices/{i['id']}/payments", json={"date": "2026-11-05", "amount": 40000}, headers=C).status_code == 422  # أكثر من المتبقي
    assert c.post(f"/invoices/{i['id']}/payments", json={"date": "2026-11-06", "amount": 32000}, headers=C).status_code == 201
    inv = c.get(f"/contracts/{k['id']}/invoices", headers=A).json()[0]
    assert Decimal(str(inv["outstanding"])) == 0

def test_subcontractor_invoice_posting(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, sb, kind="subcontractor", code="S1", val=500000)
    assert c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 20000}, headers=C).status_code == 201
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 200000}, headers=C).json()
    c.post(f"/invoices/{i['id']}/review", json={}, headers=C)
    assert c.post(f"/invoices/{i['id']}/approve", json={}, headers=A).status_code == 200
    tb = c.get("/ledger/trial-balance", headers=A).json(); assert tb["balanced"]
    bal = {r["account_code"]: Decimal(str(r["debit"])) - Decimal(str(r["credit"])) for r in tb["rows"]}
    assert bal["5300"] == 200000 and bal["2300"] == -164000 and bal["2400"] == -10000 and bal["2600"] == -6000 and bal["1410"] == 0

def test_invoice_cannot_exceed_contract_and_high_value_perm(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl, val=3000000)
    assert c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 3000001}, headers=C).status_code == 422
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 2000000}, headers=E).json()   # صافي 1.64م
    c.post(f"/invoices/{i['id']}/review", json={}, headers=E)
    assert c.post(f"/invoices/{i['id']}/approve", json={}, headers=C).status_code == 403   # المحاسب بلا approve_high
    assert c.post(f"/invoices/{i['id']}/approve", json={}, headers=A).status_code == 200

def test_period_lock_blocks_invoice_approval(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-01-15", "gross": 1000}, headers=C).json()
    c.post(f"/invoices/{i['id']}/review", json={}, headers=C)
    assert c.put("/ledger/period-lock", json={"lock_date": "2026-03-31", "reason": "إقفال"}, headers=A).status_code == 200
    r = c.post(f"/invoices/{i['id']}/approve", json={}, headers=A); assert r.status_code == 423
    assert c.get(f"/contracts/{k['id']}/invoices", headers=A).json()[0]["status"] == "review"   # تراجع كامل

def test_guarantees(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    b = {"kind": "performance", "project_id": pr["id"], "bank": "بنك", "ref": "G1", "amount": 100000, "issue_date": "2026-01-01", "expiry_date": "2026-12-01"}
    assert c.post("/guarantees", json={**b, "expiry_date": "2025-01-01"}, headers=C).status_code == 422
    g = c.post("/guarantees", json=b, headers=C).json()
    assert c.post(f"/guarantees/{g['id']}/act", json={"action": "reduce", "amount": 200000, "reason": "تخفيض"}, headers=C).status_code == 422
    assert c.post(f"/guarantees/{g['id']}/act", json={"action": "renew", "new_expiry": "2027-06-01", "reason": "تجديد"}, headers=C).json()["status"] == "renewed"
    assert c.post("/guarantees", json=b, headers=E).status_code == 403

def test_reports_cashflow_statements(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 10000}, headers=C)
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 100000}, headers=C).json()
    c.post(f"/invoices/{i['id']}/review", json={}, headers=C); c.post(f"/invoices/{i['id']}/approve", json={}, headers=A)
    cf = c.get("/reports/cashflow?today=2026-11-09", headers=C).json()
    assert Decimal(str(cf["buckets"]["d0_30"]["in"])) == 82000
    assert Decimal(str(cf["buckets"]["d0_30"]["net"])) == 82000
    bs = c.get("/reports/balance-sheet", headers=C).json(); assert bs["balanced"]
    inc = c.get("/reports/income-statement", headers=C).json(); assert Decimal(str(inc["net_income"])) == 100000
    gl = c.get("/reports/general-ledger/1200", headers=C).json(); assert Decimal(str(gl["closing"])) == 82000
    d = c.get(f"/reports/project/{pr['id']}", headers=C).json(); assert Decimal(str(d["profit"])) == 100000
    assert c.get("/reports/cashflow", headers=E).status_code == 403

def test_audit_chain_still_valid_after_phase2(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl)
    c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 1000}, headers=C)
    v = c.get("/audit/verify", headers=A).json(); assert v["ok"]


def test_advance_payment_recovery_is_capped_by_actual_receipt(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl, val=1000000)                      # نسبة الدفعة المقدمة في العقد 10%
    def inv(g): return c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": g}, headers=C).json()
    def settle(i):
        c.post(f"/invoices/{i['id']}/review", json={}, headers=C); return c.post(f"/invoices/{i['id']}/approve", json={}, headers=A)
    assert Decimal(str(inv(100000)["advance"])) == 0              # لا دفعة مستلمة → لا استرداد (لا رصيد سالب)
    assert c.get(f"/ledger/trial-balance", headers=A).json()["balanced"]
    a = c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 15000, "method": "cash"}, headers=C).json()
    assert c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 2000000}, headers=C).status_code == 422   # أكبر من العقد
    st = c.get(f"/contracts/{k['id']}/advances", headers=A).json()["summary"]; assert Decimal(str(st["available"])) == 15000
    i1 = inv(100000); assert Decimal(str(i1["advance"])) == 10000                # 10% كاملة (الرصيد يكفي)
    i2 = inv(100000); assert Decimal(str(i2["advance"])) == 5000                 # المتاح بعد حجز i1 = 5000 فقط
    assert Decimal(str(inv(100000)["advance"])) == 0                             # استُنفد
    assert settle(i1).status_code == 200 and settle(i2).status_code == 200
    st = c.get(f"/contracts/{k['id']}/advances", headers=A).json()["summary"]
    assert Decimal(str(st["received"])) == 15000 and Decimal(str(st["recovered"])) == 15000 and Decimal(str(st["balance"])) == 0
    tb = c.get("/ledger/trial-balance", headers=A).json(); bal = {r["account_code"]: Decimal(str(r["debit"])) - Decimal(str(r["credit"])) for r in tb["rows"]}
    assert bal["2200"] == 0 and tb["balanced"]                                   # لا رصيد سالب في الدفعات المقدمة
    # لا يُعكس ما استُرد، وقيدها لا يُعكس من الأستاذ مباشرة
    assert c.post(f"/advances/{a['id']}/reverse?reason=خطأ في التسجيل", headers=C).status_code == 409
    assert c.post(f"/ledger/entries/{a['entry_id']}/reverse?reason=خطأ في التسجيل", headers=A).status_code == 409
    assert c.get(f"/contracts/{k['id']}", headers=A).json()["advance_balance"] == 0

def test_advance_reverse_and_approval_guard(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, cl, val=1000000)
    a = c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 50000}, headers=C).json()
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-01", "gross": 100000}, headers=C).json()       # يحجز 10000
    assert c.post(f"/advances/{a['id']}/reverse?reason=x", headers=C).status_code == 422                                  # سبب قصير
    assert c.post(f"/advances/{a['id']}/reverse?reason=تسجيل بالخطأ", headers=C).status_code == 409                      # محجوز لمستخلص معلّق
    assert c.post(f"/invoices/{i['id']}/reject", json={"note": "خطأ"}, headers=C).status_code == 200
    assert c.post(f"/advances/{a['id']}/reverse?reason=تسجيل بالخطأ", headers=C).status_code == 200
    assert c.post(f"/advances/{a['id']}/reverse?reason=مرة ثانية", headers=C).status_code == 409
    tb = c.get("/ledger/trial-balance", headers=A).json(); bal = {x["account_code"]: Decimal(str(x["debit"])) - Decimal(str(x["credit"])) for x in tb["rows"]}
    assert bal.get("2200", 0) == 0 and bal.get("1100", 0) == 0 and tb["balanced"]
    assert Decimal(str(c.get(f"/contracts/{k['id']}/advances", headers=A).json()["summary"]["balance"])) == 0
    # مستخلص جديد بعد العكس: لا استرداد
    assert Decimal(str(c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-11-02", "gross": 100000}, headers=C).json()["advance"])) == 0

def test_subcontractor_advance_posts_to_1410(env):
    c, login = env; A, C, E, pr, cl, sb = mk(c, login)
    k = contract(c, A, pr, sb, kind="subcontractor", code="S9", val=500000)
    assert c.post(f"/contracts/{k['id']}/advances", json={"date": "2026-10-01", "amount": 30000}, headers=C).status_code == 201
    tb = c.get("/ledger/trial-balance", headers=A).json(); bal = {x["account_code"]: Decimal(str(x["debit"])) - Decimal(str(x["credit"])) for x in tb["rows"]}
    assert bal["1410"] == 30000 and bal["1100"] == -30000
