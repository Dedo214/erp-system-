import io
from decimal import Decimal
D = lambda x: Decimal(str(x))

def setup(env):
    c, login = env
    A, C, S = login("admin1"), login("acct1"), login("store1")
    for code, name, basic, al in (("E1", "أحمد", 10000, 2000), ("E2", "منى", 6000, 1000)):
        r = c.post("/employees", json={"code": code, "name": name, "basic": basic, "allowances": al, "national_id": "29001010101010"}, headers=C)
        assert r.status_code == 201, r.text
    return c, A, C, S

def test_employee_rules_and_salary_privacy(env):
    c, A, C, S = setup(env)
    assert c.post("/employees", json={"code": "E1", "name": "x"}, headers=C).status_code == 409
    assert c.post("/employees", json={"code": "E9", "name": "x", "national_id": "123"}, headers=C).status_code == 422
    assert c.get("/employees", headers=S).status_code == 403
    rows = c.get("/employees", headers=C).json(); assert "basic" in rows[0]
    login = env[1]
    # مهندس الموقع يرى الموظفين دون الأجور
    from app.db import SessionLocal
    from app.models import User, Role
    from app.security import hash_password
    from sqlalchemy import select
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    E = login("eng1"); r = c.get("/employees", headers=E).json()
    assert "basic" not in r[0] and "national_id" not in r[0]

def test_salary_change_needs_reason_and_version(env):
    c, A, C, S = setup(env)
    e = c.get("/employees", headers=C).json()[0]
    assert c.patch(f"/employees/{e['id']}", json={"version": e["version"], "basic": 11000}, headers=C).status_code == 422
    ok = c.patch(f"/employees/{e['id']}", json={"version": e["version"], "basic": 11000, "reason": "ترقية"}, headers=C); assert ok.status_code == 200
    assert c.patch(f"/employees/{e['id']}", json={"version": e["version"], "name": "y"}, headers=C).status_code == 409

def test_attendance_import_idempotent_and_rejects(env):
    c, A, C, S = setup(env)
    rows = [{"employee_code": "E1", "date": "2026-10-01", "status": "absent"}, {"employee_code": "E1", "date": "2026-10-02", "status": "present", "hours": 8, "overtime_hours": 2},
            {"employee_code": "ZZ", "date": "2026-10-02", "status": "present"}, {"employee_code": "E2", "date": "2026-10-02", "status": "weird"}]
    r = c.post("/attendance/import", json={"rows": rows}, headers=C); assert r.status_code == 201
    j = r.json(); assert j["new"] == 2 and j["rejected"] == 2
    assert c.post("/attendance/import", json={"rows": rows}, headers=C).status_code == 409      # نفس الدفعة
    rows2 = [{"employee_code": "E1", "date": "2026-10-01", "status": "present", "hours": 8}]
    j = c.post("/attendance/import", json={"rows": rows2}, headers=C).json(); assert j["updated"] == 1 and j["new"] == 0   # لا تكرار لليوم
    s = c.get("/attendance/summary?month=2026-10", headers=C).json()["E1"]; assert s["present"] == 2 and s["absent"] == 0
    assert c.post("/attendance/import", json={"rows": rows2}, headers=S).status_code == 403

def test_attendance_csv_file(env):
    c, A, C, S = setup(env)
    csvb = "employee_code,date,status,hours,overtime_hours\nE1,2026-10-05,absent,0,0\nE2,2026-10-05,present,8,1\nbad,row\n".encode()
    r = c.post("/attendance/import-file", files={"file": ("a.csv", csvb)}, headers=C); assert r.status_code == 201, r.text
    assert r.json()["new"] == 2 and r.json()["rejected"] >= 1
    assert c.post("/attendance/import-file", files={"file": ("a.exe", b"x")}, headers=C).status_code == 415

def test_payroll_calculation_exact(env):
    c, A, C, S = setup(env)
    run = c.post("/payroll/runs", json={"month": "2026-10"}, headers=C).json()
    l = next(x for x in run["lines"] if x["code"] == "E1")
    assert D(l["gross"]) == 12000 and D(l["emp_ins"]) == 1100 and D(l["er_ins"]) == D("1875") and D(l["tax"]) == D("992.50") and D(l["net"]) == D("9907.50")

def test_payroll_flow_posting_and_rbac(env):
    c, A, C, S = setup(env)
    c.post("/attendance/import", json={"rows": [{"employee_code": "E1", "date": "2026-10-03", "status": "absent"}]}, headers=C)
    e1 = c.get("/employees", headers=C).json()[0]["id"]
    c.post(f"/employees/{e1}/loans", json={"amount": 3000, "monthly": 1000}, headers=C)
    run = c.post("/payroll/runs", json={"month": "2026-10"}, headers=C).json()
    assert c.post("/payroll/runs", json={"month": "2026-10"}, headers=C).status_code == 409
    l = next(x for x in run["lines"] if x["code"] == "E1")
    assert D(l["absent_days"]) == 1 and D(l["absence_ded"]) == 400 and D(l["loan"]) == 1000
    p = c.patch(f"/payroll/runs/{run['id']}/lines/{l['id']}", json={"bonus": 500, "penalty": 100, "reason": "مكافأة"}, headers=C); assert p.status_code == 200
    assert c.post(f"/payroll/runs/{run['id']}/approve", headers=C).status_code == 403        # لا يملك الاعتماد
    assert c.post(f"/payroll/runs/{run['id']}/pay", json={"date": "2026-11-01"}, headers=A).status_code == 409   # قبل الاعتماد
    ap = c.post(f"/payroll/runs/{run['id']}/approve", headers=A); assert ap.status_code == 200, ap.text
    assert c.patch(f"/payroll/runs/{run['id']}/lines/{l['id']}", json={"bonus": 1, "reason": "تعديل"}, headers=C).status_code == 409
    tb = c.get("/ledger/trial-balance", headers=A).json(); assert tb["balanced"]
    bal = {r["account_code"]: D(r["debit"]) - D(r["credit"]) for r in tb["rows"]}
    t = ap.json()["totals"]
    assert bal["5200"] == D(t["gross"]) + D(t["er_ins"]) - D(t["penalty"]) and bal["2500"] == -D(t["net"]) and bal["1400"] == -1000
    assert c.post(f"/payroll/runs/{run['id']}/pay", json={"date": "2026-11-01"}, headers=C).status_code == 403
    assert c.post(f"/payroll/runs/{run['id']}/pay", json={"date": "2026-11-01"}, headers=A).json()["status"] == "paid"
    bal = {r["account_code"]: D(r["debit"]) - D(r["credit"]) for r in c.get("/ledger/trial-balance", headers=A).json()["rows"]}
    assert bal["2500"] == 0 and bal["1100"] == -D(t["net"])
    # رصيد السلفة تحرك
    run2 = c.post("/payroll/runs", json={"month": "2026-11"}, headers=C).json()
    assert D(next(x for x in run2["lines"] if x["code"] == "E1")["loan"]) == 1000

def test_settings_change_audited_and_applied(env):
    c, A, C, S = setup(env)
    assert c.put("/payroll/settings", json={"values": {"ins_max": 20000}, "reason": "تحديث"}, headers=C).status_code == 403
    assert c.put("/payroll/settings", json={"values": {"bogus": 1}, "reason": "تحديث"}, headers=A).status_code == 422
    assert c.put("/payroll/settings", json={"values": {"ins_emp_pct": 0}, "reason": "اختبار"}, headers=A).status_code == 200
    run = c.post("/payroll/runs", json={"month": "2026-10"}, headers=C).json()
    assert D(run["lines"][0]["emp_ins"]) == 0
    assert c.get("/audit/verify", headers=A).json()["ok"]
