from decimal import Decimal
D = lambda x: Decimal(str(x))

def base(env):
    c, login = env
    A, C, S = login("admin1"), login("acct1"), login("store1")
    pr = c.post("/projects", json={"code": "P1", "name": "م"}, headers=A).json()
    sup = c.post("/parties", json={"kind": "supplier", "name": "مورد"}, headers=A).json()
    it = c.post("/items", json={"code": "CEM", "name": "أسمنت", "unit": "طن", "min_stock": 5}, headers=S).json()
    return c, login, A, C, S, pr, sup, it

def make_po(c, C, A, pr, sup, it, qty=10, price=1000):
    o = c.post("/purchase-orders", json={"supplier_id": sup["id"], "project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": qty, "price": price}]}, headers=C)
    assert o.status_code == 201, o.text; o = o.json()
    assert c.post(f"/purchase-orders/{o['id']}/approve", headers=A).status_code == 200
    return o

def bal(c, A):
    return {r["account_code"]: D(r["debit"]) - D(r["credit"]) for r in c.get("/ledger/trial-balance", headers=A).json()["rows"]}

def test_pr_flow_and_rbac(env):
    c, login, A, C, S, pr, sup, it = base(env)
    r = c.post("/purchase-requests", json={"project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 20}]}, headers=S).json()
    assert c.post(f"/purchase-requests/{r['id']}/decide", json={"approve": True}, headers=S).status_code == 403
    assert c.post(f"/purchase-requests/{r['id']}/decide", json={"approve": False}, headers=A).status_code == 422
    assert c.post(f"/purchase-requests/{r['id']}/decide", json={"approve": True}, headers=A).json()["status"] == "approved"
    # أمر شراء من الطلب المعتمد فقط
    r2 = c.post("/purchase-requests", json={"project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 1}]}, headers=S).json()
    body = {"supplier_id": sup["id"], "project_id": pr["id"], "request_id": r2["id"], "lines": [{"item_id": it["id"], "qty": 1, "price": 1}]}
    assert c.post("/purchase-orders", json=body, headers=C).status_code == 422
    body["request_id"] = r["id"]; assert c.post("/purchase-orders", json=body, headers=C).status_code == 201
    assert c.post("/purchase-orders", json=body, headers=C).status_code == 422       # الطلب صار "ordered"
    assert c.post("/purchase-orders", json=body, headers=S).status_code == 403

def test_po_supplier_kind_and_self_approval(env):
    c, login, A, C, S, pr, sup, it = base(env)
    cl = c.post("/parties", json={"kind": "client", "name": "ع"}, headers=A).json()
    assert c.post("/purchase-orders", json={"supplier_id": cl["id"], "project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 1, "price": 1}]}, headers=C).status_code == 422
    o = c.post("/purchase-orders", json={"supplier_id": sup["id"], "project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 1, "price": 1}]}, headers=A).json()
    assert c.post(f"/purchase-orders/{o['id']}/approve", headers=A).status_code == 403     # المنشئ نفسه

def test_high_value_po_needs_special_permission(env):
    c, login, A, C, S, pr, sup, it = base(env)
    from app.db import SessionLocal
    from app.models import User, Role, Permission
    from app.security import hash_password
    from sqlalchemy import select
    with SessionLocal() as db:
        p = db.execute(select(Permission).where(Permission.code == "purchasing.po_approve")).scalar_one()
        db.add(User(username="mgr1", password_hash=hash_password("Passw0rd!long"), roles=[Role(name="mgr", perms=[p])])); db.commit()
    M = login("mgr1")
    big = c.post("/purchase-orders", json={"supplier_id": sup["id"], "project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 1000, "price": 600}]}, headers=C).json()
    assert c.post(f"/purchase-orders/{big['id']}/approve", headers=M).status_code == 403
    assert c.post(f"/purchase-orders/{big['id']}/approve", headers=A).status_code == 200

def test_receipt_posting_over_receipt_and_avg(env):
    c, login, A, C, S, pr, sup, it = base(env)
    o = make_po(c, C, A, pr, sup, it, 10, 1000); L = o["lines"][0]["id"]
    assert c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": L, "qty": 11}]}, headers=S).status_code == 422
    assert c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": L, "qty": 4}]}, headers=C).status_code == 403
    r = c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": L, "qty": 4}]}, headers=S); assert r.status_code == 201, r.text
    b = bal(c, A); assert b["1300"] == 4000 and b["2100"] == -4000
    o2 = make_po(c, C, A, pr, sup, it, 6, 1500); L2 = o2["lines"][0]["id"]
    c.post(f"/purchase-orders/{o2['id']}/receive", json={"date": "2026-11-02", "lines": [{"po_line_id": L2, "qty": 6}]}, headers=S)
    item = c.get("/items", headers=S).json()[0]
    assert D(item["qty"]) == 10 and D(item["value"]) == 13000 and D(item["avg_cost"]) == 1300      # متوسط مرجح
    assert c.post(f"/purchase-orders/{o2['id']}/cancel?reason=خطأ", headers=A).status_code == 409

def test_three_way_match_and_supplier_payment(env):
    c, login, A, C, S, pr, sup, it = base(env)
    o = make_po(c, C, A, pr, sup, it, 10, 1000); L = o["lines"][0]["id"]
    inv = lambda amt, ref="F1": c.post(f"/purchase-orders/{o['id']}/invoices", json={"ref": ref, "date": "2026-11-03", "amount": amt}, headers=C)
    assert inv(1000).status_code == 422                     # لا استلام بعد
    c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": L, "qty": 5}]}, headers=S)
    assert inv(5001).status_code == 422
    i = inv(5000); assert i.status_code == 201; i = i.json()
    assert inv(1, "F1").status_code in (409, 422)           # لا تكرار ولا تجاوز
    assert c.post(f"/supplier-invoices/{i['id']}/pay", json={"date": "2026-11-05", "amount": 6000}, headers=C).status_code == 422
    assert c.post(f"/supplier-invoices/{i['id']}/pay", json={"date": "2026-11-05", "amount": 5000}, headers=S).status_code == 403
    assert c.post(f"/supplier-invoices/{i['id']}/pay", json={"date": "2026-11-05", "amount": 5000}, headers=C).status_code == 201
    b = bal(c, A); assert b["2100"] == 0 and b["1100"] == -5000

def test_issue_no_negative_stock_and_cost(env):
    c, login, A, C, S, pr, sup, it = base(env)
    o = make_po(c, C, A, pr, sup, it, 10, 1000)
    c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": o["lines"][0]["id"], "qty": 10}]}, headers=S)
    body = {"item_id": it["id"], "project_id": pr["id"], "date": "2026-11-02"}
    assert c.post("/stock/issue", json={**body, "qty": 11}, headers=S).status_code == 422
    r = c.post("/stock/issue", json={**body, "qty": 4}, headers=S); assert r.status_code == 201 and D(r.json()["cost"]) == 4000
    b = bal(c, A); assert b["5100"] == 4000 and b["1300"] == 6000
    assert c.post("/stock/issue", json={**body, "qty": 6}, headers=S).status_code == 201     # آخر الرصيد صفر
    assert c.get("/items", headers=S).json()[0]["qty"] in ("0.000", 0, "0")
    assert c.post("/stock/issue", json={**body, "qty": 1}, headers=S).status_code == 422
    assert c.post("/stock/issue", json={**body, "qty": 1}, headers=C).status_code == 403

def test_stock_adjustment_and_reconciliation(env):
    c, login, A, C, S, pr, sup, it = base(env)
    o = make_po(c, C, A, pr, sup, it, 10, 1000)
    c.post(f"/purchase-orders/{o['id']}/receive", json={"date": "2026-11-01", "lines": [{"po_line_id": o["lines"][0]["id"], "qty": 10}]}, headers=S)
    adj = {"item_id": it["id"], "counted_qty": 8, "date": "2026-11-05", "reason": "عجز جرد"}
    assert c.post("/stock/adjust", json=adj, headers=S).status_code == 403       # أمين المخزن لا يسوي الجرد
    assert c.post("/stock/adjust", json={**adj, "reason": "x"}, headers=A).status_code == 422
    assert c.post("/stock/adjust", json=adj, headers=A).status_code == 201
    b = bal(c, A); assert b["5900"] == 2000 and b["1300"] == 8000
    rep = c.get("/reports/stock", headers=S).json()
    assert D(rep["stock_value"]) == 8000 and D(rep["difference"]) == 0
    assert rep["low_stock"] == []
    c.post("/stock/issue", json={"item_id": it["id"], "project_id": pr["id"], "date": "2026-11-06", "qty": 4}, headers=S)
    assert c.get("/reports/stock", headers=S).json()["low_stock"] == ["CEM"]     # 4 <= حد 5

def test_audit_still_valid(env):
    c, login, A, C, S, pr, sup, it = base(env)
    make_po(c, C, A, pr, sup, it)
    assert c.get("/audit/verify", headers=A).json()["ok"]
