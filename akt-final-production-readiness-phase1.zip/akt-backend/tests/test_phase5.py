from decimal import Decimal
D = lambda x: Decimal(str(x))

def scenario(env):
    c, login = env
    A, C, S = login("admin1"), login("acct1"), login("store1")
    pr = c.post("/projects", json={"code": "P1", "name": "مشروع 1", "budget": 100000}, headers=A).json()
    cl = c.post("/parties", json={"kind": "client", "name": "ع"}, headers=A).json()
    sup = c.post("/parties", json={"kind": "supplier", "name": "مورد", "terms_days": 0}, headers=A).json()
    k = c.post("/contracts", json={"code": "C1", "kind": "client", "project_id": pr["id"], "party_id": cl["id"], "title": "ع", "original_value": 1000000,
                                    "payment_days": 30}, headers=A).json()
    c.post(f"/contracts/{k['id']}/activate", headers=A)
    i = c.post(f"/contracts/{k['id']}/invoices", json={"date": "2026-08-01", "gross": 300000}, headers=C).json()
    c.post(f"/invoices/{i['id']}/review", json={}, headers=C); c.post(f"/invoices/{i['id']}/approve", json={}, headers=A)
    c.post(f"/invoices/{i['id']}/payments", json={"date": "2026-08-20", "amount": 100000}, headers=C)
    it = c.post("/items", json={"code": "CEM", "name": "أسمنت", "min_stock": 1}, headers=S).json()
    po = c.post("/purchase-orders", json={"supplier_id": sup["id"], "project_id": pr["id"], "lines": [{"item_id": it["id"], "qty": 100, "price": 500}]}, headers=C).json()
    c.post(f"/purchase-orders/{po['id']}/approve", headers=A)
    c.post(f"/purchase-orders/{po['id']}/receive", json={"date": "2026-09-01", "lines": [{"po_line_id": po["lines"][0]["id"], "qty": 40}]}, headers=S)
    c.post("/stock/issue", json={"item_id": it["id"], "project_id": pr["id"], "qty": 30, "date": "2026-09-05"}, headers=S)
    return c, A, C, S, pr

def test_dashboard_numbers(env):
    c, A, C, S, pr = scenario(env)
    d = c.get("/executive/dashboard?today=2026-11-09", headers=A).json()
    f = d["financial"]
    assert D(f["revenue"]) == 300000 and D(f["expenses"]) == 15000 and D(f["net_income"]) == 285000
    assert D(f["cash"]) == 100000 and D(f["receivables"]) == 200000
    assert D(f["inventory"]) == 5000 and D(f["payables"]) == 20000
    assert D(d["backlog"]) == 700000
    p = d["projects"][0]
    assert D(p["billed"]) == 300000 and D(p["collected"]) == 100000 and D(p["profit"]) == 285000 and D(p["margin_pct"]) == D("95.0")
    assert D(p["committed"]) == 30000          # 60 وحدة لم تُستلم × 500
    assert D(p["budget_used_pct"]) == D("45.0")   # (15000+30000)/100000

def test_aging_buckets(env):
    c, A, C, S, pr = scenario(env)
    ag = c.get("/executive/aging?today=2026-11-09", headers=A).json()
    # مستخلص 2026-08-01 + 30 يوم = 08-31 ← متأخر 70 يومًا ← شريحة 61-90
    assert D(ag["receivables"]["d61_90"]) > 0 and D(ag["receivables"]["current"]) == 0
    assert D(ag["receivables"]["d61_90"]) == D(c.get("/executive/dashboard?today=2026-11-09", headers=A).json()["financial"]["receivables"])

def test_rbac_and_csv_export_safety(env):
    c, A, C, S, pr = scenario(env)
    assert c.get("/executive/dashboard", headers=C).status_code == 403
    assert c.get("/executive/export/projects.csv", headers=C).status_code == 403
    assert c.get("/executive/dashboard").status_code == 401
    c.post("/projects", json={"code": "P2", "name": "=cmd|' /C calc'!A0"}, headers=A)
    r = c.get("/executive/export/projects.csv", headers=A)
    assert r.status_code == 200 and "'=cmd" in r.text and ",=cmd" not in r.text
    assert c.get("/audit/verify", headers=A).json()["ok"]

def test_alerts(env):
    c, A, C, S, pr = scenario(env)
    c.post("/guarantees", json={"kind": "performance", "project_id": pr["id"], "amount": 1000, "issue_date": "2026-01-01", "expiry_date": "2026-11-20", "ref": "G9"}, headers=C)
    c.post("/payroll/runs", json={"month": "2026-10"}, headers=C)
    types = {a["type"] for a in c.get("/executive/dashboard?today=2026-11-09", headers=A).json()["alerts"]}
    assert "guarantee_expiry" in types
