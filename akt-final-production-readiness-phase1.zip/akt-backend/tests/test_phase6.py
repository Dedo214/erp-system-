from decimal import Decimal
D = lambda x: Decimal(str(x))

def mkproj(c, login):
    A, C, S = login("admin1"), login("acct1"), login("store1")
    from app.db import SessionLocal
    from app.models import User, Role
    from app.security import hash_password
    from sqlalchemy import select
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    E = login("eng1")
    pr = c.post("/projects", json={"code": "P1", "name": "م"}, headers=A).json()
    return A, C, S, E, pr

def test_boq_flow_and_progress(env):
    c, login = env; A, C, S, E, pr = mkproj(c, login)
    u = f"/projects/{pr['id']}/boq"
    assert c.post(u, json={"description": "خرسانة", "unit": "م3", "qty": 100, "price": 1000, "section": "هيكل"}, headers=C).status_code == 403
    a = c.post(u, json={"description": "خرسانة", "unit": "م3", "qty": 100, "price": 1000, "section": "هيكل"}, headers=E).json()
    c.post(u, json={"description": "بياض", "unit": "م2", "qty": 200, "price": 50, "section": "تشطيب"}, headers=E)
    assert c.post(u, json={"description": "x", "qty": -1, "price": 1}, headers=E).status_code == 422
    r = c.patch(f"/boq/{a['id']}", json={"version": 1, "done": 50}, headers=E); assert r.status_code == 200
    assert c.patch(f"/boq/{a['id']}", json={"version": 1, "done": 60}, headers=E).status_code == 409
    assert c.patch(f"/boq/{a['id']}", json={"version": 2, "price": 1200}, headers=E).status_code == 422      # سبب إلزامي
    s = c.get(u, headers=C).json()                                                                            # المحاسب يرى فقط
    assert D(s["direct_cost"]) == 110000 and D(s["executed_value"]) == 50000 and D(s["progress_pct"]) == D("45.5")
    assert c.delete(f"/boq/{a['id']}?reason=خطأ", headers=E).status_code == 403
    assert c.delete(f"/boq/{a['id']}?reason=خطأ", headers=A).status_code == 409                               # له كمية منفذة

def test_boq_over_execution_flagged_not_hidden(env):
    c, login = env; A, C, S, E, pr = mkproj(c, login)
    u = f"/projects/{pr['id']}/boq"
    b = c.post(u, json={"description": "حديد", "qty": 10, "price": 100}, headers=E).json()
    c.patch(f"/boq/{b['id']}", json={"version": 1, "done": 12}, headers=E)
    s = c.get(u, headers=E).json(); assert s["over_executed"] == ["حديد"] and D(s["executed_value"]) == 1000
    assert any(a["type"] == "boq_over_executed" for a in c.get("/executive/dashboard", headers=A).json()["alerts"])

def test_boq_csv_import_reports_rejects(env):
    c, login = env; A, C, S, E, pr = mkproj(c, login)
    csvb = "section,description,unit,qty,price\nهيكل,خرسانة,م3,10,500\nهيكل,بند تالف,م3,abc,5\n,,,,\n".encode("utf-8")
    r = c.post(f"/projects/{pr['id']}/boq/import", files={"file": ("b.csv", csvb)}, headers=E); assert r.status_code == 201, r.text
    assert r.json()["added"] == 1 and r.json()["rejected"] >= 1
    assert c.post(f"/projects/{pr['id']}/boq/import", files={"file": ("b.exe", b"x")}, headers=E).status_code == 415

def test_schedule_rules(env):
    c, login = env; A, C, S, E, pr = mkproj(c, login)
    u = f"/projects/{pr['id']}/tasks"
    assert c.post(u, json={"name": "x", "start": "2026-02-01", "end": "2026-01-01"}, headers=E).status_code == 422
    a = c.post(u, json={"name": "حفر", "start": "2026-01-01", "end": "2026-01-10", "progress": 50}, headers=E).json()
    b = c.post(u, json={"name": "أساسات", "start": "2026-01-11", "end": "2026-01-30", "predecessor_id": a["id"]}, headers=E).json()
    assert c.patch(f"/tasks/{a['id']}", json={"version": 1, "predecessor_id": b["id"]}, headers=E).status_code == 422   # حلقة
    g = c.get(u + "?today=2026-02-15", headers=C).json()
    assert g["delayed"] == ["حفر", "أساسات"] and D(g["progress_pct"]) == D("16.7")   # (50*10)/(10+20)
    assert c.patch(f"/tasks/{a['id']}", json={"version": 1, "end": "2026-01-20"}, headers=E).status_code == 422          # سبب
    assert c.delete(f"/tasks/{a['id']}?reason=إلغاء", headers=E).status_code == 409                                       # b يعتمد عليها
    assert c.patch(f"/tasks/{b['id']}", json={"version": 1, "progress": 100}, headers=E).status_code == 200
    assert c.post(u, json={"name": "y", "start": "2026-01-01", "end": "2026-01-02"}, headers=S).status_code == 403

def test_legacy_import_brings_boq_and_tasks(env):
    c, login = env; A = login("admin1")
    snap = {"projects": [{"id": "p1", "name": "برج", "value": 100, "budget": 80, "start": "2026-01-01", "end": "2026-12-31", "status": "جارٍ"}],
            "boq": [{"id": "b1", "pid": "p1", "sec": "هيكل", "desc": "خرسانة", "unit": "م3", "qty": 10, "price": 500, "done": 4}, {"id": "b2", "pid": "zz", "desc": "يتيم", "qty": 1, "price": 1}],
            "tasks": [{"id": "t1", "pid": "p1", "name": "حفر", "start": "2026-01-01", "end": "2026-01-10", "progress": 30}, {"id": "t2", "pid": "p1", "name": "تالف", "start": "2026-02-01", "end": "2026-01-01"}]}
    r = c.post("/legacy/import", json=snap, headers=A).json()
    assert r["boq_items"] == 1 and r["tasks"] == 1 and r["skipped"] >= 2 and "boq" not in r["pending_modules"]
    r2 = c.post("/legacy/import", json=snap, headers=A).json(); assert r2["boq_items"] == 0 and r2["tasks"] == 0      # آمن للتكرار
    pid = c.get("/projects", headers=A).json()[0]["id"]
    assert D(c.get(f"/projects/{pid}/boq", headers=A).json()["direct_cost"]) == 5000
