from decimal import Decimal
D = lambda x: Decimal(str(x))

def users(c, login):
    from app.db import SessionLocal
    from app.models import User, Role
    from app.security import hash_password
    from sqlalchemy import select
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    return login("admin1"), login("acct1"), login("store1"), login("eng1")

def proj(c, A, code="P1"):
    return c.post("/projects", json={"code": code, "name": "م" + code}, headers=A).json()

def test_inspection_decision_creates_snag_atomically(env):
    c, login = env; A, C, S, E = users(c, login); p = proj(c, A)
    i = c.post("/inspections", json={"project_id": p["id"], "item": "حديد", "kind": "work", "date": "2026-11-01", "inspector": "استشاري"}, headers=E).json()
    assert i["ref"] == "IR-001"
    assert c.post(f"/inspections/{i['id']}/decide", json={"result": "rejected"}, headers=E).status_code == 422          # ملاحظة إلزامية
    assert c.post(f"/inspections/{i['id']}/decide", json={"result": "rejected", "note": "تخانة غير كافية"}, headers=C).status_code == 403
    r = c.post(f"/inspections/{i['id']}/decide", json={"result": "rejected", "note": "تخانة غير كافية", "due": "2026-11-20"}, headers=E).json()
    assert r["snag"]["severity"] == "high" and r["snag"]["ref"] == "NCR-001"
    assert c.post(f"/inspections/{i['id']}/decide", json={"result": "accepted"}, headers=E).status_code == 409          # مرة واحدة
    assert len(c.get("/snags?status=open", headers=C).json()) == 1

def test_snag_close_needs_note_and_version(env):
    c, login = env; A, C, S, E = users(c, login); p = proj(c, A)
    s = c.post("/snags", json={"project_id": p["id"], "location": "ممر", "description": "شرخ", "severity": "low", "due": "2020-01-01"}, headers=E).json()
    assert s["overdue"] is True
    assert c.post(f"/snags/{s['id']}/act", json={"version": 1, "action": "close", "note": "x"}, headers=E).status_code == 422
    assert c.post(f"/snags/{s['id']}/act", json={"version": 1, "action": "close", "note": "تم الإصلاح"}, headers=E).json()["status"] == "closed"
    assert c.post(f"/snags/{s['id']}/act", json={"version": 1, "action": "close", "note": "تم الإصلاح"}, headers=E).status_code == 409
    assert c.post(f"/snags/{s['id']}/act", json={"version": 2, "action": "reopen", "note": "عاد العيب"}, headers=E).json()["status"] == "open"

def finish_checks(c, h, E):
    for n in range(len(h["checklist"])): c.post(f"/handovers/{h['id']}/check", json={"index": n, "value": True}, headers=E)

def test_handover_rules(env):
    c, login = env; A, C, S, E = users(c, login); p = proj(c, A)
    s = c.post("/snags", json={"project_id": p["id"], "location": "x", "description": "عيب", "severity": "medium"}, headers=E).json()
    h = c.post("/handovers", json={"project_id": p["id"], "kind": "initial", "warranty_months": 12}, headers=E).json()
    assert c.post("/handovers", json={"project_id": p["id"], "kind": "initial"}, headers=E).status_code == 409
    assert c.post(f"/handovers/{h['id']}/complete", json={"date": "2026-11-01"}, headers=A).status_code == 422          # بنود ناقصة
    finish_checks(c, h, E)
    r = c.post(f"/handovers/{h['id']}/complete", json={"date": "2026-11-01"}, headers=A); assert r.status_code == 422 and "ملاحظات مفتوحة" in r.text
    c.post(f"/snags/{s['id']}/act", json={"version": 1, "action": "close", "note": "تم الإصلاح"}, headers=E)
    assert c.post(f"/handovers/{h['id']}/complete", json={"date": "2026-11-01"}, headers=E).status_code == 403          # المهندس لا يعتمد
    rr = c.post(f"/handovers/{h['id']}/complete", json={"date": "2026-11-01"}, headers=A); ok = rr.json(); assert ok["status"] == "done" and ok["warranty_end"] == "2027-11-01"
    assert c.post(f"/handovers/{h['id']}/check", json={"index": 0, "value": False}, headers=E).status_code == 409        # مقفل بعد الاعتماد

def test_final_handover_needs_initial_warranty_and_final_invoice(env):
    c, login = env; A, C, S, E = users(c, login); p = proj(c, A)
    cl = c.post("/parties", json={"kind": "client", "name": "ع"}, headers=A).json()
    k = c.post("/contracts", json={"code": "C1", "kind": "client", "project_id": p["id"], "party_id": cl["id"], "title": "ع", "original_value": 100000}, headers=A).json()
    c.post(f"/contracts/{k['id']}/activate", headers=A)
    fin = c.post("/handovers", json={"project_id": p["id"], "kind": "final"}, headers=E).json(); finish_checks(c, fin, E)
    assert "الابتدائي" in c.post(f"/handovers/{fin['id']}/complete", json={"date": "2027-01-01"}, headers=A).text
    ini = c.post("/handovers", json={"project_id": p["id"], "kind": "initial", "warranty_months": 12}, headers=E).json(); finish_checks(c, ini, E)
    c.post(f"/handovers/{ini['id']}/complete", json={"date": "2026-01-01"}, headers=A)
    r = c.post(f"/handovers/{fin['id']}/complete", json={"date": "2026-06-01"}, headers=A); assert r.status_code == 422
    assert "لم تنتهِ فترة الصيانة" in r.text and "مستخلص ختامي" in r.text
    r = c.post(f"/handovers/{fin['id']}/complete", json={"date": "2026-06-01", "override_reason": "اتفاق مع العميل"}, headers=A); assert r.status_code == 200   # المدير فقط
    assert [x for x in c.get("/projects", headers=A).json() if x["id"] == p["id"]][0]["status"] == "completed"

def test_tender_lifecycle_and_convert(env):
    c, login = env; A, C, S, E = users(c, login)
    cl = c.post("/parties", json={"kind": "client", "name": "ع"}, headers=A).json()
    t = c.post("/tenders", json={"name": "مبنى", "client_id": cl["id"], "value": 1000000, "cost": 850000, "due": "2026-11-12"}, headers=C).json()
    assert D(t["margin_pct"]) == D("15.0")
    assert c.post("/tenders", json={"name": "x", "client_id": "nope"}, headers=C).status_code == 422
    assert c.patch(f"/tenders/{t['id']}", json={"version": 1, "stage": "lost"}, headers=C).status_code == 422             # سبب الخسارة
    assert c.post(f"/tenders/{t['id']}/convert", json={"project_code": "P9", "contract_code": "C9"}, headers=A).status_code == 422   # ليس فائزًا
    assert c.patch(f"/tenders/{t['id']}", json={"version": 1, "stage": "submitted"}, headers=C).status_code == 200
    assert c.patch(f"/tenders/{t['id']}", json={"version": 2, "value": 900000}, headers=C).status_code == 422             # سبب بعد التقديم
    assert c.patch(f"/tenders/{t['id']}", json={"version": 2, "stage": "won"}, headers=C).status_code == 200
    assert c.post(f"/tenders/{t['id']}/convert", json={"project_code": "P9", "contract_code": "C9"}, headers=C).status_code == 403   # المحاسب لا يحوّل
    r = c.post(f"/tenders/{t['id']}/convert", json={"project_code": "P9", "contract_code": "C9"}, headers=A); assert r.status_code == 201, r.text
    assert c.post(f"/tenders/{t['id']}/convert", json={"project_code": "P8", "contract_code": "C8"}, headers=A).status_code == 409
    k = c.get("/contracts", headers=A).json()[0]; assert k["status"] == "draft" and D(k["original_value"]) == 1000000
    assert c.patch(f"/tenders/{t['id']}", json={"version": 4, "note": "x"}, headers=C).status_code == 409                  # تحوّل
    pr = [x for x in c.get("/projects", headers=A).json() if x["code"] == "P9"][0]; assert D(pr["budget"]) == 850000

def test_pipeline_and_alerts(env):
    c, login = env; A, C, S, E = users(c, login)
    c.post("/tenders", json={"name": "أ", "value": 1000, "cost": 800, "due": "2026-11-10"}, headers=C)
    t = c.post("/tenders", json={"name": "ب", "value": 2000, "cost": 1500}, headers=C).json()
    c.patch(f"/tenders/{t['id']}", json={"version": 1, "stage": "negotiation"}, headers=C)
    pl = c.get("/tenders/pipeline/summary", headers=C).json()
    assert D(pl["weighted_total"]) == 100 + 1200
    assert any(a["type"] in ("tender_due", "tender_due_missed") for a in c.get("/executive/dashboard?today=2026-11-09", headers=A).json()["alerts"])

def test_legacy_import_quality_and_tenders(env):
    c, login = env; A = login("admin1")
    snap = {"clients": [{"id": "c1", "name": "عميل"}], "projects": [{"id": "p1", "name": "برج", "value": 1, "budget": 1, "start": "2026-01-01", "end": "2026-12-31", "status": "جارٍ"}],
            "tenders": [{"id": "t1", "name": "عطاء", "cid": "c1", "type": "x", "due": "2026-12-01", "value": 100, "cost": 80, "stage": "فائزة"}, {"id": "t2", "name": "تالف", "stage": "غريب"}],
            "insp": [{"id": "i1", "pid": "p1", "item": "حديد", "kind": "تنفيذ", "date": "2026-10-01", "inspector": "س", "status": "مقبول"}],
            "snags": [{"id": "s1", "pid": "p1", "loc": "ممر", "desc": "شرخ", "severity": "عالية", "due": "2026-10-10", "status": "مفتوح"}],
            "handover": [{"id": "h1", "pid": "p1", "kind": "ابتدائي", "status": "تم", "date": "2026-10-01", "warranty": 12, "checks": {"0": True}},
                         {"id": "h2", "pid": "p1", "kind": "نهائي", "status": "جاري", "warranty": 0, "checks": {"0": True, "1": True}}]}
    r = c.post("/legacy/import", json=snap, headers=A).json()
    assert (r["tenders"], r["inspections"], r["snags"], r["handovers"]) == (1, 1, 1, 1)         # "تم" ببنود ناقصة لم يُستورد كمعتمد
    assert r["skipped"] >= 2 and not set(r["pending_modules"]) & {"tenders", "insp", "snags", "handover"}
    r2 = c.post("/legacy/import", json=snap, headers=A).json(); assert (r2["tenders"], r2["inspections"], r2["snags"], r2["handovers"]) == (0, 0, 0, 0)
    assert c.get("/tenders", headers=A).json()[0]["client_id"]
    assert c.get("/snags", headers=A).json()[0]["ref"] == "NCR-001"
