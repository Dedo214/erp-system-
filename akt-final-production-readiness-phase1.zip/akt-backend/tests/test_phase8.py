from decimal import Decimal
D = lambda x: Decimal(str(x))
from datetime import date, timedelta
TODAY = date.today().isoformat()
def ago(n): return (date.today() - timedelta(days=n)).isoformat()
def ahead(n): return (date.today() + timedelta(days=n)).isoformat()

def setup(c, login):
    from app.db import SessionLocal
    from app.models import User, Role
    from app.security import hash_password
    from sqlalchemy import select
    with SessionLocal() as db:
        db.add(User(username="eng1", password_hash=hash_password("Passw0rd!long"), roles=[db.execute(select(Role).where(Role.name == "site_engineer")).scalar_one()])); db.commit()
    A, C, S, E = login("admin1"), login("acct1"), login("store1"), login("eng1")
    return A, C, S, E, c.post("/projects", json={"code": "P1", "name": "م"}, headers=A).json()

def bal(c, A): return {r["account_code"]: D(r["debit"]) - D(r["credit"]) for r in c.get("/ledger/trial-balance", headers=A).json()["rows"]}

def test_daily_report_rules(env):
    c, login = env; A, C, S, E, p = setup(c, login)
    b = {"project_id": p["id"], "date": ago(1), "work": "صب سقف", "workers_count": 30}
    assert c.post("/daily-reports", json={**b, "date": ahead(2)}, headers=E).status_code == 422
    r = c.post("/daily-reports", json=b, headers=E); assert r.status_code == 201
    assert c.post("/daily-reports", json=b, headers=E).status_code == 409
    assert c.post("/daily-reports", json=b, headers=S).status_code == 403
    rid = r.json()["id"]
    assert c.patch(f"/daily-reports/{rid}", json={"version": 1, "work": "عدّلت"}, headers=E).status_code == 422       # سبب إلزامي
    assert c.patch(f"/daily-reports/{rid}", json={"version": 1, "work": "عدّلت", "reason": "تصحيح"}, headers=E).status_code == 200
    assert c.patch(f"/daily-reports/{rid}", json={"version": 1, "work": "xyz1", "reason": "تصحيح"}, headers=E).status_code == 409

def test_safety_documents_risks_correspondence(env):
    c, login = env; A, C, S, E, p = setup(c, login)
    s = c.post("/safety", json={"project_id": p["id"], "date": ago(2), "kind": "accident", "severity": "high", "description": "سقوط مواد"}, headers=E).json()
    assert c.post("/safety", json={"project_id": p["id"], "date": ago(2), "kind": "x", "severity": "high", "description": "abc"}, headers=E).status_code == 422
    assert c.post(f"/safety/{s['id']}/close", json={"version": 1, "action": "x"}, headers=E).status_code == 422
    assert c.post(f"/safety/{s['id']}/close", json={"version": 1, "action": "تركيب شبكة حماية"}, headers=E).json()["status"] == "closed"
    d = c.post("/documents", json={"project_id": p["id"], "doc_type": "ترخيص", "name": "ترخيص بناء", "issue_date": ago(300), "expiry_date": ahead(10)}, headers=E).json()
    assert d["days_to_expiry"] == 10
    assert c.post("/documents", json={"doc_type": "x", "name": "y", "issue_date": TODAY, "expiry_date": ago(5)}, headers=E).status_code == 422
    assert c.delete(f"/documents/{d['id']}?reason=خطأ", headers=E).status_code == 403
    r = c.post("/risks", json={"project_id": p["id"], "description": "ارتفاع الأسعار", "prob": 4, "impact": 5}, headers=E).json()
    assert r["score"] == 20 and r["level"] == "high"
    assert c.post("/risks", json={"project_id": p["id"], "description": "ارتفاع", "prob": 6, "impact": 1}, headers=E).status_code == 422
    k = c.post("/correspondence", json={"direction": "in", "ref_no": "و-1", "date": ago(10), "party": "استشاري", "subject": "ملاحظات", "due": ago(3)}, headers=E).json()
    assert k["overdue"] is True
    assert c.post("/correspondence", json={"direction": "in", "ref_no": "و-1", "date": TODAY, "party": "س", "subject": "ص"}, headers=E).status_code == 409
    types = {a["type"] for a in c.get("/executive/dashboard", headers=A).json()["alerts"]}
    assert {"document_expiry", "risk_high", "correspondence_overdue"} <= types and "safety_open_high" not in types

def test_equipment_usage_and_maintenance(env):
    c, login = env; A, C, S, E, p = setup(c, login)
    assert c.post("/equipment", json={"name": "ونش", "daily_rate": 6000}, headers=E).status_code == 403
    eq = c.post("/equipment", json={"name": "ونش", "daily_rate": 6000, "maint_interval_days": 90, "last_maint": ago(100)}, headers=A).json()
    assert eq["maint_overdue"] is True
    u = c.post("/equipment/usage", json={"equipment_id": eq["id"], "project_id": p["id"], "date": ago(1), "days": 3}, headers=E); assert u.status_code == 201 and D(u.json()["cost"]) == 18000
    assert c.post("/equipment/usage", json={"equipment_id": eq["id"], "project_id": p["id"], "date": ago(1), "days": 1}, headers=E).status_code == 409
    c.patch(f"/equipment/{eq['id']}", json={"version": 1, "status": "maintenance"}, headers=A)
    assert c.post("/equipment/usage", json={"equipment_id": eq["id"], "project_id": p["id"], "date": ago(2), "days": 1}, headers=E).status_code == 422
    m = c.post(f"/equipment/{eq['id']}/maintenance", json={"date": ago(1), "note": "صيانة دورية"}, headers=A).json(); assert m["maint_overdue"] is False and m["status"] == "working"
    assert D(c.get("/reports/equipment-cost", headers=C).json()["total"]) == 18000

def test_labor_wage_payment_posts_per_project_and_blocks_double_count(env):
    c, login = env; A, C, S, E, p = setup(c, login)
    p2 = c.post("/projects", json={"code": "P2", "name": "م2"}, headers=A).json()
    w = c.post("/workers", json={"name": "محمود", "trade": "نجار", "daily_rate": 550}, headers=A).json()
    assert c.post("/workers", json={"name": "x", "daily_rate": 1}, headers=E).status_code == 403
    d = lambda pid, day, n=1: c.post("/labor/days", json={"worker_id": w["id"], "project_id": pid, "date": ago(day), "days": n}, headers=E)
    assert d(p["id"], 3).status_code == 201 and d(p["id"], 2, 1.5).status_code == 201 and d(p2["id"], 1).status_code == 201
    assert d(p2["id"], 3).status_code == 409                       # نفس اليوم على مشروع آخر
    assert d(p["id"], 5, 3).status_code == 422                     # أكثر من يومين
    c.patch(f"/workers/{w['id']}", json={"version": 1, "daily_rate": 700, "reason": "زيادة"}, headers=A)   # لا يغيّر الأيام المسجلة
    assert D(c.get("/workers", headers=C).json()[0]["unpaid"]) == 1925
    assert c.post("/labor/pay", json={"date": TODAY, "up_to": TODAY}, headers=E).status_code == 403
    r = c.post("/labor/pay", json={"date": TODAY, "up_to": TODAY}, headers=C); assert r.status_code == 201, r.text
    assert D(r.json()["total"]) == 550 * 1 + 550 * 1.5 + 550 * 1 and r.json()["days_paid"] == 3 and len(r.json()["entries"]) == 2
    b = bal(c, A); assert b["5200"] == D(r.json()["total"]) and b["1110"] == -D(r.json()["total"])
    assert c.post("/labor/pay", json={"date": TODAY, "up_to": TODAY}, headers=C).status_code == 422     # لا شيء متبقٍ
    assert c.get("/ledger/trial-balance", headers=A).json()["balanced"]

def test_custody_lifecycle(env):
    c, login = env; A, C, S, E, p = setup(c, login)
    cu = c.post("/custodies", json={"person": "أحمد", "project_id": p["id"], "amount": 50000, "date": ago(5)}, headers=C).json()
    assert c.post("/custodies", json={"person": "x", "amount": 1, "date": TODAY}, headers=S).status_code == 403
    ex = lambda amt, cat="materials", day=3: c.post(f"/custodies/{cu['id']}/expenses", json={"date": ago(day), "category": cat, "description": "مستلزمات", "amount": amt}, headers=E)
    assert ex(21000).status_code == 201
    assert ex(30000).status_code == 422                          # يتجاوز
    assert ex(100, "x").status_code == 422 and ex(100, "materials", 9).status_code == 422
    b = bal(c, A); assert b["1400"] == 29000 and b["5100"] == 21000
    assert c.post(f"/custodies/{cu['id']}/settle", json={"date": TODAY}, headers=E).status_code == 403
    r = c.post(f"/custodies/{cu['id']}/settle", json={"date": TODAY}, headers=C).json(); assert r["settled"] and D(r["remaining"]) == 29000
    b = bal(c, A); assert b["1400"] == 0 and b["1110"] == -21000
    assert ex(1).status_code == 409 and c.post(f"/custodies/{cu['id']}/settle", json={"date": TODAY}, headers=C).status_code == 409
    assert c.get("/ledger/trial-balance", headers=A).json()["balanced"]

def test_legacy_import_site_modules_and_not_migrated_report(env):
    c, login = env; A = login("admin1")
    snap = {"projects": [{"id": "p1", "name": "برج", "value": 1, "budget": 1, "start": "2026-01-01", "end": "2026-12-31", "status": "جارٍ"}],
            "subs": [{"id": "u1", "name": "الفنار", "trade": "كهرباء"}],
            "subc": [{"id": "c1", "subid": "u1", "pid": "p1", "desc": "كهرباء", "value": 3400000, "retPct": 5, "paid": 800000}],
            "reports": [{"id": "d1", "pid": "p1", "date": "2026-11-07", "weather": "مشمس", "workers": 46, "work": "صب سقف", "issues": ""}],
            "safety": [{"id": "k1", "pid": "p1", "date": "2026-10-19", "kind": "تفتيش", "severity": "منخفضة", "desc": "تفتيش سقالات", "status": "مغلق"}],
            "docs": [{"id": "m1", "pid": "p1", "type": "عقد", "name": "عقد", "issue": "2026-01-02", "expiry": "2027-07-06"}],
            "risks": [{"id": "r1", "pid": "p1", "desc": "ارتفاع الحديد", "prob": 4, "impact": 4, "owner": "م", "mitigation": "تعاقد", "status": "مفتوح"}, {"id": "r2", "pid": "p1", "desc": "تالف", "prob": 9, "impact": 1}],
            "corr": [{"id": "x1", "dir": "وارد", "no": "و-212", "date": "2026-10-27", "party": "استشاري", "pid": "p1", "subject": "ملاحظات", "due": "2026-11-04", "status": "مفتوح"}],
            "equip": [{"id": "e1", "name": "ونش برجي", "type": "رفع", "rate": 6000, "status": "يعمل", "interval": 90, "lastMaint": "2026-07-31"}],
            "eqUse": [{"id": "q1", "eid": "e1", "pid": "p1", "date": "2026-09-09", "days": 45}],
            "workers": [{"id": "w1", "name": "محمود", "trade": "نجار", "daily": 550}],
            "att": [{"id": "a1", "wid": "w1", "pid": "p1", "date": "2026-11-02", "days": 1, "paid": False}, {"id": "a2", "wid": "w1", "pid": "p1", "date": "2026-11-03", "days": 1, "paid": True}],
            "invoices": [{"id": "i1", "no": 1}], "emps": [{"id": "z1", "name": "أحمد"}], "txs": [{"id": "t"}]}
    r = c.post("/legacy/import", json=snap, headers=A).json()
    got = {k: r[k] for k in ("daily_reports", "safety", "documents", "risks", "correspondence", "equipment", "equipment_usage", "workers", "labor_days", "sub_contracts")}
    assert got == {"daily_reports": 1, "safety": 1, "documents": 1, "risks": 1, "correspondence": 1, "equipment": 1, "equipment_usage": 1, "workers": 1, "labor_days": 2, "sub_contracts": 1}
    nm = {x["module"] for x in r["not_migrated"]}; assert {"invoices", "emps", "txs"} <= nm and r["pending_modules"] == []
    assert [x for x in r["not_migrated"] if x["module"] == "emps"][0]["reason"].startswith("يلزم رقم الموظف")
    r2 = c.post("/legacy/import", json=snap, headers=A).json(); assert all(r2[k] == 0 for k in got)       # آمن للتكرار
    ks = c.get("/contracts", headers=A).json(); assert ks[0]["status"] == "draft" and D(ks[0]["original_value"]) == 3400000
    assert D(c.get("/workers", headers=A).json()[0]["unpaid"]) == 550          # المسدد قديمًا لا يُدفع مرة ثانية
