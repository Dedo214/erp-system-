import io, os, openpyxl

def test_files_lifecycle(env):
    c, login = env; A, S = login("admin1"), login("store1")
    pid = c.post("/projects", json={"code": "P1", "name": "م"}, headers=A).json()["id"]
    pdf = b"%PDF-1.4 test"
    r = c.post(f"/files?entity=project&entity_id={pid}", files={"file": ("خطة.pdf", pdf, "application/pdf")}, headers=S); assert r.status_code == 201, r.text
    fid = r.json()["id"]
    assert c.post(f"/files?entity=project&entity_id={pid}", files={"file": ("x.exe", b"MZ", "application/octet-stream")}, headers=S).status_code == 415
    assert c.post(f"/files?entity=project&entity_id={pid}", files={"file": ("x.pdf", b"not pdf", "application/pdf")}, headers=S).status_code == 415
    L = c.get(f"/files?entity=project&entity_id={pid}", headers=S).json(); assert len(L) == 1 and L[0]["id"] == fid
    d = c.get(f"/files/{fid}/download", headers=S); assert d.status_code == 200 and d.content == pdf
    assert c.delete(f"/files/{fid}?reason=خطأ", headers=S).status_code == 403            # أمين المخزن لا يحذف
    assert c.delete(f"/files/{fid}?reason=x", headers=A).status_code == 422             # سبب قصير
    # تلف الملف يُكتشف
    from app.db import SessionLocal; from app.models import Attachment
    with SessionLocal() as db: path = db.get(Attachment, fid).path
    open(path, "wb").write(b"%PDF-tampered")
    assert c.get(f"/files/{fid}/download", headers=S).status_code == 500
    assert c.delete(f"/files/{fid}?reason=خطأ في الرفع", headers=A).status_code == 200
    assert not os.path.exists(path)
    assert c.get(f"/files/{fid}/download", headers=A).status_code == 404
    acts = [a["action"] for a in c.get("/audit?limit=50", headers=A).json()]
    assert {"files.upload", "files.download", "files.delete"} <= set(acts)

def test_shared_file_not_removed_when_other_attachment_uses_it(env):
    c, login = env; A = login("admin1")
    pid = c.post("/projects", json={"code": "P1", "name": "م"}, headers=A).json()["id"]
    f = {"file": ("a.txt", b"same", "text/plain")}
    a = c.post(f"/files?entity=project&entity_id={pid}", files=f, headers=A).json()["id"]
    b = c.post(f"/files?entity=party&entity_id=z", files={"file": ("b.txt", b"same", "text/plain")}, headers=A).json()["id"]
    from app.db import SessionLocal; from app.models import Attachment
    with SessionLocal() as db: path = db.get(Attachment, a).path
    assert c.delete(f"/files/{a}?reason=تجربة حذف", headers=A).status_code == 200
    assert os.path.exists(path)                                  # ما زال مستخدمًا
    assert c.get(f"/files/{b}/download", headers=A).content == b"same"

def test_export(env):
    c, login = env; A, S = login("admin1"), login("store1")
    body = {"title": "تقرير/اختبار", "columns": ["الاسم", "القيمة"], "rows": [["=HYPERLINK(\"http://x\")", 5], ["مشروع", 1234.5], [None, True]]}
    r = c.post("/export/xlsx", json=body, headers=S); assert r.status_code == 200
    ws = openpyxl.load_workbook(io.BytesIO(r.content)).active
    assert ws["A2"].value.startswith("'=") and ws["B3"].value == 1234.5 and ws["B4"].value == "نعم"   # لا معادلات منفَّذة
    assert ws.sheet_view.rightToLeft
    r = c.post("/export/pdf", json=body, headers=S); assert r.status_code == 200 and r.content.startswith(b"%PDF") and len(r.content) > 1500
    assert c.post("/export/docx", json=body, headers=A).status_code == 404
    assert c.post("/export/xlsx", json={**body, "columns": []}, headers=A).status_code == 422
    assert c.post("/export/xlsx", json=body).status_code in (401, 403)
    assert [a for a in c.get("/audit?limit=50", headers=A).json() if a["action"] == "export.pdf"]

def test_general_ledger_window_and_paging(env):
    c, login = env; A = login("admin1")
    for i in range(7):
        r = c.post("/ledger/entries", json={"date": f"2026-10-{i+1:02}", "description": f"e{i}", "lines": [{"account_code": "5100", "debit": 100 + i}, {"account_code": "1100", "credit": 100 + i}]}, headers=A)
        assert r.status_code == 201, r.text
    full = c.get("/reports/general-ledger/5100", headers=A).json()
    assert full["total_rows"] == 7 and not full["truncated"] and float(full["closing"]) == sum(100 + i for i in range(7))
    bals = [float(r["balance"]) for r in full["rows"]]; assert bals == sorted(bals) and bals[-1] == float(full["closing"])
    p2 = c.get("/reports/general-ledger/5100?limit=3&offset=3", headers=A).json()
    assert p2["returned"] == 3 and p2["truncated"] and float(p2["closing"]) == float(full["closing"])
    assert [r["balance"] for r in p2["rows"]] == [r["balance"] for r in full["rows"][3:6]]       # الرصيد الجاري متسق عبر الصفحات
    f = c.get("/reports/general-ledger/5100?frm=2026-10-04", headers=A).json()
    assert float(f["opening"]) == 100 + 101 + 102 and float(f["closing"]) == float(full["closing"]) and f["total_rows"] == 4

def test_security_hardening(env):
    c, login = env
    assert c.get("/docs").status_code == 404 and c.get("/openapi.json").status_code == 404       # الوثائق مغلقة افتراضيًا
    r = c.get("/")
    assert "script-src 'self';" in r.headers["content-security-policy"] and "unsafe-inline" not in r.headers["content-security-policy"].split("style-src")[0]
    assert "<script>" not in r.text and "/app.js" in r.text
    js = c.get("/app.js"); assert js.status_code == 200 and "javascript" in js.headers["content-type"]
    for h in ("strict-transport-security", "referrer-policy", "permissions-policy", "x-frame-options"):
        assert h in r.headers, h
    # كلمة مرور ضعيفة
    A = login("admin1")
    assert c.post("/auth/change-password", json={"old_password": "Passw0rd!long", "new_password": "1234567890"}, headers=A).status_code == 422

def test_ip_failure_throttle(env):
    c, login = env
    from app.config import settings
    old = settings.max_ip_failures; settings.max_ip_failures = 4
    try:
        codes = [c.post("/auth/login", json={"username": f"nobody{i}", "password": "x"}).status_code for i in range(6)]
        assert codes[:4] == [401] * 4 and codes[4:] == [429, 429]            # الرش بأسماء مختلفة يُوقَف
    finally: settings.max_ip_failures = old


def test_export_english_ltr(env):
    c, login = env; admin_h = login("admin1"); client = c
    body = {"title": "Users", "columns": ["Name", "Status"], "rows": [["A", True]], "rtl": False, "lang": "en"}
    r = client.post("/export/xlsx", json=body, headers=admin_h)
    assert r.status_code == 200
    ws = openpyxl.load_workbook(io.BytesIO(r.content)).active
    assert ws.sheet_view.rightToLeft is False and ws["B2"].value == "Yes"
    assert client.post("/export/pdf", json=body, headers=admin_h).content[:4] == b"%PDF"
    assert client.post("/export/xlsx", json={**body, "lang": "fr"}, headers=admin_h).status_code == 422
