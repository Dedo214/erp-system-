const {chromium}=require('playwright');
const URL='http://localhost:8765/';
(async()=>{
  const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1300,height:850},deviceScaleFactor:1});
  const page=await ctx.newPage();const errs=[];
  page.on('pageerror',e=>errs.push('PAGEERR '+e.message));
  page.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text())});
  page.on('dialog',d=>d.accept());
  const F=(l)=>page.locator(`xpath=//div[@id='md']//label[starts-with(normalize-space(.),'${l}')]/following-sibling::*[1]`);
  const login=async(u,p='Passw0rd!long')=>{await page.fill('#lu',u);await page.fill('#lp',p);await page.click('#lf button')};
  const nav=async k=>{await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(500)};
  const ok=async()=>{await page.click('#md form button.btn');await page.waitForSelector('#ov.hide',{state:'attached',timeout:8000});await page.waitForTimeout(500)};
  const step=(m)=>console.log('✔',m);
  await page.goto(URL);
  await login('boss','wrong');await page.waitForTimeout(600);
  console.log('wrong-login msg:',await page.textContent('#le'));
  await login('boss');await page.waitForSelector('#app:not(.hide)');step('login admin');
  // مشروع
  await nav('projects');await page.click('text=+ مشروع');await F('الكود').fill('P1');await F('الاسم').fill('برج النخيل');await F('قيمة العقد').fill('5000000');await F('الموازنة').fill('3000000');await ok();
  console.log('projects table has P1:',(await page.textContent('#main')).includes('برج النخيل'));
  // أطراف
  await nav('parties');await page.click('text=+ طرف');await F('النوع').selectOption('client');await F('الاسم').fill('شركة العميل');await ok();
  await page.click('text=+ طرف');await F('النوع').selectOption('supplier');await F('الاسم').fill('مورد الأسمنت');await ok();
  // عقد
  await nav('contracts');await page.click('text=+ عقد');await F('الكود').fill('C1');await F('النوع').selectOption('client');
  await F('المشروع').selectOption({index:0});await F('الطرف الثاني').selectOption({label:'عميل: شركة العميل'});await F('العنوان').fill('عقد التشطيبات');await F('القيمة').fill('1000000');
  await F('دفعة مقدمة').fill('10');await F('ضمان أعمال').fill('5');await F('ضريبة خصم').fill('3');await ok();
  await page.click('button:has-text("تفعيل")');await ok();step('contract created+activated');
  // خطأ يجب أن يظهر: كود مكرر
  await page.click('text=+ عقد');await F('الكود').fill('C1');await F('النوع').selectOption('client');await F('المشروع').selectOption({index:0});await F('الطرف الثاني').selectOption({label:'عميل: شركة العميل'});await F('العنوان').fill('x');await F('القيمة').fill('1');
  await page.click('#md form button.btn');await page.waitForTimeout(700);
  console.log('dup error shown:',await page.textContent('#md .err'));await page.click('#md button.sec');
  await page.click('#main tbody tr');await page.waitForTimeout(700);
  await page.screenshot({path:'ui_contracts.png'});
  // خروج ودخول المحاسب
  await page.click('#lo');await login('acc');await page.waitForSelector('#app:not(.hide)');
  console.log('acc nav has users page:',await page.locator('#nav a[data-k="users"]').count(),'| dash:',await page.locator('#nav a[data-k="dash"]').count());
  await nav('contracts');await page.click('#main tbody tr');await page.waitForTimeout(600);
  await page.click('text=+ مستخلص');await F('إجمالي المستخلص').fill('100000');await ok();
  await page.click('button:has-text("مراجعة")');await ok();
  console.log('acc sees approve button:',await page.locator('button:has-text("اعتماد (يولّد القيد)")').count());
  await page.click('#lo');await login('boss');await page.waitForSelector('#app:not(.hide)');
  await nav('contracts');await page.click('#main tbody tr');await page.waitForTimeout(600);
  await page.click('button:has-text("اعتماد (يولّد القيد)")');await ok();
  await page.click('button:has-text("تحصيل/سداد")');await F('المبلغ').fill('40000');await ok();
  step('invoice created→reviewed→approved→paid');
  console.log('invoices table:',(await page.textContent('#main')).replace(/\s+/g,' ').match(/المستخلصات.*?المتبقي/)?.[0]?.slice(0,40));
  // تقارير
  await nav('rep');await page.waitForTimeout(800);
  console.log('trial balance balanced shown:',(await page.textContent('#tc')).replace(/\s+/g,' ').slice(0,200));
  await page.click('button:has-text("الميزانية العمومية")');await page.click('#tc form button');await page.waitForTimeout(700);
  console.log('balance sheet:',(await page.textContent('#tc')).replace(/\s+/g,' ').slice(0,260));
  await nav('dash');await page.waitForTimeout(900);await page.screenshot({path:'ui_dash.png'});
  console.log('dash has revenue:',(await page.textContent('#main')).includes('الإيرادات'));
  await nav('audit');await page.waitForTimeout(700);
  console.log('audit rows:',await page.locator('#main tbody tr').count());
  await page.click('button:has-text("قبل/بعد") >> nth=0');await page.waitForTimeout(300);console.log('audit detail opens:',await page.locator('#md pre').count());await page.click('#vx');
  await page.click('button:has-text("التحقق من سلامة السلسلة")');await page.click('#md form button.btn');await page.waitForTimeout(600);
  // موبايل
  await page.setViewportSize({width:390,height:800});await nav('contracts');await page.waitForTimeout(500);
  console.log('mobile h-scroll (page):',await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth));
  console.log('ERRORS:',errs.length?errs:'none');
  await b.close();
})().catch(e=>{console.error('FAIL',e.message);process.exit(1)});
