const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({acceptDownloads:true});const page=await ctx.newPage();page.setViewportSize({width:1300,height:850});const errs=[];
page.on('pageerror',e=>errs.push(e.message));page.on('dialog',d=>d.accept());
const F=l=>page.locator(`xpath=//div[@id='md']//label[starts-with(normalize-space(.),'${l}')]/following-sibling::*[1]`);
const ok=async()=>{await page.click('#md form button.btn');await page.waitForSelector('#ov.hide',{state:'attached',timeout:5000});await page.waitForTimeout(400)};
const nav=async k=>{await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(500)};
await page.goto('http://localhost:8765/');await page.fill('#lu','boss');await page.fill('#lp','Passw0rd!long');await page.click('#lf button');await page.waitForSelector('#app:not(.hide)');
await nav('projects');await page.click('text=+ مشروع');await F('الكود').fill('F-1');await F('الاسم').fill('مشروع المرفقات');await ok();
fs.writeFileSync('/tmp/note.txt','محتوى تجريبي');
await page.click('button:has-text("مرفقات")');
await page.setInputFiles('#fu','/tmp/note.txt');await page.click('#fup');await page.waitForSelector('#md td:has-text("note.txt")');console.log('uploaded: yes');
const [dl]=await Promise.all([page.waitForEvent('download'),page.click('#md [data-d]')]);const p=await dl.path();console.log('download matches:',fs.readFileSync(p,'utf8')==='محتوى تجريبي');
await page.click('#md [data-x]');console.log('no-reason error:',await page.textContent('#fe'));
await page.fill('#fr','رُفع بالخطأ');await page.click('#md [data-x]');await page.waitForSelector('#md td:has-text("لا توجد مرفقات")');console.log('deleted: yes');
await page.click('#fx');
for(const [lbl,ext] of [['تصدير Excel','xlsx'],['تصدير PDF','pdf']]){
  const [d]=await Promise.all([page.waitForEvent('download'),page.click(`button:has-text("${lbl}")`)]);const f=await d.path();const buf=fs.readFileSync(f);
  console.log(ext,'file:',d.suggestedFilename(),buf.length,'bytes', ext==='pdf'?buf.slice(0,4).toString():buf.slice(0,2).toString());}
await nav('dash');await page.waitForTimeout(500);
console.log('dashboard export buttons:',await page.locator('#main button:has-text("تصدير")').count());
console.log(errs.length?errs:'no js errors');await b.close()})();
