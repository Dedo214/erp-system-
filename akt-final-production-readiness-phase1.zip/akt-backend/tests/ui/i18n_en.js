const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({acceptDownloads:true});const page=await ctx.newPage();page.setViewportSize({width:1300,height:850});const errs=[];
page.on('pageerror',e=>errs.push(e.message));page.on('dialog',d=>d.accept());
const ar=/[؀-ۿ]/;
await page.goto('http://localhost:8765/');
await page.evaluate(()=>localStorage.setItem('akt_lang','en'));await page.reload();
console.log('dir:',await page.evaluate(()=>document.documentElement.dir+'/'+document.documentElement.lang));
console.log('login text:',(await page.textContent('#login')).replace(/\s+/g,' ').trim());
await page.fill('#lu','boss');await page.fill('#lp','bad');await page.click('#lf button');await page.waitForTimeout(800);
console.log('login err:',await page.textContent('#le'));
await page.fill('#lp','Passw0rd!long');await page.click('#lf button');await page.waitForSelector('#app:not(.hide)');
const keys=await page.$$eval('#nav a',as=>as.map(a=>a.dataset.k).filter(Boolean));
const left={};let total=0;
for(const k of keys){await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(500);
 const t=await page.evaluate(()=>{const o=[];const w=document.createTreeWalker(document.querySelector('#main'),NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){if(/[؀-ۿ]/.test(n.nodeValue)&&!n.parentNode.closest('td,[data-notr]'))o.push(n.nodeValue.trim())}return o});
 if(t.length)left[k]=t;total+=t.length}
console.log('nav items:',keys.length,'untranslated UI strings:',total);console.log(JSON.stringify(left,null,1).slice(0,3000));
console.log('nav text:',(await page.textContent('#nav')).replace(/\s+/g,' ').slice(0,300));
// export in English
await page.click('#nav a[data-k="users"]');await page.waitForTimeout(700);console.log('btns:',await page.$$eval('#main button',b=>b.map(x=>x.textContent.trim()).join('|')));
const dl=page.waitForEvent('download');await page.click('button:has-text("Export Excel")');const d=await dl;console.log('download:',d.suggestedFilename());
// toggle back
await page.click('#langbtn');await page.waitForTimeout(800);
console.log('back dir:',await page.evaluate(()=>document.documentElement.dir),'nav has Arabic:',ar.test(await page.textContent('#nav')));
console.log(errs.length?errs:'no js errors');await b.close()})();
