const {chromium,devices}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({...devices['Pixel 7']});const page=await ctx.newPage();const errs=[];
page.on('pageerror',e=>errs.push(e.message));page.on('dialog',d=>d.accept());
await page.goto('http://localhost:8765/');await page.screenshot({path:'/tmp/m_login.png'});
await page.fill('#lu','boss');await page.fill('#lp','Passw0rd!long');await page.click('#lf button');await page.waitForSelector('#app:not(.hide)');
await page.screenshot({path:'/tmp/m_home.png'});
const ks=await page.$$eval('#nav a[data-k]',a=>a.map(x=>x.dataset.k));
const bad=[];const vw=page.viewportSize().width;
const clickable=async k=>{await page.click('#mmenu');await page.waitForTimeout(250);await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(450)};
for(const k of ks){
  await clickable(k);
  const o=await page.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,open:document.body.classList.contains('navopen'),t:document.getElementById('mtitle').textContent}));
  if(o.sw>o.cw+2)bad.push(`${k}: page overflow ${o.sw}>${o.cw}`);
  if(o.open)bad.push(k+': menu stayed open');
  if(!o.t)bad.push(k+': no title');
}
console.log('pages:',ks.length,'problems:',bad.length?bad:'none');
await clickable('projects');await page.click('text=+ مشروع');await page.screenshot({path:'/tmp/m_form.png'});
const md=await page.evaluate(()=>{const r=document.getElementById('md').getBoundingClientRect();return {l:r.left,r:r.right,w:innerWidth}});console.log('modal fits:',md.l>=0&&md.r<=md.w,md);
await page.click('#md .btn.sec, #md button:has-text("إلغاء")').catch(()=>{});
await clickable('dash');await page.screenshot({path:'/tmp/m_dash.png'});
console.log(errs.length?errs:'no js errors');await b.close()})();
