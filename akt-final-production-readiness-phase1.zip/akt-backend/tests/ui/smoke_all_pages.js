const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const page=await b.newPage();const errs=[];
page.on('pageerror',e=>errs.push('PAGEERR '+e.message));page.on('dialog',d=>d.accept());
await page.goto('http://localhost:8765/');await page.fill('#lu','boss');await page.fill('#lp','Passw0rd!long');await page.click('#lf button');await page.waitForSelector('#app:not(.hide)');
const ks=await page.$$eval('#nav a[data-k]',a=>a.map(x=>x.dataset.k));
for(const k of ks){await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(600);
 const e=await page.$$eval('#main .err',x=>x.map(y=>y.textContent));console.log(k.padEnd(9),e.length?'ERR '+e:'ok');}
// فتح نماذج الإنشاء لكل وحدة للتأكد من سلامة بناء الحقول
for(const k of ['items','pr','po','emp','pay','users','ledger','guar']){await page.click(`#nav a[data-k="${k}"]`);await page.waitForTimeout(400);
 const btn=page.locator('#main .tools button.btn').first();await btn.click();await page.waitForTimeout(500);
 console.log('form',k,await page.locator('#md form').count(),'fields',await page.locator('#md form input,#md form select,#md form textarea').count());await page.click('#md form p button.sec');}
console.log(errs.length?errs:'no js errors');await b.close()})();
