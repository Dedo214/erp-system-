const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const page=await (await b.newContext()).newPage();page.setViewportSize({width:1300,height:850});
let fired=false,csp=[];page.on('dialog',async d=>{fired=true;await d.dismiss()});page.on('console',m=>{if(/Content Security Policy/i.test(m.text()))csp.push(m.text().slice(0,80))});
await page.goto('http://localhost:8765/');await page.fill('#lu','boss');await page.fill('#lp','Passw0rd!long');await page.click('#lf button');await page.waitForSelector('#app:not(.hide)');
const P=['<img src=x onerror=alert(1)>','"><script>alert(2)</script>','<svg onload=alert(3)>'];
for(const [i,p] of P.entries()){await page.click('#nav a[data-k="projects"]');await page.waitForTimeout(300);await page.click('text=+ مشروع');
 await page.locator("xpath=//div[@id='md']//label[starts-with(normalize-space(.),'الكود')]/following-sibling::*[1]").fill('X'+i);
 await page.locator("xpath=//div[@id='md']//label[starts-with(normalize-space(.),'الاسم')]/following-sibling::*[1]").fill(p);
 await page.click('#md form button.btn');await page.waitForTimeout(600)}
await page.click('#nav a[data-k="projects"]');await page.waitForTimeout(500);
const html=await page.innerHTML('#main tbody');
console.log('raw tags in DOM:',/<img |<svg |<script/i.test(html),'| dialogs fired:',fired,'| csp violations:',csp.length);
console.log('text shown literally:',(await page.textContent('#main tbody')).includes('<img src=x onerror=alert(1)>'));
await b.close()})();
