"""اختبار تحمل للنظام.

التشغيل:
    python tools/loadtest.py http://localhost:8766 boss 'pass' [entries] [threads]

تُشغّل الأداة يدويًا على بيئة اختبار لأنها تنشئ مشاريع وقيودًا تجريبية.
"""
import random
import statistics
import sys
import threading
import time

import httpx


def percentile(values, ratio):
    values = sorted(values)
    return values[min(len(values) - 1, int(len(values) * ratio))]


def report(name, latencies, errors, wall=None):
    if not latencies:
        print(f"{name:28} لا توجد نتائج")
        return
    throughput = f" thr={len(latencies) / wall:6.1f}/s" if wall else ""
    print(
        f"{name:28} n={len(latencies):5} err={errors:3} "
        f"p50={statistics.median(latencies) * 1000:7.0f}ms "
        f"p95={percentile(latencies, .95) * 1000:7.0f}ms "
        f"max={max(latencies) * 1000:7.0f}ms{throughput}"
    )


def login(client, username, password):
    response = client.post("/auth/login", json={"username": username, "password": password})
    response.raise_for_status()
    return {"authorization": "Bearer " + response.json()["token"]}


def create_projects(client, headers):
    project_ids = []
    for i in range(30):
        response = client.post(
            "/projects",
            json={"code": f"L{i:03}", "name": f"مشروع تحميل {i}"},
            headers=headers,
        )
        if response.status_code == 201:
            project_ids.append(response.json()["id"])
    if len(project_ids) < 30:
        response = client.get("/projects", headers=headers)
        response.raise_for_status()
        project_ids = [p["id"] for p in response.json() if p["code"].startswith("L")]
    if not project_ids:
        raise RuntimeError("تعذر إنشاء أو العثور على مشاريع اختبار")
    return project_ids


def run_writes(base, headers, project_ids, entries, threads):
    latencies, errors, lock, bad = [], [0], threading.Lock(), []

    def writer(count):
        with httpx.Client(base_url=base, timeout=60) as client:
            for _ in range(count):
                amount = random.randint(100, 50000)
                body = {
                    "date": "2026-11-0%d" % random.randint(1, 9),
                    "description": f"قيد تحميل {random.random()}",
                    "project_id": random.choice(project_ids),
                    "lines": [
                        {"account_code": "5100", "debit": amount},
                        {"account_code": "1100", "credit": amount},
                    ],
                }
                started = time.time()
                response = client.post("/ledger/entries", json=body, headers=headers)
                elapsed = time.time() - started
                with lock:
                    latencies.append(elapsed)
                    if response.status_code != 201:
                        errors[0] += 1
                        bad.append((response.status_code, response.text[:120]))

    per_thread = entries // threads
    started = time.time()
    workers = [threading.Thread(target=writer, args=(per_thread,)) for _ in range(threads)]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join()
    wall = time.time() - started
    report(f"POST /ledger/entries x{threads} threads", latencies, errors[0], wall)
    if bad:
        print("  أول الأخطاء:", bad[:3])


def verify_data(client, headers, expected_entries):
    entries = client.get("/ledger/entries?limit=500", headers=headers)
    entries.raise_for_status()
    numbers = [entry["no"] for entry in entries.json()]
    trial_balance = client.get("/ledger/trial-balance", headers=headers)
    trial_balance.raise_for_status()
    rows = trial_balance.json()["rows"]
    debit = sum(float(row["debit"]) for row in rows)
    credit = sum(float(row["credit"]) for row in rows)
    print(f"ميزان المراجعة: مدين={debit:,.2f} دائن={credit:,.2f} متوازن={abs(debit - credit) < 0.005}")
    if numbers:
        print("آخر رقم قيد:", max(numbers), "| عدد القيود المتوقع:", expected_entries)
    started = time.time()
    audit = client.get("/audit/verify", headers=headers)
    audit.raise_for_status()
    print(f"audit/verify: {audit.json()} في {time.time() - started:.1f}s")


def run_reads(client, headers, project_id):
    endpoints = [
        "/ledger/entries?limit=500",
        "/ledger/trial-balance",
        "/reports/income-statement",
        "/reports/balance-sheet",
        "/reports/cashflow",
        "/executive/dashboard",
        "/executive/aging",
        "/reports/alerts",
        f"/reports/project/{project_id}",
        "/audit?limit=200",
        "/projects",
        "/reports/general-ledger/5100",
    ]
    for endpoint in endpoints:
        latencies, errors, lock = [], [0], threading.Lock()

        def reader(count):
            with httpx.Client(base_url=client.base_url, timeout=60) as worker:
                for _ in range(count):
                    started = time.time()
                    response = worker.get(endpoint, headers=headers)
                    elapsed = time.time() - started
                    with lock:
                        latencies.append(elapsed)
                        if response.status_code != 200:
                            errors[0] += 1

        started = time.time()
        workers = [threading.Thread(target=reader, args=(10,)) for _ in range(10)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        report("GET " + endpoint[:24], latencies, errors[0], time.time() - started)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) < 3:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    base, username, password = argv[:3]
    entries = int(argv[3]) if len(argv) > 3 else 3000
    threads = int(argv[4]) if len(argv) > 4 else 16
    if entries < 1 or threads < 1:
        raise ValueError("entries وthreads يجب أن يكونا أكبر من صفر")

    with httpx.Client(base_url=base, timeout=60) as client:
        headers = login(client, username, password)
        project_ids = create_projects(client, headers)
        run_writes(base, headers, project_ids, entries, threads)
        verify_data(client, headers, (entries // threads) * threads)
        run_reads(client, headers, project_ids[0])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
