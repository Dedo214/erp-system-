"use strict";
/* ============ أدوات أساسية ============ */
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let TOKEN=null,ME=null;
try{TOKEN=sessionStorage.getItem("akt_token")}catch(e){}

function toast(m,err){const t=$("#toast");t.textContent=m;t.className=err?"err":"";clearTimeout(toast.t);toast.t=setTimeout(()=>t.className="hide",err?6000:2500)}

async function api(method,url,body,raw){
  const h={};if(TOKEN)h.authorization="Bearer "+TOKEN;
  let init={method,headers:h};
  if(body instanceof FormData)init.body=body;else if(body!==undefined){h["content-type"]="application/json";init.body=JSON.stringify(body)}
  let r;
  try{r=await fetch(url,init)}catch(e){throw new Error("تعذر الاتصال بالخادم. لم تُحفظ العملية.")}
  if(r.status===401&&!url.startsWith("/auth/login")){logout(true);throw new Error("انتهت الجلسة، سجّل الدخول مجددًا")}
  let d=null;const txt=await r.text();try{d=txt?JSON.parse(txt):null}catch(e){}
  if(!r.ok){
    let m=d&&d.detail;
    if(Array.isArray(m))m=m.map(x=>(x.loc||[]).slice(1).join(".")+": "+x.msg).join("\n");
    else if(m&&typeof m==="object")m=m.message||JSON.stringify(m);
    throw new Error(m||("خطأ "+r.status));
  }
  return d;
}

const AR={over:"تجاوز",warn:"قارب الحد",unbudgeted:"بلا موازنة",awarded:"تمت الترسية",cancelled:"ملغى",supplier:"مورد",subcontractor:"مقاول باطن",draft:"مسودة",review:"قيد المراجعة",approved:"معتمد",submitted:"مقدَّم",rejected:"مرفوض",cancelled:"ملغي",active:"ساري",completed:"مكتمل",
 terminated:"منتهٍ",tech_review:"مراجعة فنية",fin_review:"مراجعة مالية",approval:"بانتظار الاعتماد",pending:"بانتظار البت",ordered:"تم الطلب",closed:"مغلق",paid:"مصروف",
 renewed:"مجدَّد",released:"مُفرج عنه",claimed:"مُصادَر",suspended:"موقوف",client:"عميل",subcontractor:"مقاول باطن",supplier:"مورد",
 bid:"ابتدائي",performance:"نهائي",advance:"دفعة مقدمة",insurance:"تأمين",manual:"يدوي",invoice:"مستخلص",payment:"سداد/تحصيل",payroll:"رواتب",receipt:"استلام",
 issue:"صرف",stock_adjust:"جرد",supplier_payment:"سداد مورد",bank:"بنك",cash:"نقدي",cheque:"شيك",study:"قيد الدراسة",submitted:"تم التقديم",negotiation:"تفاوض",won:"فائزة",lost:"خاسرة",pending:"قيد الفحص",accepted:"مقبول",accepted_notes:"مقبول بملاحظات",open:"مفتوح",in_progress:"جارٍ",done:"تم",initial:"ابتدائي",final:"نهائي",work:"تنفيذ",material:"مواد",low:"منخفضة",medium:"متوسطة",high:"عالية",inspection:"تفتيش",accident:"حادث",near_miss:"شبه حادث",mitigated:"مخفَّف",working:"يعمل",maintenance:"صيانة",idle:"متوقف",in:"وارد",out:"صادر",materials:"مواد",labor:"عمالة",equipment:"معدات",admin:"إدارية",other:"أخرى"};
const KEYS={advance_pct:"نسبة الدفعة المقدمة %",age_days:"العمر (يوم)",approved_changes:"أوامر التغيير المعتمدة",avg_cost:"متوسط التكلفة",closure_note:"ملاحظة الإغلاق",current_value:"القيمة الحالية",days_paid:"أيام مسدَّدة",days_to_due:"أيام حتى الاستحقاق",days_to_expiry:"أيام حتى الانتهاء",direct_cost:"التكلفة المباشرة",done_pct:"نسبة الإنجاز %",done_value:"قيمة المنجز",due_missed:"فات موعده",end_date:"تاريخ النهاية",executed_value:"القيمة المنفذة",expiry_date:"تاريخ الانتهاء",fin_review:"المراجعة المالية",full_name:"الاسم الكامل",hire_date:"تاريخ التعيين",ins_emp_pct:"تأمين الموظف %",ins_er_pct:"تأمين صاحب العمل %",ins_max:"حد التأمين الأعلى",ins_min:"حد التأمين الأدنى",is_active:"نشط",issue_date:"تاريخ الإصدار",lock_date:"تاريخ إقفال الفترة",maint_overdue:"صيانة متأخرة",min_stock:"الحد الأدنى للمخزون",next_maint:"الصيانة القادمة",open_snags:"ملاحظات مفتوحة",original_value:"القيمة الأصلية",ot_multiplier:"معامل الإضافي",over_executed:"تجاوز الكمية",overtime_hours:"ساعات إضافية",payment_days:"مدة السداد (يوم)",payroll_due:"رواتب مستحقة",penalty_terms:"شروط الغرامة",planned_end:"نهاية مخططة",planned_start:"بداية مخططة",probability_pct:"احتمال الفوز %",progress_pct:"نسبة التقدم %",projects_count:"عدد المشاريع",received_value:"القيمة المستلمة",rejected_rows:"صفوف مرفوضة",retention_payable:"محتجزات مستحقة للدفع",retention_pct:"نسبة المحتجز %",retention_receivable:"محتجزات مستحقة التحصيل",reversal_no:"رقم قيد العكس",start_date:"تاريخ البداية",tax_exemption:"الإعفاء الضريبي",tax_pct:"الضريبة %",tech_review:"المراجعة الفنية",time_days:"المدة (يوم)",uploaded_at:"رُفع في",uploaded_by:"رفعه",warranty_end:"نهاية الضمان",warranty_months:"مدة الضمان (شهر)",weighted_total:"الإجمالي المرجَّح",win_rate_pct:"نسبة الفوز %",code:"الكود",name:"الاسم",status:"الحالة",kind:"النوع",title:"العنوان",no:"رقم",date:"التاريخ",description:"البيان",amount:"المبلغ",
 debit:"مدين",credit:"دائن",balance:"الرصيد",net:"الصافي",gross:"الإجمالي",tax:"الضريبة",retention:"ضمان الأعمال",advance:"الدفعة المقدمة",paid:"المدفوع",
 outstanding:"المتبقي",revenue:"الإيرادات",expenses:"المصروفات",net_income:"صافي الدخل",cash:"النقدية",receivables:"المستحقات",payables:"المدفوعات المستحقة",
 inventory:"المخزون",backlog:"أعمال متبقية",projects:"المشاريع",alerts:"تنبيهات",financial:"المؤشرات المالية",aging:"أعمار الديون",total_debit:"إجمالي المدين",
 total_credit:"إجمالي الدائن",balanced:"متزن",rows:"الأسطر",account_code:"الحساب",asset:"الأصول",liability:"الخصوم",equity:"حقوق الملكية",
 total_assets:"إجمالي الأصول",total_liabilities:"إجمالي الخصوم",total_equity:"إجمالي حقوق الملكية",current_earnings:"أرباح الفترة",total_revenue:"إجمالي الإيرادات",
 total_expenses:"إجمالي المصروفات",opening:"رصيد افتتاحي",closing:"رصيد ختامي",entry_no:"رقم القيد",buckets:"الشرائح",in:"داخل",out:"خارج",
 opening_cash:"النقدية الافتتاحية",projected_cash:"النقدية المتوقعة",overdue:"متأخر",d0_30:"0-30 يوم",d31_60:"31-60 يوم",d61_90:"61-90 يوم",later:"لاحقًا",
 current:"غير مستحق",d1_30:"1-30",d90_plus:"+90",receivables_:"",payables_:"",as_of:"كما في",ok:"سليمة",checked:"عدد الأسطر",stock_value:"قيمة المخزون",
 ledger_1300:"رصيد الأستاذ (1300)",difference:"الفرق",low_stock:"تحت الحد الأدنى",items:"الأصناف",margin_pct:"الهامش %",profit:"الربح",cost:"التكلفة",budget:"الموازنة",
 billed:"المفوتر",collected:"المحصّل",committed:"التزامات",contract_value:"قيمة العقد",budget_used_pct:"استهلاك الموازنة %",flags:"ملاحظات",type:"النوع",
 message:"الرسالة",days_left:"الأيام المتبقية",project:"المشروع",employees:"الموظفون",totals:"الإجماليات",lines:"البنود"};
const label=k=>KEYS[k]||k;
const INTK=/(_count|_days|days|_months|_rows|hours|_no)$/;
const isNum=v=>typeof v==="number"||(typeof v==="string"&&/^-?\d+(\.\d+)?$/.test(v));
function money(v){const n=Number(v);return isNaN(n)?v:n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}
function show(v,k){
  if(v===null||v===undefined||v==="")return "";
  if(typeof v==="boolean")return v?"نعم":"لا";
  if(Array.isArray(v))return v.length?v.map(x=>typeof x==="object"?JSON.stringify(x):x).join("، "):"";
  if(typeof v==="object")return JSON.stringify(v);
  if(AR[v]&&(k==="status"||k==="kind"||k==="source"||k==="method"||k==="stage"||k==="severity"||k==="direction"||k==="category"||k==="level"))return AR[v];
  return v;
}
function tag(v){const c={approved:"ok",paid:"ok",active:"ok",completed:"ok",closed:"ok",won:"ok",accepted:"ok",done:"ok",low:"ok",working:"ok",mitigated:"ok",rejected:"bad",cancelled:"bad",claimed:"bad",terminated:"bad",lost:"bad",high:"bad",over:"bad",unbudgeted:"warn",accident:"bad",maintenance:"warn",draft:"warn",pending:"warn",review:"warn",open:"warn",accepted_notes:"warn",medium:"warn",negotiation:"warn"}[v]||"";return `<span class="tag ${c}">${esc(AR[v]||v)}</span>`}

/* مراجع الأسماء */
const L={projects:{},parties:{},items:{}};
let EQN={},WKN={};
async function loadRefs(){
  const get=async(u,perm,f)=>{if(!can(perm))return;try{(await api("GET",u)).forEach(f)}catch(e){}};
  await Promise.all([get("/projects","projects.view",p=>L.projects[p.id]=p.code+" - "+p.name),
    get("/parties","parties.view",p=>L.parties[p.id]=p.name),get("/items","items.view",i=>L.items[i.id]=i.code+" - "+i.name),
    get("/equipment","equipment.view",e=>EQN[e.id]=e.name),get("/workers","labor.view",w=>WKN[w.id]=w.name)]);
}
const can=p=>!p||(ME&&ME.permissions.includes(p));
const get=(o,path)=>path.split(".").reduce((a,k)=>a==null?a:a[k],o);

/* ============ النوافذ والنماذج ============ */
const SRC={
  projects:{url:"/projects",v:"id",l:r=>r.code+" - "+r.name,perm:"projects.view"},
  clients:{url:"/parties",f:r=>r.kind==="client",v:"id",l:r=>r.name,perm:"parties.view"},
  suppliers:{url:"/parties",f:r=>r.kind==="supplier",v:"id",l:r=>r.name,perm:"parties.view"},
  parties:{url:"/parties",v:"id",l:r=>(AR[r.kind]||r.kind)+": "+r.name,perm:"parties.view"},
  accounts:{url:"/ledger/accounts",v:"code",l:r=>r.code+" - "+r.name,perm:"ledger.view"},
  items:{url:"/items",v:"id",l:r=>r.code+" - "+r.name,perm:"items.view"},
  prs:{url:"/purchase-requests",f:r=>r.status==="approved",v:"id",l:r=>"طلب #"+r.no,perm:"items.view"},
};
const ROLES=[["admin","مدير"],["accountant","محاسب"],["storekeeper","أمين مخزن"],["site_engineer","مهندس موقع"]];
const srcCache={};
async function srcOpts(name){
  const s=SRC[name];if(!can(s.perm))return [];
  const d=await api("GET",s.url);return (s.f?d.filter(s.f):d).map(r=>[r[s.v],s.l(r)]);
}
function cellText(r,c){
  const [k,l,t]=c,v=get(r,k);
  if(t==="money"||t==="num")return v===null||v===undefined||v===""?"":Number(v);
  if(t&&t.startsWith("ref:"))return L[t.slice(4)][v]||v||"";
  if(t==="len")return (v||[]).length;
  if(t==="status")return AR[v]||v||"";
  const x=show(v,k);return x;
}
async function exportRows(fmt,title,columns,rows){
  try{
    const r=await fetch("/export/"+fmt,{method:"POST",headers:{authorization:"Bearer "+TOKEN,"content-type":"application/json"},body:JSON.stringify(isEN()?{title:tr(title),columns:columns.map(c=>tr(c)),rows:rows.map(r=>r.map(v=>typeof v==="string"?tr(v,"cell"):v)),rtl:false,lang:"en"}:{title,columns,rows})});
    if(!r.ok){let m=tr("فشل التصدير");try{const d=await r.json();m=typeof d.detail==="string"?d.detail:m}catch(e){}throw new Error(m)}
    const b=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=(/^[\x20-\x7e]+$/.test(tr(title))?tr(title).replace(/[\\/:*?"<>|]/g,"_"):"akt-export-"+new Date().toISOString().slice(0,16).replace(/[:T]/g,"-"))+"."+fmt;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
  }catch(e){toast(e.message,true)}
}
function exportButtons(host,getData){
  if(!can("export.use"))return;
  [["xlsx","Excel"],["pdf","PDF"]].forEach(([f,n])=>{const b=document.createElement("button");b.className="btn sec sm";b.textContent="تصدير "+n;b.onclick=()=>{const d=getData();if(!d||!d.rows.length){toast("لا توجد بيانات للتصدير",true);return}exportRows(f,d.title,d.columns,d.rows)};host.appendChild(b)});
}
async function filesDialog(entity,eid,title){
  const md=$("#md");
  const draw=async()=>{
    let L2=[];try{L2=await api("GET",`/files?entity=${encodeURIComponent(entity)}&entity_id=${encodeURIComponent(eid)}`)}catch(e){md.innerHTML=`<h2>المرفقات</h2><p class="err">${esc(e.message)}</p><p><button class="btn sec" id="fx">إغلاق</button></p>`;$("#fx").onclick=closeModal;return}
    md.innerHTML=`<h2>مرفقات: ${esc(title||"")}</h2>
    <div class="tw"><table><thead><tr><th>الملف</th><th>الحجم</th><th>رُفع في</th><th></th></tr></thead><tbody>${L2.map(f=>`<tr><td>${esc(f.filename)}</td><td class="n">${Math.ceil(f.size/1024)} ك.ب</td><td>${esc(String(f.uploaded_at||"").slice(0,16).replace("T"," "))}</td><td><button class="btn sm sec" data-d="${esc(f.id)}" data-n="${esc(f.filename)}">تنزيل</button>${can("files.delete")?` <button class="btn sm bad" data-x="${esc(f.id)}">حذف</button>`:""}</td></tr>`).join("")||`<tr><td colspan="4" class="muted">لا توجد مرفقات</td></tr>`}</tbody></table></div>
    ${can("files.upload")?`<div class="card" style="margin-top:10px"><label>رفع ملف (pdf, png, jpg, xlsx, docx, csv, txt)</label><input type="file" id="fu" accept=".pdf,.png,.jpg,.jpeg,.xlsx,.docx,.csv,.txt"><p><button class="btn" id="fup">رفع</button></p></div>`:""}
    ${can("files.delete")&&L2.length?`<div><label>سبب الحذف (إلزامي عند الحذف)</label><input id="fr" placeholder="مثال: رُفع بالخطأ"></div>`:""}
    <p id="fe" class="err"></p><p><button class="btn sec" id="fx">إغلاق</button></p>`;
    $("#fx").onclick=closeModal;
    md.querySelectorAll("[data-d]").forEach(b=>b.onclick=()=>download("/files/"+b.dataset.d+"/download",b.dataset.n));
    md.querySelectorAll("[data-x]").forEach(b=>b.onclick=async()=>{
      const r=($("#fr")||{}).value||"";if(r.trim().length<3){$("#fe").textContent="اكتب سبب الحذف (3 أحرف على الأقل)";return}
      try{await api("DELETE",`/files/${b.dataset.x}?reason=${encodeURIComponent(r)}`);toast("تم الحذف");draw()}catch(e){$("#fe").textContent=e.message}});
    const up=$("#fup");if(up)up.onclick=async()=>{
      const f=$("#fu").files[0];if(!f){$("#fe").textContent="اختر ملفًا أولًا";return}
      const F=new FormData();F.append("file",f);up.disabled=true;
      try{await api("POST",`/files?entity=${encodeURIComponent(entity)}&entity_id=${encodeURIComponent(eid)}`,F);toast("تم الرفع");draw()}catch(e){$("#fe").textContent=e.message;up.disabled=false}};
  };
  md.innerHTML="";$("#ov").className="";await draw();
}
function closeModal(){$("#ov").className="hide";$("#md").innerHTML=""}
$("#ov").addEventListener("mousedown",e=>{if(e.target.id==="ov")closeModal()});

function fieldHtml(f,i,pre,opts,bare){
  const id=`${pre}_${i}`,req=f.req?" required":"",d=f.def!==undefined&&f.def!==null?f.def:"";
  let inner="";
  if(f.t==="select"){inner=`<select id="${id}"${req}>${f.req&&!bare?"":`<option value="">${bare?esc(f.l):""}</option>`}${(opts||[]).map(([v,l])=>`<option value="${esc(v)}"${String(v)===String(d)?" selected":""}>${esc(l)}</option>`).join("")}</select>`}
  else if(f.t==="textarea")inner=`<textarea id="${id}" rows="3"${req}>${esc(d)}</textarea>`;
  else if(f.t==="check")return `<label><input type="checkbox" id="${id}"${d?" checked":""}> ${esc(f.l)}</label>`;
  else if(f.t==="multi")inner=(opts||[]).map(([v,l],j)=>`<label style="display:inline-block;margin-inline-end:12px"><input type="checkbox" data-m="${id}" value="${esc(v)}"${(d||[]).includes(v)?" checked":""}> ${esc(l)}</label>`).join("");
  else if(f.t==="file")inner=`<input type="file" id="${id}"${req}${f.accept?` accept="${f.accept}"`:""}>`;
  else if(f.t==="rows")inner=`<div class="rows" id="${id}"></div><button type="button" class="btn sec sm" data-add="${id}">+ سطر</button>`;
  else inner=`<input id="${id}" type="${f.t==="number"?"number":f.t==="date"?"date":f.t==="password"?"password":"text"}"${f.t==="number"?' step="any"':""} value="${esc(d)}"${req}${bare?` placeholder="${esc(f.l)}" title="${esc(f.l)}"`:""}>`;
  if(bare)return inner;
  return `<label>${esc(f.l)}${f.req?" *":""}</label>${inner}`;
}
function readField(f,i,pre){
  const id=`${pre}_${i}`,el=document.getElementById(id);
  if(f.t==="check")return el.checked;
  if(f.t==="multi")return [...document.querySelectorAll(`[data-m="${id}"]:checked`)].map(x=>x.value);
  if(f.t==="file")return el.files[0]||null;
  if(f.t==="rows")return [...el.querySelectorAll(".rr")].map(rr=>{const o={};f.rows.forEach((sf,j)=>{const v=readField(sf,j,rr.dataset.p);if(v!==""&&v!==null)o[sf.n]=v});return o});
  const v=el.value;if(v==="")return "";
  return f.t==="number"?Number(v):v;
}
async function form(title,fields,submit,opts={}){
  const ov=$("#ov"),md=$("#md"),pre="f"+Date.now();
  const sel={};for(let i=0;i<fields.length;i++){const f=fields[i];if(f.src)sel[i]=await srcOpts(f.src).catch(()=>[]);else if(f.opts)sel[i]=typeof f.opts==="function"?f.opts():f.opts;
    if(f.t==="rows")for(let j=0;j<f.rows.length;j++){const s=f.rows[j];if(s.src)s._o=await srcOpts(s.src).catch(()=>[]);else if(s.opts)s._o=typeof s.opts==="function"?s.opts():s.opts}}
  md.innerHTML=`<h2>${esc(title)}</h2>${opts.note?`<p class="muted">${esc(opts.note)}</p>`:""}<form id="${pre}">${fields.map((f,i)=>fieldHtml(f,i,pre,sel[i])).join("")}
  <div class="err" id="${pre}e"></div><p style="margin-top:14px"><button class="btn" id="${pre}ok">${esc(opts.ok||"تنفيذ")}</button> <button type="button" class="btn sec" id="${pre}x">إلغاء</button></p></form>`;
  ov.className="";
  const addRow=id=>{const f=fields.find((_,i)=>`${pre}_${i}`===id),box=document.getElementById(id),p=id+"_r"+box.children.length;
    const d=document.createElement("div");d.className="rr";d.dataset.p=p;d.innerHTML=f.rows.map((s,j)=>fieldHtml(s,j,p,s._o,true)).join("");box.appendChild(d)};
  fields.forEach((f,i)=>{if(f.t==="rows")addRow(`${pre}_${i}`)});
  md.onclick=e=>{if(e.target.dataset.add)addRow(e.target.dataset.add)};
  $(`#${pre}x`).onclick=closeModal;
  $(`#${pre}`).onsubmit=async e=>{e.preventDefault();const b=$(`#${pre}ok`),er=$(`#${pre}e`);er.textContent="";b.disabled=true;
    try{const v={};fields.forEach((f,i)=>{v[f.n]=readField(f,i,pre)});await submit(v);closeModal();loadRefs()}
    catch(x){er.textContent=x.message}finally{b.disabled=false}};
}
function clean(v){const o={};for(const k in v){const x=v[k];if(x===""||x===null||(Array.isArray(x)&&x.length===0&&false))continue;o[k]=x}return o}

/* ============ عرض القوائم ============ */
const ACT=[];   // مخزن دوال الأزرار
function cellHtml(r,c){
  const [k,l,t]=c,v=get(r,k);
  if(t==="money")return `<td class="n">${v===null||v===undefined||v===""?"":esc(money(v))}</td>`;
  if(t==="num")return `<td class="n">${esc(show(v,k))}</td>`;
  if(t==="status")return `<td>${tag(v)}</td>`;
  if(t&&t.startsWith("ref:"))return `<td>${esc(L[t.slice(4)][v]||v||"")}</td>`;
  if(t==="len")return `<td class="n">${(v||[]).length}</td>`;
  return `<td>${esc(show(v,k))}</td>`;
}
async function listView(el,spec,ctx){
  const id="lv"+Math.random().toString(36).slice(2,7);
  el.innerHTML=`<div class="top"><h2 style="margin:0">${esc(spec.t)}</h2><input id="${id}q" placeholder="بحث..." style="max-width:220px"></div><div class="tools" id="${id}t"></div><div id="${id}h"></div><div class="tw" id="${id}w"><p style="padding:14px" class="muted">جارٍ التحميل...</p></div><div id="${id}c"></div>`;
  const tools=$(`#${id}t`),wrap=$(`#${id}w`),kids=$(`#${id}c`);
  let data=[],sel=null;
  const url=typeof spec.url==="function"?spec.url(ctx):spec.url;
  const reload=async()=>{
    try{let d=await api("GET",url);if(spec.head)$(`#${id}h`).innerHTML=spec.head(d);if(spec.pick)d=spec.pick(d,ctx);data=d;draw()}
    catch(e){wrap.innerHTML=`<p class="err" style="padding:14px">${esc(e.message)}</p>`}
  };
  const run=(a,row)=>{
    if(a.custom){a.custom(row,async()=>{await loadRefs();await reload()},ctx);return}
    if(a.view){$("#md").innerHTML=`<h2>${esc(a.l)}</h2>${a.view(row)}<p><button class="btn sec" id="vx">إغلاق</button></p>`;$("#ov").className="";$("#vx").onclick=closeModal;return}
    const f=(typeof a.f==="function"?a.f(row,ctx):a.f)||[];
    const doit=async v=>{
      if(a.run){await a.run(v,row,ctx)}
      else{
        let u=typeof a.url==="function"?a.url(row,ctx):a.url,body;
        const vv=a.q?v:clean(v);
        if(a.q){u+="?"+Object.entries({...(a.pre?a.pre(row):{}),...clean(v)}).map(([k,x])=>k+"="+encodeURIComponent(x)).join("&")}
        else if(a.body)body=a.body(vv,row,ctx);else body=vv;
        const fd=f.some(x=>x.t==="file");
        if(fd){const F=new FormData();F.append("file",v[f.find(x=>x.t==="file").n]);body=F}
        await api(a.m||"POST",u,a.q?undefined:body);
      }
      toast("تم التنفيذ");await loadRefs();await reload();
      if(sel)openKids();
    };
    form(typeof a.l==="function"?a.l(row):a.l,f.map(x=>({...x,def:typeof x.def==="function"?x.def(row):x.def})),doit,{note:a.note,ok:a.ok});
  };
  (spec.tools||[]).forEach(a=>{if(!can(a.perm))return;const b=document.createElement("button");b.className="btn"+(a.sec?" sec":"");b.textContent=a.l;b.onclick=()=>run(a,null);tools.appendChild(b)});
  const openKids=()=>{
    kids.innerHTML="";if(!spec.kids||sel===null)return;
    const row=data[sel];
    spec.kids.forEach(k=>{if(!can(k.perm))return;const d=document.createElement("div");d.className="sub";kids.appendChild(d);listView(d,{...k,t:k.t+" — "+(row.code||row.month||("#"+row.no)||"")},row)});
  };
  const draw=()=>{
    const q=($(`#${id}q`).value||"").toLowerCase();
    const rows=data.map((r,i)=>[r,i]).filter(([r])=>!q||JSON.stringify(r).toLowerCase().includes(q));
    const acts=(spec.actions||[]).filter(a=>can(a.perm));const fl=spec.files&&can("files.view");
    wrap.innerHTML=`<table><thead><tr>${spec.cols.map(c=>`<th>${esc(c[1])}</th>`).join("")}${acts.length||fl?"<th></th>":""}</tr></thead><tbody>${
      rows.map(([r,i])=>`<tr data-i="${i}" class="${sel===i?"sel":""}" style="${spec.kids?"cursor:pointer":""}">${spec.cols.map(c=>cellHtml(r,c)).join("")}${
        acts.length||fl?`<td>${fl?(ACT.push(()=>filesDialog(spec.files,r.id,r.code||r.name||r.no||r.subject||r.description||r.id)),`<button class="btn sm sec" data-a="${ACT.length-1}">مرفقات</button> `):""}${acts.filter(a=>!a.when||a.when(r,ctx)).map(a=>{ACT.push(()=>run(a,r));return `<button class="btn sm ${a.bad?"bad":"sec"}" data-a="${ACT.length-1}">${esc(typeof a.l==="function"?a.l(r):a.l)}</button>`}).join(" ")}</td>`:""}</tr>`).join("")||`<tr><td colspan="99" class="muted" style="padding:14px">لا توجد سجلات</td></tr>`}</tbody></table>`;
  };
  wrap.onclick=e=>{
    const b=e.target.closest("[data-a]");if(b){ACT[+b.dataset.a]();return}
    const tr=e.target.closest("tr[data-i]");if(tr&&spec.kids){sel=+tr.dataset.i;draw();openKids()}
  };
  $(`#${id}q`).oninput=draw;
  exportButtons(tools,()=>{const q=($(`#${id}q`).value||"").toLowerCase();return{title:spec.t,columns:spec.cols.map(c=>c[1]),rows:data.filter(r=>!q||JSON.stringify(r).toLowerCase().includes(q)).map(r=>spec.cols.map(c=>cellText(r,c)))}});
  if(spec.create&&can(spec.create.perm)){
    const b=document.createElement("button");b.className="btn";b.textContent="+ "+(spec.create.l||"جديد");b.onclick=()=>run({...spec.create},null);tools.prepend(b);
  }
  await reload();
}

/* ============ عرض التقارير (JSON عام) ============ */
function renderAny(d,depth=0){
  if(d===null||d===undefined)return "";
  if(Array.isArray(d)){
    if(!d.length)return `<p class="muted">لا يوجد</p>`;
    if(typeof d[0]!=="object")return `<p>${esc(d.join("، "))}</p>`;
    const cols=[...new Set(d.flatMap(r=>Object.keys(r)))].filter(k=>!["id","version"].includes(k)&&d.some(r=>r[k]===null||typeof r[k]!=="object"));
    return `<div class="tw"><table><thead><tr>${cols.map(c=>`<th>${esc(label(c))}</th>`).join("")}</tr></thead><tbody>${d.map(r=>`<tr>${cols.map(c=>{const v=r[c];return isNum(v)&&!/^(no|entry_no|code)$/.test(c)?`<td class="n">${esc(INTK.test(c)?String(v):money(v))}</td>`:`<td>${esc(show(v,c))}</td>`}).join("")}</tr>`).join("")}</tbody></table></div>`;
  }
  if(typeof d==="object"){
    const sc=Object.entries(d).filter(([k,v])=>typeof v!=="object"||v===null),nested=Object.entries(d).filter(([k,v])=>typeof v==="object"&&v!==null);
    let h=sc.length?`<div class="tw"><table class="kv"><tbody>${sc.map(([k,v])=>`<tr><td>${esc(label(k))}</td><td class="${isNum(v)?"n":""}">${esc(isNum(v)?(INTK.test(k)?String(v):money(v)):show(v,k))}</td></tr>`).join("")}</tbody></table></div>`:"";
    nested.forEach(([k,v])=>{h+=`<div class="sub"><h3>${esc(label(k))}</h3>${renderAny(v,depth+1)}</div>`});
    return h;
  }
  return esc(d);
}
async function reportView(el,spec){
  const id="rp"+Math.random().toString(36).slice(2,7);
  el.innerHTML=`<div class="top"><h2 style="margin:0">${esc(spec.t)}</h2></div><div class="tools" id="${id}t"></div>${spec.params?`<form id="${id}f" class="card row2" style="margin-bottom:12px"></form>`:""}<div id="${id}o"></div>`;
  const out=$(`#${id}o`);
  (spec.tools||[]).forEach(a=>{if(!can(a.perm))return;const b=document.createElement("button");b.className="btn"+(a.sec?" sec":"");b.textContent=a.l;b.onclick=()=>a.go();$(`#${id}t`).appendChild(b)});
  let fields=spec.params||[];
  if(fields.length){const f=$(`#${id}f`),sel={};for(let i=0;i<fields.length;i++)if(fields[i].src)sel[i]=await srcOpts(fields[i].src).catch(()=>[]);
    f.innerHTML=fields.map((x,i)=>`<div>${fieldHtml(x,i,id,sel[i])}</div>`).join("")+`<div style="align-self:end"><button class="btn">عرض</button></div>`;}
  const go=async()=>{
    out.innerHTML=`<p class="muted">جارٍ التحميل...</p>`;
    try{
      let u=spec.url,q=[];
      fields.forEach((f,i)=>{const v=readField(f,i,id);if(v===""||v===null)return;if(u.includes("{"+f.n+"}"))u=u.replace("{"+f.n+"}",encodeURIComponent(v));else q.push(f.n+"="+encodeURIComponent(v))});
      if(u.includes("{")){out.innerHTML=`<p class="err">أكمل الحقول المطلوبة</p>`;return}
      const d=await api("GET",u+(q.length?"?"+q.join("&"):""));
      out.innerHTML=spec.csv?`<p><button class="btn sec sm" id="${id}c">تنزيل CSV</button></p>`+renderAny(d):renderAny(d);
      if(spec.csv)$(`#${id}c`).onclick=()=>download(spec.csv,spec.csvName);
      if(can("export.use")){const tb=[...out.querySelectorAll("table:not(.kv)")].sort((a,b)=>b.rows.length-a.rows.length)[0];if(tb){const bar=document.createElement("p");exportButtons(bar,()=>({title:spec.t,columns:[...tb.tHead.rows[0].cells].map(c=>c.textContent.trim()),rows:[...tb.tBodies[0].rows].map(r=>[...r.cells].map(c=>{const t=c.textContent.trim();return /^-?[\d,]+(\.\d+)?$/.test(t)&&t.replace(/,/g,"")!==""&&!/^0\d/.test(t)?Number(t.replace(/,/g,"")):t}))}));out.prepend(bar)}}
    }catch(e){out.innerHTML=`<p class="err">${esc(e.message)}</p>`}
  };
  if(fields.length)$(`#${id}f`).onsubmit=e=>{e.preventDefault();go()};else go();
}
async function download(url,name){
  try{const r=await fetch(url,{headers:{authorization:"Bearer "+TOKEN}});if(!r.ok)throw new Error("فشل التنزيل: "+r.status);
    const b=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
  catch(e){toast(e.message,true)}
}
function saveJson(obj,name){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(obj)],{type:"application/json"}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
const readJson=f=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>{try{ok(JSON.parse(r.result))}catch(e){no(new Error("الملف ليس JSON صالحًا"))}};r.onerror=()=>no(new Error("تعذرت قراءة الملف"));r.readAsText(f)});

/* ============ تعريف الوحدات ============ */
const D=n=>({n,l:"التاريخ",t:"date",req:true,def:new Date().toISOString().slice(0,10)});
const REASON={n:"reason",l:"السبب",t:"text",req:true};
const NOTE={n:"note",l:"ملاحظة",t:"text"};
const NOTEREQ={n:"note",l:"السبب",t:"text",req:true};
const METHODS=[["bank","بنك"],["cash","نقدي"],["cheque","شيك"]];
const MODS=[
 {g:"الإدارة",k:"dash",t:"اللوحة التنفيذية",perm:"executive.view",type:"report",url:"/executive/dashboard",
   tools:[{l:"تصدير ربحية المشاريع CSV",perm:"executive.export",sec:true,go:()=>download("/executive/export/projects.csv","projects.csv")}]},
 {g:"الأساسيات",k:"projects",files:"project",t:"المشاريع",perm:"projects.view",type:"list",url:"/projects",
   cols:[["code","الكود"],["name","الاسم"],["client_id","العميل","ref:parties"],["status","الحالة","status"],["contract_value","قيمة العقد","money"],["budget","الموازنة","money"],["progress","الإنجاز %","num"]],
   create:{l:"مشروع",perm:"projects.create",url:"/projects",f:[{n:"code",l:"الكود",t:"text",req:true},{n:"name",l:"الاسم",t:"text",req:true},{n:"client_id",l:"العميل",t:"select",src:"clients"},{n:"location",l:"الموقع",t:"text"},{n:"start_date",l:"البداية",t:"date"},{n:"end_date",l:"النهاية",t:"date"},{n:"contract_value",l:"قيمة العقد",t:"number"},{n:"budget",l:"الموازنة",t:"number"}]},
   actions:[{l:"تعديل",perm:"projects.update",m:"PATCH",url:r=>"/projects/"+r.id,f:[{n:"name",l:"الاسم",t:"text",def:r=>r.name},{n:"progress",l:"الإنجاز %",t:"number",def:r=>r.progress},{n:"contract_value",l:"قيمة العقد",t:"number",def:r=>r.contract_value},{n:"budget",l:"الموازنة",t:"number",def:r=>r.budget},{n:"reason",l:"السبب (إلزامي عند تغيير القيمة/الموازنة)",t:"text"}],body:(v,r)=>({...v,version:r.version})},
            {l:"حذف",bad:true,perm:"projects.delete",m:"DELETE",q:true,url:r=>"/projects/"+r.id,f:[REASON]}]},
 {g:"الأساسيات",k:"parties",files:"party",t:"العملاء والموردون والمقاولون",perm:"parties.view",type:"list",url:"/parties",
   cols:[["name","الاسم"],["kind","النوع","status"],["contact","المسؤول"],["phone","الهاتف"],["tax_no","الرقم الضريبي"],["terms_days","مدة السداد","num"]],
   create:{l:"طرف",perm:"parties.create",url:"/parties",f:[{n:"kind",l:"النوع",t:"select",req:true,opts:[["client","عميل"],["supplier","مورد"],["subcontractor","مقاول باطن"]]},{n:"name",l:"الاسم",t:"text",req:true},{n:"contact",l:"المسؤول",t:"text"},{n:"phone",l:"الهاتف",t:"text"},{n:"email",l:"البريد",t:"text"},{n:"tax_no",l:"الرقم الضريبي",t:"text"},{n:"terms_days",l:"مدة السداد (يوم)",t:"number"}]}},
 {g:"العقود والمستخلصات",k:"contracts",files:"contract",t:"العقود",perm:"contracts.view",type:"list",url:"/contracts",
   cols:[["code","الكود"],["kind","النوع","status"],["title","العنوان"],["party_id","الطرف","ref:parties"],["original_value","الأصلية","money"],["approved_changes","التغييرات","money"],["current_value","الحالية","money"],["invoiced","المفوتر","money"],["remaining","المتبقي","money"],["status","الحالة","status"]],
   create:{l:"عقد",perm:"contracts.create",url:"/contracts",f:[{n:"code",l:"الكود",t:"text",req:true},{n:"kind",l:"النوع",t:"select",req:true,opts:[["client","عميل"],["subcontractor","مقاول باطن"],["supplier","مورد"]]},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"party_id",l:"الطرف الثاني",t:"select",req:true,src:"parties"},{n:"title",l:"العنوان",t:"text",req:true},{n:"original_value",l:"القيمة",t:"number",req:true},{n:"start_date",l:"البداية",t:"date"},{n:"end_date",l:"النهاية",t:"date"},{n:"advance_pct",l:"دفعة مقدمة %",t:"number"},{n:"retention_pct",l:"ضمان أعمال %",t:"number"},{n:"tax_pct",l:"ضريبة خصم %",t:"number"},{n:"payment_days",l:"مدة السداد (يوم)",t:"number",def:30},{n:"penalty_terms",l:"الغرامات",t:"textarea"}]},
   actions:[{l:"تفعيل",perm:"contracts.approve",when:r=>r.status==="draft",url:r=>`/contracts/${r.id}/activate`,f:[],note:"سيصبح العقد ساريًا ولا تُعدَّل قيمته إلا بأمر تغيير."}],
   kids:[
    {t:"أوامر التغيير",perm:"changeorders.view",type:"list",url:r=>`/contracts/${r.id}/change-orders`,
     cols:[["no","#","num"],["title","العنوان"],["amount","المبلغ","money"],["time_days","أيام","num"],["status","الحالة","status"],["history","السجل","len"]],
     create:{l:"أمر تغيير",perm:"changeorders.create",url:(r,c)=>`/contracts/${c.id}/change-orders`,f:[{n:"title",l:"العنوان",t:"text",req:true},{n:"reason",l:"السبب",t:"textarea",req:true},{n:"amount",l:"المبلغ (سالب للخصم)",t:"number",req:true},{n:"time_days",l:"أيام إضافية",t:"number"}]},
     actions:[{l:r=>({draft:"إرسال للمراجعة الفنية",tech_review:"اعتماد فني",fin_review:"اعتماد مالي",approval:"اعتماد نهائي"}[r.status]),perm:"changeorders.view",when:r=>["draft","tech_review","fin_review","approval"].includes(r.status),url:r=>`/change-orders/${r.id}/advance`,f:[NOTE]},
              {l:"رفض",bad:true,perm:"changeorders.view",when:r=>["tech_review","fin_review","approval"].includes(r.status),url:r=>`/change-orders/${r.id}/reject`,f:[NOTEREQ]}]},
    {t:"الدفعات المقدمة",perm:"invoices.view",type:"list",url:r=>`/contracts/${r.id}/advances`,pick:d=>d.items,
     head:d=>`<div class="card row2" style="margin-bottom:10px"><div>المستلم/المدفوع: <b>${esc(money(d.summary.received))}</b></div><div>المسترد بمستخلصات معتمدة: <b>${esc(money(d.summary.recovered))}</b></div><div>الرصيد غير المسترد: <b>${esc(money(d.summary.balance))}</b></div><div>المتاح للمستخلصات الجديدة: <b>${esc(money(d.summary.available))}</b>${Number(d.summary.unbacked_recovery)>0?` <span class="badge bad">استرداد بلا دفعة مسجّلة: ${esc(money(d.summary.unbacked_recovery))}</span>`:""}</div></div>`,
     cols:[["date","التاريخ"],["amount","المبلغ","money"],["method","الطريقة"],["ref","المرجع"],["reversed","معكوسة","num"],["reverse_reason","سبب العكس"]],
     create:{l:"دفعة مقدمة",perm:"payments.create",url:(r,c)=>`/contracts/${c.id}/advances`,f:[D("date"),{n:"amount",l:"المبلغ",t:"number",req:true},{n:"method",l:"الطريقة",t:"select",req:true,opts:[["bank","بنك"],["cash","نقدي"],["cheque","شيك"]]},{n:"ref",l:"المرجع",t:"text"}],note:"عقد عميل: استلام من العميل (دائن 2200). عقد مقاول: صرف للمقاول (مدين 1410). يُستردّ من المستخلصات بنسبة العقد وبسقف الرصيد."},
     actions:[{l:"عكس",bad:true,perm:"payments.create",when:r=>!r.reversed,m:"POST",q:true,url:r=>`/advances/${r.id}/reverse`,f:[{n:"reason",l:"سبب العكس",t:"text",req:true}]}]},
    {t:"المستخلصات",perm:"invoices.view",type:"list",files:"invoice",url:r=>`/contracts/${r.id}/invoices`,
     cols:[["no","#","num"],["date","التاريخ"],["description","البيان"],["gross","الإجمالي","money"],["advance","دفعة مقدمة","money"],["retention","ضمان","money"],["tax","ضريبة","money"],["net","الصافي","money"],["paid","المدفوع","money"],["outstanding","المتبقي","money"],["status","الحالة","status"]],
     create:{l:"مستخلص",perm:"invoices.create",url:(r,c)=>`/contracts/${c.id}/invoices`,f:[D("date"),{n:"description",l:"البيان",t:"text"},{n:"gross",l:"إجمالي المستخلص",t:"number",req:true},{n:"other",l:"استقطاعات أخرى",t:"number"},{n:"final",l:"مستخلص ختامي",t:"check"}]},
     actions:[{l:"مراجعة",perm:"invoices.review",when:r=>r.status==="draft",url:r=>`/invoices/${r.id}/review`,f:[NOTE]},
              {l:"اعتماد (يولّد القيد)",perm:"invoices.approve",when:r=>r.status==="review",url:r=>`/invoices/${r.id}/approve`,f:[NOTE]},
              {l:"رفض",bad:true,perm:"invoices.review",when:r=>["draft","review"].includes(r.status),url:r=>`/invoices/${r.id}/reject`,f:[NOTEREQ]},
              {l:"تحصيل/سداد",perm:"payments.create",when:r=>["approved","submitted"].includes(r.status),url:r=>`/invoices/${r.id}/payments`,f:[D("date"),{n:"amount",l:"المبلغ",t:"number",req:true,def:r=>r.outstanding},{n:"method",l:"الطريقة",t:"select",req:true,opts:METHODS},{n:"ref",l:"المرجع",t:"text"}]}]}]},
 {g:"العقود والمستخلصات",k:"guar",files:"guarantee",t:"خطابات الضمان",perm:"guarantees.view",type:"list",url:"/guarantees",
   cols:[["kind","النوع","status"],["project_id","المشروع","ref:projects"],["bank","البنك"],["ref","المرجع"],["amount","القيمة","money"],["remaining","المتبقي","money"],["expiry_date","الانتهاء"],["days_left","متبقٍ (يوم)","num"],["status","الحالة","status"]],
   create:{l:"ضمان",perm:"guarantees.create",url:"/guarantees",f:[{n:"kind",l:"النوع",t:"select",req:true,opts:[["bid","ابتدائي"],["performance","نهائي"],["advance","دفعة مقدمة"],["insurance","تأمين"]]},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"bank",l:"البنك",t:"text"},{n:"ref",l:"المرجع",t:"text"},{n:"amount",l:"القيمة",t:"number",req:true},{n:"issue_date",l:"الإصدار",t:"date",req:true},{n:"expiry_date",l:"الانتهاء",t:"date",req:true}]},
   actions:[{l:"إجراء",perm:"guarantees.update",when:r=>["active","renewed"].includes(r.status),url:r=>`/guarantees/${r.id}/act`,f:[{n:"action",l:"الإجراء",t:"select",req:true,opts:[["renew","تجديد"],["reduce","تخفيض"],["release","إفراج"],["claim","مصادرة"]]},{n:"new_expiry",l:"تاريخ التجديد",t:"date"},{n:"amount",l:"مبلغ التخفيض",t:"number"},REASON]}]},

 {g:"التخطيط",k:"boq",t:"المقايسات",perm:"boq.view",type:"byproject",url:c=>`/projects/${c.id}/boq`,pick:d=>d.items,
   head:d=>`<div class="card row2" style="margin-bottom:10px"><div>التكلفة المباشرة: <b>${esc(money(d.direct_cost))}</b></div><div>المنفذ: <b>${esc(money(d.executed_value))}</b> (${esc(d.progress_pct??"-")}%)</div>${d.over_executed.length?`<div class="err" style="grid-column:1/-1">تنبيه: كمية منفذة تتجاوز المقايسة في: ${esc(d.over_executed.join("، "))}</div>`:""}</div>`,
   cols:[["section","القسم"],["description","البند"],["unit","الوحدة"],["qty","الكمية","num"],["price","السعر","money"],["total","الإجمالي","money"],["done","المنفذ","num"],["done_pct","%","num"],["done_value","قيمة المنفذ","money"]],
   create:{l:"بند",perm:"boq.create",url:(r,c)=>`/projects/${c.id}/boq`,f:[{n:"section",l:"القسم",t:"text"},{n:"description",l:"وصف البند",t:"text",req:true},{n:"unit",l:"الوحدة",t:"text"},{n:"qty",l:"الكمية",t:"number",req:true},{n:"price",l:"سعر الوحدة",t:"number",req:true}]},
   tools:[{l:"استيراد CSV/XLSX",sec:true,perm:"boq.import",url:(r,c)=>`/projects/${c.id}/boq/import`,f:[{n:"file",l:"الأعمدة: section,description,unit,qty,price",t:"file",req:true,accept:".csv,.xlsx"}]}],
   actions:[{l:"تحديث المنفذ",perm:"boq.update",m:"PATCH",url:r=>"/boq/"+r.id,f:[{n:"done",l:"الكمية المنفذة (تراكمي)",t:"number",req:true,def:r=>r.done}],body:(v,r)=>({...v,version:r.version})},
            {l:"تعديل",perm:"boq.update",m:"PATCH",url:r=>"/boq/"+r.id,f:[{n:"description",l:"الوصف",t:"text",def:r=>r.description},{n:"qty",l:"الكمية",t:"number",def:r=>r.qty},{n:"price",l:"السعر",t:"number",def:r=>r.price},REASON],body:(v,r)=>({...v,version:r.version})},
            {l:"حذف",bad:true,perm:"boq.delete",m:"DELETE",q:true,url:r=>"/boq/"+r.id,f:[REASON]}]},

 {g:"التخطيط",k:"budget",t:"الميزانية التقديرية",perm:"budget.view",type:"byproject",url:c=>`/projects/${c.id}/budget`,pick:d=>d.rows,
   head:d=>`<div class="card row2" style="margin-bottom:10px"><div>إجمالي الموازنة: <b>${esc(money(d.total_budget))}</b></div><div>الفعلي: <b>${esc(money(d.total_actual))}</b>${d.used_pct!==null?` (${esc(d.used_pct)}%)`:""}</div><div>الإنجاز (المقايسة): <b>${esc(d.progress_pct??"—")}${d.progress_pct!==null?"%":""}</b></div><div>التكلفة المتوقعة عند الإنجاز: <b>${esc(money(d.forecast_total))}</b></div><div>قيمة العقد: <b>${esc(money(d.contract_value))}</b></div><div>الربح المتوقع: <b>${d.forecast_profit===null?"—":esc(money(d.forecast_profit))}</b></div>${Number(d.unmapped_cost)>0?`<div class="muted" style="grid-column:1/-1">تكاليف على حسابات غير مبوّبة بفئة: ${esc(money(d.unmapped_cost))}</div>`:""}<div class="muted" style="grid-column:1/-1">أساس التوقع: ${esc(d.forecast_basis)}</div></div>`,
   cols:[["name","الفئة"],["budget","الموازنة","money"],["actual","الفعلي","money"],["variance","الفرق","money"],["used_pct","% مستهلك","num"],["forecast","المتوقع عند الإنجاز","money"],["status","الحالة","status"]],
   tools:[{l:"تحديد/تعديل الموازنة",perm:"budget.edit",custom:async(r,done,ctx)=>{
     const d=await api("GET",`/projects/${ctx.id}/budget`),has=d.total_budget>0;
     await form("موازنة: "+d.project,[...d.rows.map(x=>({n:"c_"+x.category,l:x.name,t:"number",def:x.budget>0?x.budget:""})),...(has?[{n:"reason",l:"سبب التعديل (إلزامي)",t:"text",req:true}]:[])],
       async v=>{const lines=d.rows.filter(x=>v["c_"+x.category]!==""&&v["c_"+x.category]!==null&&v["c_"+x.category]!==undefined).map(x=>({category:x.category,amount:v["c_"+x.category]}));
         if(!lines.length)throw new Error("أدخل موازنة فئة واحدة على الأقل");await api("PUT",`/projects/${ctx.id}/budget`,{version:d.version,lines,reason:v.reason||""});toast("تم الحفظ");await loadRefs();await done()},
       {note:"اترك الفئة فارغة إن لم تكن لها موازنة. الفعلي يُقرأ من دفتر الأستاذ بحسب المشروع."})}}]},
 {g:"التخطيط",k:"sched",t:"الجدول الزمني",perm:"schedule.view",type:"byproject",url:c=>`/projects/${c.id}/tasks`,pick:d=>d.tasks,
   head:d=>`<div class="card row2" style="margin-bottom:10px"><div>الإنجاز المرجَّح بالمدة: <b>${esc(d.progress_pct??"-")}%</b></div><div>من ${esc(d.planned_start||"-")} إلى ${esc(d.planned_end||"-")}</div>${d.delayed.length?`<div class="err" style="grid-column:1/-1">مهام متأخرة: ${esc(d.delayed.join("، "))}</div>`:""}</div>`,
   cols:[["name","المهمة"],["start","البدء"],["end","الانتهاء"],["days","الأيام","num"],["progress","الإنجاز %","num"],["delayed","متأخرة","num"]],
   create:{l:"مهمة",perm:"schedule.create",url:(r,c)=>`/projects/${c.id}/tasks`,f:[{n:"name",l:"اسم المهمة",t:"text",req:true},{n:"start",l:"البدء",t:"date",req:true},{n:"end",l:"الانتهاء",t:"date",req:true},{n:"progress",l:"الإنجاز %",t:"number"}]},
   actions:[{l:"تحديث الإنجاز",perm:"schedule.update",m:"PATCH",url:r=>"/tasks/"+r.id,f:[{n:"progress",l:"الإنجاز %",t:"number",req:true,def:r=>r.progress}],body:(v,r)=>({...v,version:r.version})},
            {l:"تغيير المواعيد",perm:"schedule.update",m:"PATCH",url:r=>"/tasks/"+r.id,f:[{n:"start",l:"البدء",t:"date",def:r=>r.start},{n:"end",l:"الانتهاء",t:"date",def:r=>r.end},REASON],body:(v,r)=>({...v,version:r.version})},
            {l:"حذف",bad:true,perm:"schedule.delete",m:"DELETE",q:true,url:r=>"/tasks/"+r.id,f:[REASON]}]},

 {g:"المناقصات",k:"tenders",files:"tender",t:"المناقصات والعطاءات",perm:"tenders.view",type:"list",url:"/tenders",
   cols:[["name","العطاء"],["client_id","العميل","ref:parties"],["type","النوع"],["due","موعد التقديم"],["days_to_due","متبقٍ (يوم)","num"],["value","سعر العرض","money"],["cost","التكلفة المقدرة","money"],["margin_pct","الهامش %","num"],["stage","المرحلة","status"],["project_id","المشروع","ref:projects"]],
   create:{l:"عطاء",perm:"tenders.create",url:"/tenders",f:[{n:"name",l:"اسم العطاء",t:"text",req:true},{n:"client_id",l:"العميل",t:"select",src:"clients"},{n:"type",l:"نوع الأعمال",t:"text"},{n:"due",l:"موعد التقديم",t:"date"},{n:"value",l:"سعر العرض",t:"number"},{n:"cost",l:"التكلفة المقدرة",t:"number"},{n:"note",l:"ملاحظات",t:"textarea"}]},
   actions:[{l:"تغيير المرحلة",perm:"tenders.update",when:r=>!r.project_id,m:"PATCH",url:r=>"/tenders/"+r.id,f:[{n:"stage",l:"المرحلة",t:"select",req:true,def:r=>r.stage,opts:[["study","قيد الدراسة"],["submitted","تم التقديم"],["negotiation","تفاوض"],["won","فائزة"],["lost","خاسرة"]]},{n:"reason",l:"السبب (إلزامي عند الخسارة)",t:"text"}],body:(v,r)=>({...v,version:r.version})},
            {l:"تعديل",perm:"tenders.update",when:r=>!r.project_id,m:"PATCH",url:r=>"/tenders/"+r.id,f:[{n:"name",l:"الاسم",t:"text",def:r=>r.name},{n:"due",l:"موعد التقديم",t:"date",def:r=>r.due},{n:"value",l:"سعر العرض",t:"number",def:r=>r.value},{n:"cost",l:"التكلفة",t:"number",def:r=>r.cost},{n:"reason",l:"السبب (إلزامي بعد التقديم)",t:"text"}],body:(v,r)=>({...v,version:r.version})},
            {l:"تحويل لمشروع وعقد",perm:"tenders.convert",when:r=>r.stage==="won"&&!r.project_id,url:r=>`/tenders/${r.id}/convert`,f:[{n:"project_code",l:"كود المشروع",t:"text",req:true},{n:"contract_code",l:"كود العقد",t:"text",req:true}],note:"يُنشأ المشروع وعقد عميل مسودة بقيمة العرض، ويُكمَل العقد ويُفعَّل من صفحة العقود."},
            {l:"حذف",bad:true,perm:"tenders.delete",when:r=>!r.project_id,m:"DELETE",q:true,url:r=>"/tenders/"+r.id,f:[REASON]}]},
 {g:"الجودة والتسليم",k:"insp",files:"inspection",t:"طلبات الفحص",perm:"quality.view",type:"list",url:"/inspections",
   cols:[["ref","المرجع"],["project_id","المشروع","ref:projects"],["item","البند"],["kind","النوع","status"],["date","التاريخ"],["inspector","المفتش"],["status","النتيجة","status"],["note","الملاحظات"]],
   create:{l:"طلب فحص",perm:"quality.create",url:"/inspections",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"item",l:"البند المطلوب فحصه",t:"text",req:true},{n:"kind",l:"النوع",t:"select",req:true,opts:[["work","تنفيذ"],["material","مواد"]]},D("date"),{n:"inspector",l:"المفتش/الاستشاري",t:"text"}]},
   actions:[{l:"تسجيل النتيجة",perm:"quality.decide",when:r=>r.status==="pending",url:r=>`/inspections/${r.id}/decide`,f:[{n:"result",l:"النتيجة",t:"select",req:true,opts:[["accepted","مقبول"],["accepted_notes","مقبول بملاحظات"],["rejected","مرفوض"]]},{n:"note",l:"الملاحظات (إلزامية عند غير المقبول)",t:"textarea"},{n:"due",l:"موعد المعالجة",t:"date"}],note:"القبول بملاحظات أو الرفض يفتح ملاحظة جودة (NCR) تلقائيًا."}]},
 {g:"الجودة والتسليم",k:"snags",files:"snag",t:"ملاحظات الجودة",perm:"quality.view",type:"list",url:"/snags",
   cols:[["ref","المرجع"],["project_id","المشروع","ref:projects"],["location","الموقع"],["description","الوصف"],["severity","الخطورة","status"],["due","موعد المعالجة"],["overdue","متأخرة","num"],["status","الحالة","status"]],
   create:{l:"ملاحظة",perm:"quality.create",url:"/snags",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"location",l:"الموقع داخل المشروع",t:"text",req:true},{n:"description",l:"الوصف",t:"textarea",req:true},{n:"severity",l:"الخطورة",t:"select",req:true,opts:[["low","منخفضة"],["medium","متوسطة"],["high","عالية"]]},{n:"due",l:"موعد المعالجة",t:"date"},{n:"responsible",l:"المسؤول عن المعالجة",t:"text"}]},
   actions:[{l:"إغلاق",perm:"quality.close",when:r=>r.status==="open",url:r=>`/snags/${r.id}/act`,f:[{n:"note",l:"ما تم لمعالجتها",t:"text",req:true}],body:(v,r)=>({action:"close",note:v.note,version:r.version})},
            {l:"إعادة فتح",bad:true,perm:"quality.close",when:r=>r.status==="closed",url:r=>`/snags/${r.id}/act`,f:[{n:"note",l:"السبب",t:"text",req:true}],body:(v,r)=>({action:"reopen",note:v.note,version:r.version})}]},
 {g:"الجودة والتسليم",k:"ho",files:"handover",t:"محاضر الاستلام",perm:"handover.view",type:"list",url:"/handovers",
   pick:d=>d.map(h=>({...h,prog:h.checklist.filter(x=>x.done).length+"/"+h.checklist.length})),
   cols:[["project_id","المشروع","ref:projects"],["kind","النوع","status"],["status","الحالة","status"],["prog","البنود المستوفاة","num"],["open_snags","ملاحظات مفتوحة","num"],["date","تاريخ الاستلام"],["warranty_months","الصيانة (شهر)","num"],["warranty_end","نهاية الصيانة"]],
   create:{l:"محضر استلام",perm:"handover.create",url:"/handovers",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"kind",l:"النوع",t:"select",req:true,opts:[["initial","ابتدائي"],["final","نهائي"]]},{n:"warranty_months",l:"مدة الصيانة (شهر)",t:"number"}]},
   actions:[{l:"استيفاء بند",perm:"handover.check",when:r=>r.status==="in_progress"&&r.checklist.some(x=>!x.done),url:r=>`/handovers/${r.id}/check`,f:r=>[{n:"index",l:"البند",t:"select",req:true,opts:()=>r.checklist.filter(x=>!x.done).map(x=>[x.i,x.text])}],body:v=>({index:Number(v.index),value:true})},
            {l:"سحب استيفاء",perm:"handover.check",when:r=>r.status==="in_progress"&&r.checklist.some(x=>x.done),url:r=>`/handovers/${r.id}/check`,f:r=>[{n:"index",l:"البند",t:"select",req:true,opts:()=>r.checklist.filter(x=>x.done).map(x=>[x.i,x.text])}],body:v=>({index:Number(v.index),value:false})},
            {l:"اعتماد الاستلام",perm:"handover.complete",when:r=>r.status==="in_progress",url:r=>`/handovers/${r.id}/complete`,f:[D("date"),{n:"override_reason",l:"سبب التجاوز (للمدير فقط، عند وجود مانع)",t:"text"}],note:"يتطلب استيفاء كل البنود وإغلاق كل ملاحظات المشروع. النهائي يتطلب ابتدائيًا معتمدًا وانتهاء الصيانة ومستخلصًا ختاميًا معتمدًا."}]},

 {g:"الموقع",k:"dr",files:"daily_report",t:"التقارير اليومية",perm:"site.view",type:"list",url:"/daily-reports",
   cols:[["date","التاريخ"],["project_id","المشروع","ref:projects"],["weather","الطقس"],["workers_count","العمالة","num"],["work","الأعمال المنفذة"],["issues","المعوقات"]],
   create:{l:"تقرير يومي",perm:"site.create",url:"/daily-reports",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},D("date"),{n:"weather",l:"الطقس",t:"text"},{n:"workers_count",l:"عدد العمالة",t:"number"},{n:"work",l:"الأعمال المنفذة",t:"textarea",req:true},{n:"issues",l:"المعوقات",t:"textarea"}]},
   actions:[{l:"تعديل",perm:"site.update",m:"PATCH",url:r=>"/daily-reports/"+r.id,f:[{n:"work",l:"الأعمال",t:"textarea",def:r=>r.work},{n:"issues",l:"المعوقات",t:"textarea",def:r=>r.issues},{n:"workers_count",l:"العمالة",t:"number",def:r=>r.workers_count},REASON],body:(v,r)=>({...v,version:r.version})}]},
 {g:"الموقع",k:"safety",files:"safety",t:"السلامة والصحة المهنية",perm:"site.view",type:"list",url:"/safety",
   cols:[["date","التاريخ"],["project_id","المشروع","ref:projects"],["kind","النوع","status"],["severity","الخطورة","status"],["description","الوصف"],["action","الإجراء التصحيحي"],["status","الحالة","status"]],
   create:{l:"بلاغ/تفتيش",perm:"site.create",url:"/safety",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},D("date"),{n:"kind",l:"النوع",t:"select",req:true,opts:[["inspection","تفتيش"],["accident","حادث"],["near_miss","شبه حادث"]]},{n:"severity",l:"الخطورة",t:"select",req:true,opts:[["low","منخفضة"],["medium","متوسطة"],["high","عالية"]]},{n:"description",l:"الوصف",t:"textarea",req:true},{n:"action",l:"إجراء فوري (اختياري)",t:"text"}]},
   actions:[{l:"إغلاق",perm:"site.update",when:r=>r.status==="open",url:r=>`/safety/${r.id}/close`,f:[{n:"action",l:"الإجراء التصحيحي المتخذ",t:"text",req:true}],body:(v,r)=>({action:v.action,version:r.version})}]},
 {g:"الموقع",k:"risks",t:"سجل المخاطر",perm:"risks.view",type:"list",url:"/risks",
   cols:[["project_id","المشروع","ref:projects"],["description","الخطر"],["prob","الاحتمال","num"],["impact","الأثر","num"],["score","الدرجة","num"],["level","المستوى","status"],["owner","المسؤول"],["mitigation","المعالجة"],["status","الحالة","status"]],
   create:{l:"خطر",perm:"risks.create",url:"/risks",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"description",l:"وصف الخطر",t:"textarea",req:true},{n:"prob",l:"الاحتمال (1-5)",t:"number",req:true},{n:"impact",l:"الأثر (1-5)",t:"number",req:true},{n:"owner",l:"المسؤول",t:"text"},{n:"mitigation",l:"خطة المعالجة",t:"textarea"}]},
   actions:[{l:"تحديث",perm:"risks.update",m:"PATCH",url:r=>"/risks/"+r.id,f:[{n:"prob",l:"الاحتمال",t:"number",def:r=>r.prob},{n:"impact",l:"الأثر",t:"number",def:r=>r.impact},{n:"mitigation",l:"المعالجة",t:"textarea",def:r=>r.mitigation},{n:"status",l:"الحالة",t:"select",req:true,def:r=>r.status,opts:[["open","مفتوح"],["mitigated","مخفَّف"],["closed","مغلق"]]},REASON],body:(v,r)=>({...v,version:r.version})}]},
 {g:"الموقع",k:"docs",files:"document",t:"المستندات والتراخيص",perm:"docs.view",type:"list",url:"/documents",
   cols:[["name","المستند"],["doc_type","النوع"],["project_id","المشروع","ref:projects"],["issue_date","الإصدار"],["expiry_date","الانتهاء"],["days_to_expiry","متبقٍ (يوم)","num"]],
   create:{l:"مستند",perm:"docs.create",url:"/documents",f:[{n:"name",l:"الاسم",t:"text",req:true},{n:"doc_type",l:"النوع",t:"text",req:true,def:"عقد"},{n:"project_id",l:"المشروع",t:"select",src:"projects"},{n:"issue_date",l:"تاريخ الإصدار",t:"date"},{n:"expiry_date",l:"تاريخ الانتهاء",t:"date"}]},
   actions:[{l:"حذف",bad:true,perm:"docs.delete",m:"DELETE",q:true,url:r=>"/documents/"+r.id,f:[REASON]}]},
 {g:"الموقع",k:"corr",files:"correspondence",t:"المراسلات",perm:"docs.view",type:"list",url:"/correspondence",
   cols:[["direction","الاتجاه","status"],["ref_no","الرقم"],["date","التاريخ"],["party","الجهة"],["subject","الموضوع"],["due","موعد الرد"],["overdue","متأخرة","num"],["status","الحالة","status"]],
   create:{l:"مراسلة",perm:"docs.create",url:"/correspondence",f:[{n:"direction",l:"الاتجاه",t:"select",req:true,opts:[["in","وارد"],["out","صادر"]]},{n:"ref_no",l:"الرقم",t:"text",req:true},D("date"),{n:"party",l:"الجهة",t:"text",req:true},{n:"project_id",l:"المشروع",t:"select",src:"projects"},{n:"subject",l:"الموضوع",t:"text",req:true},{n:"due",l:"موعد الرد",t:"date"}]},
   actions:[{l:"إغلاق",perm:"docs.update",when:r=>r.status==="open",url:r=>`/correspondence/${r.id}/close`,f:[{n:"note",l:"ما تم بشأنها",t:"text",req:true}],body:(v,r)=>({note:v.note,version:r.version})}]},
 {g:"الموارد",k:"equip",files:"equipment",t:"المعدات",perm:"equipment.view",type:"list",url:"/equipment",
   cols:[["name","المعدة"],["type","النوع"],["daily_rate","الأجر اليومي","money"],["status","الحالة","status"],["last_maint","آخر صيانة"],["next_maint","الصيانة القادمة"],["maint_overdue","متأخرة","num"]],
   create:{l:"معدة",perm:"equipment.create",url:"/equipment",f:[{n:"name",l:"الاسم",t:"text",req:true},{n:"type",l:"النوع",t:"text"},{n:"daily_rate",l:"الأجر اليومي",t:"number"},{n:"maint_interval_days",l:"دورة الصيانة (يوم)",t:"number",def:90},{n:"last_maint",l:"آخر صيانة",t:"date"}]},
   tools:[{l:"تسجيل تشغيل",perm:"equipment.usage",url:"/equipment/usage",f:[{n:"equipment_id",l:"المعدة",t:"select",req:true,opts:()=>Object.entries(EQN)},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},D("date"),{n:"days",l:"عدد الأيام",t:"number",req:true,def:1}]}],
   actions:[{l:"تسجيل صيانة",perm:"equipment.update",url:r=>`/equipment/${r.id}/maintenance`,f:[D("date"),{n:"note",l:"ما تم",t:"text",req:true}]},
            {l:"تغيير الحالة/الأجر",perm:"equipment.update",m:"PATCH",url:r=>"/equipment/"+r.id,f:[{n:"status",l:"الحالة",t:"select",req:true,def:r=>r.status,opts:[["working","يعمل"],["maintenance","صيانة"],["idle","متوقف"]]},{n:"daily_rate",l:"الأجر اليومي",t:"number",def:r=>r.daily_rate},{n:"reason",l:"السبب (إلزامي عند تغيير الأجر)",t:"text"}],body:(v,r)=>({...v,version:r.version})}]},
 {g:"الموارد",k:"workers",t:"العمالة اليومية",perm:"labor.view",type:"list",url:"/workers",
   cols:[["name","العامل"],["trade","المهنة"],["daily_rate","الأجر اليومي","money"],["unpaid","مستحق غير مسدد","money"],["active","نشط","num"]],
   create:{l:"عامل",perm:"labor.create",url:"/workers",f:[{n:"name",l:"الاسم",t:"text",req:true},{n:"trade",l:"المهنة",t:"text"},{n:"daily_rate",l:"الأجر اليومي",t:"number",req:true}]},
   tools:[{l:"تسجيل يوم عمل",perm:"labor.record",url:"/labor/days",f:[{n:"worker_id",l:"العامل",t:"select",req:true,opts:()=>Object.entries(WKN)},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},D("date"),{n:"days",l:"الأيام (حتى 2)",t:"number",req:true,def:1}]},
          {l:"سداد الأجور (يولّد القيود)",sec:true,perm:"labor.pay",url:"/labor/pay",f:[D("date"),{n:"up_to",l:"عن الأيام حتى",t:"date",req:true,def:new Date().toISOString().slice(0,10)},{n:"method",l:"الطريقة",t:"select",req:true,opts:[["cash","نقدي"],["bank","بنك"]]}],note:"يُسدَّد كل ما لم يُسدَّد حتى التاريخ، ويُنشأ قيد لكل مشروع."}],
   actions:[{l:"تعديل الأجر/الإيقاف",perm:"labor.create",m:"PATCH",url:r=>"/workers/"+r.id,f:[{n:"daily_rate",l:"الأجر اليومي",t:"number",def:r=>r.daily_rate},{n:"active",l:"نشط",t:"check",def:r=>r.active},REASON],body:(v,r)=>({...v,version:r.version})}]},
 {g:"الموارد",k:"custody",files:"custody",t:"العهد",perm:"custody.view",type:"list",url:"/custodies",
   cols:[["date","التاريخ"],["person","المستلم"],["project_id","المشروع","ref:projects"],["amount","القيمة","money"],["spent","المصروف","money"],["remaining","المتبقي","money"],["age_days","العمر (يوم)","num"],["settled","مسوّاة","num"]],
   create:{l:"صرف عهدة",perm:"custody.create",url:"/custodies",f:[{n:"person",l:"المستلم",t:"text",req:true},{n:"project_id",l:"المشروع",t:"select",src:"projects"},{n:"amount",l:"القيمة",t:"number",req:true},D("date"),{n:"method",l:"الطريقة",t:"select",req:true,opts:[["cash","نقدي"],["bank","بنك"]]}]},
   actions:[{l:"تسجيل مصروف",perm:"custody.expense",when:r=>!r.settled,url:r=>`/custodies/${r.id}/expenses`,f:[D("date"),{n:"category",l:"البند",t:"select",req:true,opts:[["materials","مواد"],["labor","عمالة"],["equipment","معدات"],["admin","إدارية"],["other","أخرى"]]},{n:"description",l:"البيان",t:"text",req:true},{n:"amount",l:"المبلغ",t:"number",req:true}]},
            {l:"تسوية (رد الباقي)",perm:"custody.settle",when:r=>!r.settled,url:r=>`/custodies/${r.id}/settle`,f:[D("date"),{n:"method",l:"طريقة رد الباقي",t:"select",req:true,opts:[["cash","نقدي"],["bank","بنك"]]}]}]},
 {g:"المحاسبة",k:"ledger",t:"قيود اليومية",perm:"ledger.view",type:"list",url:"/ledger/entries",
   cols:[["no","#","num"],["date","التاريخ"],["description","البيان"],["source","المصدر","status"],["lines","الأسطر","len"]],
   create:{l:"قيد يدوي",perm:"ledger.create",url:"/ledger/entries",f:[D("date"),{n:"description",l:"البيان",t:"text",req:true},{n:"project_id",l:"المشروع",t:"select",src:"projects"},{n:"lines",l:"الأسطر (مدين أو دائن)",t:"rows",rows:[{n:"account_code",l:"الحساب",t:"select",req:true,src:"accounts"},{n:"debit",l:"مدين",t:"number"},{n:"credit",l:"دائن",t:"number"}]}]},
   actions:[{l:"عكس القيد",bad:true,perm:"ledger.reverse",when:r=>!r.reverses_id,m:"POST",q:true,url:r=>`/ledger/entries/${r.id}/reverse`,f:[REASON],note:"القيود لا تُحذف؛ يُنشأ قيد عكسي مرتبط بالأصل."}],
   tools:[{l:"قفل الفترة المالية",perm:"ledger.close",sec:true,m:"PUT",url:"/ledger/period-lock",f:[{n:"lock_date",l:"قفل حتى تاريخ",t:"date",req:true},REASON]}]},
 {g:"المحاسبة",k:"rep",t:"التقارير المالية",perm:"reports.view",type:"multi",tabs:[
   {t:"ميزان المراجعة",url:"/ledger/trial-balance",perm:"ledger.view"},
   {t:"قائمة الدخل",url:"/reports/income-statement",params:[{n:"frm",l:"من",t:"date"},{n:"to",l:"إلى",t:"date"},{n:"project_id",l:"المشروع",t:"select",src:"projects"}]},
   {t:"الميزانية العمومية",url:"/reports/balance-sheet",params:[{n:"as_of",l:"كما في",t:"date"}]},
   {t:"دفتر الأستاذ",url:"/reports/general-ledger/{code}",params:[{n:"code",l:"الحساب",t:"select",req:true,src:"accounts"},{n:"frm",l:"من",t:"date"},{n:"to",l:"إلى",t:"date"}]},
   {t:"التدفق النقدي",url:"/reports/cashflow",perm:"cashflow.view"},
   {t:"ملخص مشروع",url:"/reports/project/{pid}",params:[{n:"pid",l:"المشروع",t:"select",req:true,src:"projects"}]},
   {t:"أعمار الديون",url:"/executive/aging",perm:"executive.view"},
   {t:"خط العطاءات",url:"/tenders/pipeline/summary",perm:"tenders.view"},
   {t:"تكلفة المعدات",url:"/reports/equipment-cost",perm:"equipment.view"},
   {t:"الموازنة مقابل الفعلي",url:"/reports/budget-vs-actual",perm:"budget.view"},
   {t:"التنبيهات",url:"/reports/alerts"}]},
 {g:"المشتريات والمخزون",k:"items",t:"الأصناف والمخزون",perm:"items.view",type:"list",url:"/items",
   cols:[["code","الكود"],["name","الصنف"],["unit","الوحدة"],["qty","الكمية","num"],["min_stock","الحد الأدنى","num"],["avg_cost","متوسط التكلفة","money"],["value","القيمة","money"],["low","تحت الحد","num"]],
   create:{l:"صنف",perm:"items.create",url:"/items",f:[{n:"code",l:"الكود",t:"text",req:true},{n:"name",l:"الاسم",t:"text",req:true},{n:"unit",l:"الوحدة",t:"text"},{n:"min_stock",l:"الحد الأدنى",t:"number"}]},
   tools:[{l:"صرف لمشروع",perm:"stock.issue",url:"/stock/issue",f:[{n:"item_id",l:"الصنف",t:"select",req:true,src:"items"},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"qty",l:"الكمية",t:"number",req:true},D("date"),{n:"note",l:"ملاحظة",t:"text"}]},
          {l:"تسوية جرد",sec:true,perm:"stock.adjust",url:"/stock/adjust",f:[{n:"item_id",l:"الصنف",t:"select",req:true,src:"items"},{n:"counted_qty",l:"الكمية بعد الجرد",t:"number",req:true},D("date"),{n:"unit_cost",l:"تكلفة الوحدة (لصنف رصيده صفر)",t:"number"},REASON]}]},
 {g:"المشتريات والمخزون",k:"pr",t:"طلبات الشراء",perm:"items.view",type:"list",url:"/purchase-requests",
   cols:[["no","#","num"],["project_id","المشروع","ref:projects"],["status","الحالة","status"],["lines","البنود","len"],["note","ملاحظة"]],
   create:{l:"طلب شراء",perm:"purchasing.pr_create",url:"/purchase-requests",f:[{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"lines",l:"البنود",t:"rows",rows:[{n:"item_id",l:"الصنف",t:"select",req:true,src:"items"},{n:"qty",l:"الكمية",t:"number",req:true},{n:"note",l:"ملاحظة",t:"text"}]},{n:"note",l:"ملاحظة",t:"text"}]},
   actions:[{l:"اعتماد",perm:"purchasing.pr_approve",when:r=>r.status==="pending",url:r=>`/purchase-requests/${r.id}/decide`,f:[],body:()=>({approve:true})},
            {l:"رفض",bad:true,perm:"purchasing.pr_approve",when:r=>r.status==="pending",url:r=>`/purchase-requests/${r.id}/decide`,f:[NOTEREQ],body:v=>({approve:false,note:v.note})}]},

 {g:"المشتريات والمخزون",k:"vendors",t:"تقييم الموردين والمقاولين",perm:"ratings.view",type:"list",url:"/reports/vendor-ratings",
   cols:[["name","الجهة"],["kind","النوع","status"],["count","عدد التقييمات","num"],["quality","الجودة","num"],["punctuality","الالتزام بالمواعيد","num"],["price","السعر/القيمة","num"],["overall","المتوسط العام","num"]],
   actions:[{l:"تقييم جديد",perm:"ratings.create",url:r=>"/ratings",f:[D("date"),{n:"quality",l:"الجودة",t:"select",req:true,def:"4",opts:[["5","5 - ممتاز"],["4","4 - جيد جدًا"],["3","3 - مقبول"],["2","2 - ضعيف"],["1","1 - سيئ"]]},{n:"punctuality",l:"الالتزام بالمواعيد",t:"select",req:true,def:"4",opts:[["5","5 - ممتاز"],["4","4 - جيد جدًا"],["3","3 - مقبول"],["2","2 - ضعيف"],["1","1 - سيئ"]]},{n:"price",l:"السعر مقابل القيمة",t:"select",req:true,def:"4",opts:[["5","5 - ممتاز"],["4","4 - جيد جدًا"],["3","3 - مقبول"],["2","2 - ضعيف"],["1","1 - سيئ"]]},{n:"note",l:"ملاحظات",t:"text"}],
     body:(v,r)=>({party_id:r.party_id,date:v.date,quality:+v.quality,punctuality:+v.punctuality,price:+v.price,note:v.note||""})}]},
 {g:"المشتريات والمخزون",k:"rfq",t:"طلبات الأسعار",perm:"rfq.view",type:"list",url:"/rfqs",
   cols:[["no","#","num"],["item","الصنف"],["qty","الكمية","num"],["unit","الوحدة"],["project_id","المشروع","ref:projects"],["quotes_count","العروض","num"],["lowest","الأقل سعرًا"],["awarded_name","الجهة المرسّى عليها"],["status","الحالة","status"]],
   create:{l:"طلب أسعار",perm:"rfq.create",url:"/rfqs",f:[{n:"item",l:"الصنف",t:"text",req:true},{n:"unit",l:"الوحدة",t:"text",def:"طن"},{n:"qty",l:"الكمية",t:"number",req:true},{n:"project_id",l:"المشروع (اختياري)",t:"select",src:"projects"}]},
   actions:[{l:"إضافة عرض سعر",perm:"rfq.update",when:r=>r.status==="open",url:r=>`/rfqs/${r.id}/quotes`,f:[{n:"party_id",l:"المورد",t:"select",req:true,src:"suppliers"},{n:"price",l:"سعر الوحدة",t:"number",req:true},{n:"note",l:"ملاحظات",t:"text"}],body:(v,r)=>({...v,version:r.version})},
            {l:"عرض العروض",view:r=>r.quotes.length?`<div class="tw"><table><thead><tr><th>المورد</th><th>سعر الوحدة</th><th>الإجمالي</th><th>ملاحظات</th></tr></thead><tbody>${r.quotes.map((q,i)=>`<tr><td>${esc(q.name)}${i===0?' <span class="badge good">الأقل</span>':""}</td><td class="n">${esc(money(q.price))}</td><td class="n">${esc(money(q.total))}</td><td>${esc(q.note||"")}</td></tr>`).join("")}</tbody></table></div>`:"<p class=\"muted\">لا عروض بعد</p>"},
            {l:"ترسية",perm:"rfq.update",when:r=>r.status==="open"&&r.quotes.length>0,url:r=>`/rfqs/${r.id}/award`,f:r=>[{n:"party_id",l:"المورد",t:"select",req:true,def:r.quotes[0]&&r.quotes[0].party_id,opts:()=>r.quotes.map(q=>[q.party_id,q.name+" — "+money(q.price)])},{n:"reason",l:"السبب (إلزامي إن لم يكن الأقل سعرًا)",t:"text"}],body:(v,r)=>({...v,version:r.version}),note:"لا يُنشأ أمر شراء تلقائيًا؛ أنشئه من شاشة أوامر الشراء بعد الترسية."},
            {l:"إلغاء",bad:true,perm:"rfq.update",when:r=>r.status==="open",m:"POST",q:true,url:r=>`/rfqs/${r.id}/cancel`,f:[{n:"reason",l:"سبب الإلغاء",t:"text",req:true}],body:null,pre:r=>({version:r.version})}]},
 {g:"المشتريات والمخزون",k:"counts",t:"الجرد المخزني",perm:"stockcount.view",type:"list",url:"/stock-counts",
   cols:[["no","#","num"],["date","التاريخ"],["status","الحالة","status"],["counted","المعدود","num"],["total","الأصناف","num"],["variances","فروق","num"],["net_value","قيمة الفروق","money"],["note","ملاحظات"]],
   create:{l:"جرد جديد",perm:"stockcount.create",url:"/stock-counts",f:[D("date"),{n:"note",l:"ملاحظات",t:"text"}],note:"يُسجَّل رصيد النظام لكل الأصناف النشطة لحظة البدء. إن تحرك صنف قبل الاعتماد يُطلب عدّه من جديد."},
   actions:[{l:"إدخال العدّ",perm:"stockcount.create",when:r=>r.status==="draft",custom:async (r,done)=>{
              const c=await api("GET","/stock-counts/"+r.id);
              await form("إدخال العدّ — جرد #"+c.no,c.lines.flatMap(l=>{const f=[{n:"i_"+l.item_id,l:`${l.code} — ${l.name} (رصيد النظام: ${l.system_qty} ${l.unit||""})`,t:"number",def:l.counted_qty===null?"":l.counted_qty}];if(Number(l.system_qty)===0)f.push({n:"u_"+l.item_id,l:`تكلفة الوحدة (لصنف رصيده صفر) — ${l.code}`,t:"number",def:l.unit_cost===null||l.unit_cost===undefined?"":l.unit_cost});return f}),
                async v=>{const lines=c.lines.filter(l=>v["i_"+l.item_id]!==""&&v["i_"+l.item_id]!==null&&v["i_"+l.item_id]!==undefined).map(l=>({item_id:l.item_id,counted_qty:v["i_"+l.item_id],...(v["u_"+l.item_id]!==""&&v["u_"+l.item_id]!==undefined&&v["u_"+l.item_id]!==null?{unit_cost:v["u_"+l.item_id]}:{})}));
                  if(!lines.length)throw new Error("أدخل عدّ صنف واحد على الأقل");await api("PUT",`/stock-counts/${r.id}/lines`,{version:c.version,lines});toast("تم الحفظ");await done()},{note:"اترك الصنف فارغًا إن لم تعدّه."})}},
            {l:"عرض الفروق",custom:async r=>{const c=await api("GET","/stock-counts/"+r.id),md=$("#md");
              md.innerHTML=`<h2>جرد #${c.no} — ${esc(AR[c.status]||c.status)}</h2><div class="tw"><table><thead><tr><th>الصنف</th><th>رصيد النظام</th><th>المعدود</th><th>الفرق</th><th>القيمة التقديرية</th></tr></thead><tbody>${c.lines.map(l=>`<tr><td>${esc(l.code)} — ${esc(l.name)}</td><td class="n">${esc(String(l.system_qty))}</td><td class="n">${l.counted_qty===null?"—":esc(String(l.counted_qty))}</td><td class="n ${l.diff&&Number(l.diff)<0?"neg":""}">${l.diff===null?"":esc(String(l.diff))}</td><td class="n">${l.est_value===null?"":esc(money(l.est_value))}</td></tr>`).join("")}</tbody></table></div><p><button class="btn sec" id="vx">إغلاق</button></p>`;$("#ov").className="";$("#vx").onclick=closeModal}},
            {l:"اعتماد وتسوية",perm:"stockcount.approve",when:r=>r.status==="draft"&&r.counted>0,url:r=>`/stock-counts/${r.id}/approve`,f:[REASON],body:(v,r)=>({version:r.version,reason:v.reason}),note:"يُنشئ قيد تسوية لكل صنف به فرق (مدين/دائن 5900 مقابل 1300). لا يعتمد الجرد من أجراه."},
            {l:"إلغاء",bad:true,perm:"stockcount.create",when:r=>r.status==="draft",m:"POST",q:true,url:r=>`/stock-counts/${r.id}/cancel`,f:[{n:"reason",l:"سبب الإلغاء",t:"text",req:true}],pre:r=>({version:r.version})}]},
 {g:"المشتريات والمخزون",k:"po",files:"purchase_order",t:"أوامر الشراء",perm:"items.view",type:"list",url:"/purchase-orders",
   cols:[["no","#","num"],["supplier_id","المورد","ref:parties"],["project_id","المشروع","ref:projects"],["status","الحالة","status"],["total","الإجمالي","money"],["received_value","المستلم","money"],["invoiced","المفوتر","money"]],
   create:{l:"أمر شراء",perm:"purchasing.po_create",url:"/purchase-orders",f:[{n:"supplier_id",l:"المورد",t:"select",req:true,src:"suppliers"},{n:"project_id",l:"المشروع",t:"select",req:true,src:"projects"},{n:"request_id",l:"طلب شراء معتمد (اختياري)",t:"select",src:"prs"},{n:"lines",l:"البنود",t:"rows",rows:[{n:"item_id",l:"الصنف",t:"select",req:true,src:"items"},{n:"qty",l:"الكمية",t:"number",req:true},{n:"price",l:"السعر",t:"number",req:true}]}]},
   actions:[{l:"اعتماد",perm:"purchasing.po_approve",when:r=>r.status==="draft",url:r=>`/purchase-orders/${r.id}/approve`,f:[]},
            {l:"استلام",perm:"purchasing.receive",when:r=>r.status==="approved",url:r=>`/purchase-orders/${r.id}/receive`,f:r=>[D("date"),{n:"lines",l:"الكميات المستلمة",t:"rows",rows:[{n:"po_line_id",l:"البند",t:"select",req:true,opts:()=>r.lines.map(l=>[l.id,(L.items[l.item_id]||l.item_id)+" (متبقي "+(l.qty-l.received)+")"])},{n:"qty",l:"الكمية",t:"number",req:true}]}],
             body:v=>({date:v.date,lines:v.lines.map(l=>({po_line_id:Number(l.po_line_id),qty:l.qty}))})},
            {l:"فاتورة مورد",perm:"purchasing.invoice",when:r=>["approved","closed"].includes(r.status),url:r=>`/purchase-orders/${r.id}/invoices`,f:[{n:"ref",l:"رقم الفاتورة",t:"text",req:true},D("date"),{n:"amount",l:"المبلغ",t:"number",req:true}]},
            {l:"إلغاء",bad:true,perm:"purchasing.po_approve",when:r=>["draft","approved"].includes(r.status),q:true,url:r=>`/purchase-orders/${r.id}/cancel`,f:[REASON]}],
   kids:[{t:"فواتير الموردين",perm:"items.view",type:"list",files:"supplier_invoice",url:r=>`/purchase-orders/${r.id}/invoices`,
     cols:[["ref","الرقم"],["date","التاريخ"],["amount","المبلغ","money"],["paid","المدفوع","money"],["outstanding","المتبقي","money"]],
     actions:[{l:"سداد",perm:"purchasing.pay",when:r=>Number(r.outstanding)>0,url:r=>`/supplier-invoices/${r.id}/pay`,f:[D("date"),{n:"amount",l:"المبلغ",t:"number",req:true,def:r=>r.outstanding},{n:"method",l:"الطريقة",t:"select",req:true,opts:[["bank","بنك"],["cash","نقدي"]]}]}]}]},
 {g:"الموارد البشرية",k:"emp",t:"الموظفون",perm:"employees.view",type:"list",url:"/employees",
   cols:[["code","الرقم"],["name","الاسم"],["job","الوظيفة"],["dept","القسم"],["basic","الأساسي","money"],["allowances","البدلات","money"],["insured","مؤمَّن","num"],["status","الحالة","status"]],
   create:{l:"موظف",perm:"employees.create",url:"/employees",f:[{n:"code",l:"الرقم (نفس رقمه في AKT Attendance)",t:"text",req:true},{n:"name",l:"الاسم",t:"text",req:true},{n:"job",l:"الوظيفة",t:"text"},{n:"dept",l:"القسم",t:"text"},{n:"national_id",l:"الرقم القومي (14 رقمًا)",t:"text"},{n:"phone",l:"الهاتف",t:"text"},{n:"hire_date",l:"تاريخ التعيين",t:"date"},{n:"basic",l:"الأساسي",t:"number"},{n:"allowances",l:"البدلات",t:"number"},{n:"insured",l:"مؤمَّن عليه",t:"check",def:true},{n:"project_id",l:"المشروع",t:"select",src:"projects"}]},
   actions:[{l:"تعديل",perm:"employees.update",m:"PATCH",url:r=>"/employees/"+r.id,f:[{n:"name",l:"الاسم",t:"text",def:r=>r.name},{n:"job",l:"الوظيفة",t:"text",def:r=>r.job},{n:"basic",l:"الأساسي",t:"number",def:r=>r.basic},{n:"allowances",l:"البدلات",t:"number",def:r=>r.allowances},{n:"status",l:"الحالة",t:"select",req:true,def:r=>r.status,opts:[["active","نشط"],["suspended","موقوف"],["terminated","منتهي"]]},{n:"reason",l:"السبب (إلزامي عند تغيير الأجر)",t:"text"}],body:(v,r)=>({...v,version:r.version})},
            {l:"سلفة",perm:"employees.salary",url:r=>`/employees/${r.id}/loans`,f:[{n:"amount",l:"قيمة السلفة",t:"number",req:true},{n:"monthly",l:"القسط الشهري",t:"number",req:true},{n:"note",l:"ملاحظة",t:"text"}]}]},
 {g:"الموارد البشرية",k:"att",t:"الحضور (مستورد من AKT Attendance)",perm:"attendance.view",type:"report",url:"/attendance/summary",params:[{n:"month",l:"الشهر (YYYY-MM)",t:"text",req:true,def:new Date().toISOString().slice(0,7)}],
   tools:[{l:"استيراد ملف حضور CSV/XLSX",perm:"attendance.import",go:()=>form("استيراد الحضور",[{n:"file",l:"الملف (الأعمدة: employee_code,date,status,hours,overtime_hours)",t:"file",req:true,accept:".csv,.xlsx"}],async v=>{const F=new FormData();F.append("file",v.file);const r=await api("POST","/attendance/import-file",F);toast(`جديد ${r.new} • محدَّث ${r.updated} • مرفوض ${r.rejected}`,r.rejected>0);if(r.rejected)alert("صفوف مرفوضة:\n"+r.rejected_rows.map(x=>"سطر "+x.row+": "+x.reason).join("\n"))})}]},
 {g:"الموارد البشرية",k:"pay",t:"مسيرات الرواتب",perm:"payroll.view",type:"list",url:"/payroll/runs",
   cols:[["month","الشهر"],["status","الحالة","status"],["employees","الموظفون","num"],["totals.gross","الإجمالي","money"],["totals.emp_ins","تأمين موظف","money"],["totals.er_ins","تأمين شركة","money"],["totals.tax","ضريبة","money"],["totals.net","الصافي","money"],["totals.cost","تكلفة الشركة","money"]],
   create:{l:"مسيرة شهر",perm:"payroll.create",url:"/payroll/runs",f:[{n:"month",l:"الشهر (YYYY-MM)",t:"text",req:true,def:new Date().toISOString().slice(0,7)}]},
   actions:[{l:"اعتماد (يولّد القيد)",perm:"payroll.approve",when:r=>r.status==="draft",url:r=>`/payroll/runs/${r.id}/approve`,f:[]},
            {l:"صرف",perm:"payroll.pay",when:r=>r.status==="approved",url:r=>`/payroll/runs/${r.id}/pay`,f:[D("date"),{n:"method",l:"الطريقة",t:"select",req:true,opts:[["bank","بنك"],["cash","نقدي"]]}]}],
   tools:[{l:"إعدادات التأمينات والضريبة",sec:true,perm:"payroll.settings",m:"PUT",url:"/payroll/settings",f:[{n:"ins_min",l:"حد أدنى للأجر التأميني",t:"number"},{n:"ins_max",l:"حد أقصى للأجر التأميني",t:"number"},{n:"ins_emp_pct",l:"تأمين الموظف %",t:"number"},{n:"ins_er_pct",l:"تأمين الشركة %",t:"number"},{n:"tax_exemption",l:"الإعفاء الضريبي السنوي",t:"number"},{n:"ot_multiplier",l:"معامل الإضافي",t:"number"},REASON],
           body:v=>{const r=v.reason;delete v.reason;return{values:v,reason:r}},note:"القيم الافتراضية تحتاج اعتماد المحاسب القانوني."}],
   kids:[{t:"تفاصيل المسيرة",perm:"payroll.view",type:"list",url:r=>`/payroll/runs/${r.id}`,pick:d=>d.lines,
     cols:[["code","الرقم"],["name","الاسم"],["absent_days","غياب","num"],["overtime_hours","ساعات إضافي","num"],["bonus","مكافأة","money"],["penalty","جزاء","money"],["gross","الإجمالي","money"],["emp_ins","تأمين","money"],["tax","ضريبة","money"],["loan","سلفة","money"],["net","الصافي","money"]],
     actions:[{l:"تعديل",perm:"payroll.create",when:(r,c)=>c.status==="draft",m:"PATCH",url:(r,c)=>`/payroll/runs/${c.id}/lines/${r.id}`,f:[{n:"bonus",l:"مكافأة",t:"number",def:r=>r.bonus},{n:"penalty",l:"جزاء",t:"number",def:r=>r.penalty},{n:"absent_days",l:"أيام الغياب",t:"number",def:r=>r.absent_days},{n:"overtime_hours",l:"ساعات الإضافي",t:"number",def:r=>r.overtime_hours},REASON]}]}]},
 {g:"النظام",k:"users",t:"المستخدمون",perm:"users.view",type:"list",url:"/users",
   cols:[["username","المستخدم"],["full_name","الاسم"],["email","البريد"],["roles","الأدوار"],["is_active","فعّال","num"]],
   create:{l:"مستخدم",perm:"users.manage",url:"/users",f:[{n:"username",l:"اسم المستخدم",t:"text",req:true},{n:"full_name",l:"الاسم",t:"text"},{n:"email",l:"البريد",t:"text"},{n:"password",l:"كلمة المرور (10 أحرف على الأقل)",t:"password",req:true},{n:"roles",l:"الأدوار",t:"multi",opts:ROLES}]},
   actions:[{l:"الأدوار",perm:"users.manage",m:"PATCH",url:r=>"/users/"+r.id,f:[{n:"roles",l:"الأدوار",t:"multi",opts:ROLES,def:r=>r.roles},REASON],body:v=>v},
            {l:r=>r.is_active?"إيقاف":"تفعيل",bad:true,perm:"users.manage",m:"PATCH",url:r=>"/users/"+r.id,f:[REASON],body:(v,r)=>({is_active:!r.is_active,reason:v.reason})},
            {l:"كلمة مرور جديدة",perm:"users.manage",m:"PATCH",url:r=>"/users/"+r.id,f:[{n:"new_password",l:"كلمة المرور الجديدة",t:"password",req:true},REASON],body:v=>v}]},
 {g:"النظام",k:"audit",t:"سجل التدقيق",perm:"audit.view",type:"list",url:"/audit?limit=300",
   cols:[["id","#","num"],["ts","الوقت"],["username","المستخدم"],["action","الإجراء"],["entity","الكيان"],["entity_id","المعرّف"],["reason","السبب"]],
   actions:[{l:"قبل/بعد",perm:"audit.view",view:r=>`<h3>قبل</h3><pre style="white-space:pre-wrap;direction:ltr;text-align:left">${esc(JSON.stringify(r.before,null,1))}</pre><h3>بعد</h3><pre style="white-space:pre-wrap;direction:ltr;text-align:left">${esc(JSON.stringify(r.after,null,1))}</pre><p class="muted">IP: ${esc(r.ip)} • hash: ${esc((r.hash||"").slice(0,16))}</p>`}],
   tools:[{l:"التحقق من سلامة السلسلة",perm:"audit.view",run:async()=>{const r=await api("GET","/audit/verify");alert(r.ok?"السلسلة سليمة. عدد الأسطر المفحوصة: "+(r.checked??""):"تم اكتشاف عبث! "+JSON.stringify(r))},f:[]}]},
 {g:"النظام",k:"admin",t:"النسخ الاحتياطي والحساب",type:"tools",tools:[
   {l:"أخذ نسخة احتياطية",perm:"backup.run",go:async()=>{try{const d=await api("POST","/admin/backup");saveJson(d,"akt-backup-"+new Date().toISOString().slice(0,10)+".json");toast("تم تنزيل النسخة. SHA-256: "+d.sha256.slice(0,12))}catch(e){toast(e.message,true)}}},
   {l:"استعادة نسخة",perm:"backup.restore",bad:true,go:()=>form("استعادة نسخة احتياطية",[{n:"file",l:"ملف النسخة",t:"file",req:true,accept:".json"},REASON],async v=>{if(!confirm("ستُستبدل كل البيانات الحالية. متأكد؟"))throw new Error("أُلغيت الاستعادة");const d=await readJson(v.file);await api("POST","/admin/restore?reason="+encodeURIComponent(v.reason),d);toast("تمت الاستعادة")},{note:"تُرفض أي نسخة بصمتها لا تطابق محتواها."})},
   {l:"استيراد بيانات النظام القديم",perm:"legacy.import",go:()=>form("استيراد من النظام القديم",[{n:"file",l:"ملف النسخة الاحتياطية JSON من النظام القديم",t:"file",req:true,accept:".json"}],async v=>{const r=await api("POST","/legacy/import",await readJson(v.file));alert("تم الاستيراد:\n"+JSON.stringify(r,null,1))},{note:"الاستيراد آمن للتكرار ولا يكرر السجلات."})},
   {l:"تغيير كلمة المرور",perm:"",go:()=>form("تغيير كلمة المرور",[{n:"old_password",l:"الحالية",t:"password",req:true},{n:"new_password",l:"الجديدة (10 أحرف على الأقل)",t:"password",req:true}],async v=>{await api("POST","/auth/change-password",v);toast("تم التغيير، سجّل الدخول مجددًا");logout(true)})}]},
];

/* ============ التنقل ============ */
let cur=null;
function buildNav(){
  const groups={};MODS.forEach(m=>{if(m.type==="tools"||can(m.perm))(groups[m.g]=groups[m.g]||[]).push(m)});
  $("#nav").innerHTML=`<h3>Akt Group ERP</h3><div class="muted" style="padding:0 8px 8px;font-size:12px;color:var(--navink)">${esc(ME.full_name||ME.username)}<br>${esc(ME.roles.map(r=>(ROLES.find(x=>x[0]===r)||[0,r])[1]).join("، "))}</div>`+
   Object.entries(groups).map(([g,ms])=>`<div class="grp">${esc(g)}</div>`+ms.map(m=>`<a data-k="${m.k}">${esc(m.t)}</a>`).join("")).join("")+`<div class="grp"></div><a id="lo">تسجيل الخروج</a>`;
  $("#nav").onclick=e=>{const a=e.target.closest("a");if(!a)return;if(a.id==="lo"){logout();return}open(a.dataset.k);document.body.classList.remove("navopen")};
  $("#mmenu").onclick=()=>document.body.classList.toggle("navopen");$("#nvbg").onclick=()=>document.body.classList.remove("navopen");
}
function open(k){
  const m=MODS.find(x=>x.k===k);if(!m)return;cur=k;
  document.querySelectorAll("#nav a").forEach(a=>a.classList.toggle("on",a.dataset.k===k));{const on=document.querySelector(`#nav a[data-k="${k}"]`);const mt=document.getElementById("mtitle");if(mt&&on)mt.textContent=on.textContent}
  const el=$("#main");
  try{location.hash=k}catch(e){}
  if(m.type==="list")listView(el,m,null);
  else if(m.type==="byproject"){
    el.innerHTML=`<h2>${esc(m.t)}</h2><label>المشروع</label><select id="bp" style="max-width:360px"><option value="">— اختر مشروعًا —</option>${Object.entries(L.projects).map(([i,n])=>`<option value="${esc(i)}">${esc(n)}</option>`).join("")}</select><div id="bpc" class="sub"></div>`;
    $("#bp").onchange=e=>{const v=e.target.value;if(v)listView($("#bpc"),m,{id:v});else $("#bpc").innerHTML=""};
  }
  else if(m.type==="report")reportView(el,m);
  else if(m.type==="tools"){el.innerHTML=`<h2>${esc(m.t)}</h2><div class="tools" id="tl"></div>`;m.tools.forEach(a=>{if(!can(a.perm))return;const b=document.createElement("button");b.className="btn"+(a.bad?" bad":"");b.textContent=a.l;b.onclick=a.go;$("#tl").appendChild(b)})}
  else if(m.type==="multi"){
    el.innerHTML=`<h2>${esc(m.t)}</h2><div class="tools" id="tb"></div><div id="tc"></div>`;
    m.tabs.filter(t=>can(t.perm)).forEach((t,i)=>{const b=document.createElement("button");b.className="btn sec";b.textContent=t.t;b.onclick=()=>{[...$("#tb").children].forEach(x=>x.classList.add("sec"));b.classList.remove("sec");reportView($("#tc"),t)};$("#tb").appendChild(b);if(i===0)b.click()});
  }
}
function logout(silent){
  TOKEN=null;ME=null;try{sessionStorage.removeItem("akt_token")}catch(e){}
  $("#app").className="hide";$("#login").className="";closeModal();
  if(silent)$("#le").textContent="انتهت الجلسة أو تم تسجيل الخروج";
}
async function start(){
  $("#login").className="hide";$("#app").className="";
  await loadRefs();buildNav();
  const k=(location.hash||"").slice(1),first=MODS.find(m=>m.k===k&&(m.type==="tools"||can(m.perm)))||MODS.find(m=>m.type!=="tools"&&can(m.perm));
  if(first)open(first.k);else $("#main").innerHTML=`<p class="muted">لا توجد صلاحيات مسندة لحسابك. راجع المدير.</p>`;
}
$("#lf").onsubmit=async e=>{
  e.preventDefault();$("#le").textContent="";
  try{const r=await api("POST","/auth/login",{username:$("#lu").value,password:$("#lp").value});
    TOKEN=r.token;ME=r.user;try{sessionStorage.setItem("akt_token",TOKEN)}catch(x){}$("#lp").value="";await start()}
  catch(x){$("#le").textContent=x.message}
};
(async()=>{
  if(TOKEN){try{ME=await api("GET","/auth/me");await start();return}catch(e){TOKEN=null}}
  $("#login").className="";
})();
